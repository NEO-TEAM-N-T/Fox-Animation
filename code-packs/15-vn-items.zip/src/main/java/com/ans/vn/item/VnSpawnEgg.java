package com.ans.vn.item;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** A spawn egg for one of the Villager News characters: spawns a normal mob with the character's name. */
public class VnSpawnEgg extends Item {
   private final EntityType<?> type;
   private final String customName;

   public VnSpawnEgg(Item.Properties properties, EntityType<?> type, String customName) {
      super(properties);
      this.type = type;
      this.customName = customName;
   }

   @Override
   public InteractionResult useOn(UseOnContext context) {
      Level level = context.getLevel();
      if (!(level instanceof ServerLevel serverLevel)) {
         return InteractionResult.SUCCESS;
      }

      BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
      Entity entity = this.type.spawn(serverLevel, context.getItemInHand(), context.getPlayer(), pos, EntitySpawnReason.SPAWN_ITEM_USE, true, false);
      if (entity != null) {
         entity.setCustomName(Component.literal(this.customName));
         if (context.getPlayer() != null && !context.getPlayer().getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
         }
      }

      return InteractionResult.SUCCESS;
   }
}
