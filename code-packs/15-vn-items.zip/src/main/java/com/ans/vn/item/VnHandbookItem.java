package com.ans.vn.item;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** The Villager News Handbook. Using it opens the handbook on the client. */
public class VnHandbookItem extends Item {
   public VnHandbookItem(Item.Properties properties) {
      super(properties);
   }

   @Override
   public InteractionResult use(Level level, Player player, InteractionHand hand) {
      if (!(level instanceof ServerLevel) && VnItems.openHandbook != null) {
         VnItems.openHandbook.run();
      }

      return InteractionResult.SUCCESS;
   }
}
