package com.ans.vn.item;

import com.ans.Ans;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** The Villager News items and special spawn eggs. */
public final class VnItems {
   public static final List<Item> ALL = new ArrayList<>();
   /** Set by the client so the handbook item can open the handbook. */
   public static Runnable openHandbook;

   public static Item HANDBOOK;
   public static Item MAYOR_HAT;
   public static Item MICROPHONE;
   public static Item MOUSTACHE;
   public static Item TESTIFICATE_HELMET;
   public static Item VILLAGER_NOSE;

   private VnItems() {
   }

   private static Item register(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
      ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(Ans.MOD_ID, name));
      Item item = factory.apply(props.setId(key));
      Registry.register(BuiltInRegistries.ITEM, key, item);
      ALL.add(item);
      return item;
   }

   private static void egg(String name, EntityType<?> type, String customName) {
      register(name, p -> new VnSpawnEgg(p, type, customName), new Item.Properties());
   }

   public static void register() {
      HANDBOOK = register("villager_news_handbook", VnHandbookItem::new, new Item.Properties().stacksTo(1));
      MAYOR_HAT = register("mayor_hat", Item::new, new Item.Properties().stacksTo(1).equippable(EquipmentSlot.HEAD));
      MICROPHONE = register("microphone", Item::new, new Item.Properties().stacksTo(1));
      MOUSTACHE = register("moustache", Item::new, new Item.Properties().stacksTo(1).equippable(EquipmentSlot.HEAD));
      TESTIFICATE_HELMET = register("testificate_man_helmet", Item::new, new Item.Properties().stacksTo(1).equippable(EquipmentSlot.HEAD));
      VILLAGER_NOSE = register("villager_nose", Item::new, new Item.Properties().stacksTo(1).equippable(EquipmentSlot.HEAD));
      egg("mayor_villager_spawn_egg", EntityTypes.VILLAGER, "Mayor Villager");
      egg("testificate_man_spawn_egg", EntityTypes.VILLAGER, "Testificate Man");
      egg("villager_5_spawn_egg", EntityTypes.VILLAGER, "Villager Number 5");
      egg("villager_9_spawn_egg", EntityTypes.VILLAGER, "Villager Number 9");
      egg("untouchable_villager_spawn_egg", EntityTypes.VILLAGER, "Villager Unreachable");
      egg("wooly_spawn_egg", EntityTypes.SHEEP, "Wooly");

      ResourceKey<CreativeModeTab> tabKey = ResourceKey.create(
         Registries.CREATIVE_MODE_TAB, Identifier.fromNamespaceAndPath(Ans.MOD_ID, "news_and_stuff")
      );
      CreativeModeTab tab = CreativeModeTab.builder(CreativeModeTab.Row.TOP, 0)
         .title(Component.translatable("itemGroup.ans.news_and_stuff"))
         .icon(() -> new ItemStack(HANDBOOK))
         .displayItems((params, output) -> {
            for (Item item : ALL) {
               output.accept(item);
            }
         })
         .build();
      Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, tabKey, tab);
   }
}
