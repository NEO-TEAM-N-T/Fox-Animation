package com.ansviewmodel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class AnsViewmodel {
   public static final String MOD_ID = "ans_viewmodel";
   public static final Logger LOGGER = LoggerFactory.getLogger("ans_viewmodel");
   public static final String TESTED_ANS_VERSION = "0.7.0";

   private AnsViewmodel() {
   }
}
