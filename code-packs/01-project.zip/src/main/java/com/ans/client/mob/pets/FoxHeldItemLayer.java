package com.ans.client.mob.pets;

import com.ans.client.bedrock.FrameResult;
import com.ans.client.bedrock.RenderLayer;
import com.ans.client.equipment.EquipmentLayer;
import com.ans.client.render.MobAnimatable;
import com.ans.client.render.ReplacedMobRenderer;
import com.geckolib.cache.model.BakedGeoModel;
import com.geckolib.cache.model.GeoBone;
import com.geckolib.constant.dataticket.DataTicket;
import com.geckolib.event.replacedentity.CompileReplacedEntityRenderLayersEvent;
import com.geckolib.event.replacedentity.CompileReplacedEntityRenderLayersEvent.Listener;
import com.geckolib.renderer.base.GeoRenderer;
import com.geckolib.renderer.base.RenderPassInfo;
import com.geckolib.renderer.layer.GeoRenderLayer;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.jspecify.annotations.Nullable;

public final class FoxHeldItemLayer<E extends LivingEntity> extends GeoRenderLayer<MobAnimatable, E, LivingEntityRenderState> {
   private static final DataTicket<ItemStackRenderState> ITEM = DataTicket.create("ans_fox_held_item", ItemStackRenderState.class);
   private static final String BONE = "held_item";

   private FoxHeldItemLayer(GeoRenderer<MobAnimatable, E, LivingEntityRenderState> renderer) {
      super(renderer);
   }

   public static void install() {
      CompileReplacedEntityRenderLayersEvent.EVENT.register((Listener)event -> {
         if (event.getRenderer() instanceof ReplacedMobRenderer<?> r && ((MobAnimatable)r.getAnimatable()).mob().type() == EntityTypes.FOX) {
            r.withRenderLayer(new FoxHeldItemLayer(r));
         }
      });
   }

   public void addRenderData(MobAnimatable animatable, @Nullable E entity, LivingEntityRenderState renderState, float partialTick) {
      ItemStack stack = entity == null ? ItemStack.EMPTY : entity.getItemBySlot(EquipmentSlot.MAINHAND);
      ItemStackRenderState state = new ItemStackRenderState();
      if (!stack.isEmpty()) {
         Minecraft.getInstance().getItemModelResolver().updateForLiving(state, stack, ItemDisplayContext.GROUND, entity);
      }

      if (!state.isEmpty() || renderState.hasGeckolibData(ITEM)) {
         renderState.addGeckolibData(ITEM, state);
      }
   }

   public void submitRenderTask(RenderPassInfo<LivingEntityRenderState> info, SubmitNodeCollector collector) {
      ItemStackRenderState item = (ItemStackRenderState)info.getGeckolibData(ITEM);
      FrameResult frame = (FrameResult)info.getGeckolibData(FrameResult.TICKET);
      if (item != null && !item.isEmpty() && frame != null) {
         GeoBone bone = null;

         for (RenderLayer layer : frame.layers()) {
            BakedGeoModel model = this.getGeoModel().getBakedModel(layer.model());
            if (!model.isMissingno()) {
               Optional<GeoBone> b = model.getBone("held_item");
               if (b.isPresent()) {
                  bone = b.get();
                  break;
               }
            }
         }

         if (bone != null) {
            PoseStack ps = info.poseStack();
            ps.pushPose();
            ps.last().set(info.getModelRenderMatrixPose());
            EquipmentLayer.toBone(ps, bone, frame.pose());
            ps.scale(-1.0F, -1.0F, 1.0F);
            ps.rotate(Axis.XP.rotationDegrees(90.0F));
            item.submit(ps, collector, info.packedLight(), OverlayTexture.NO_OVERLAY, ((LivingEntityRenderState)info.renderState()).outlineColor);
            ps.popPose();
         }
      }
   }
}
