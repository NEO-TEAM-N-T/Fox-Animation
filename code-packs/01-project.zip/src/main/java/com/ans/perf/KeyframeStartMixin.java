package com.ans.perf;

import com.ans.client.bedrock.EntityRuntime;
import com.geckolib.animation.AnimationProcessor;
import com.geckolib.animation.object.EasingType;
import com.geckolib.animation.state.AnimationPoint;
import com.geckolib.animation.state.BoneSnapshot;
import com.geckolib.animation.state.ControllerState;
import com.geckolib.animation.state.AnimationPoint.Axis;
import com.geckolib.animation.state.AnimationPoint.Transform;
import com.geckolib.cache.animation.Keyframe;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value = EntityRuntime.class, remap = false)
public abstract class KeyframeStartMixin {
   @Redirect(
      method = "sample",
      at = @At(
         value = "INVOKE",
         target = "Lcom/geckolib/animation/AnimationProcessor;findAnimationPointValue(Lcom/geckolib/animation/state/BoneSnapshot;Lcom/geckolib/animation/state/ControllerState;Lcom/geckolib/animation/state/AnimationPoint;Lcom/geckolib/animation/state/AnimationPoint;ILcom/geckolib/animation/state/AnimationPoint$Transform;Lcom/geckolib/animation/state/AnimationPoint$Axis;Lcom/geckolib/animation/object/EasingType;)F"
      )
   )
   private float ansFix$holdFirstKeyframe(
      BoneSnapshot var1, ControllerState var2, AnimationPoint var3, AnimationPoint var4, int var5, Transform var6, Axis var7, EasingType var8
   ) {
      if (var2.transitionTime() < 0.0) {
         int var9 = var3.keyFramePoints()[var5][var6.index][var7.index];
         if (var9 == -1) {
            Keyframe var10 = var3.getCurrentKeyframe(var5, var6, var7);
            if (var10 != null) {
               return (float)var10.endValue().get(var2);
            }
         }
      }

      return AnimationProcessor.findAnimationPointValue(var1, var2, var3, var4, var5, var6, var7, var8);
   }
}
