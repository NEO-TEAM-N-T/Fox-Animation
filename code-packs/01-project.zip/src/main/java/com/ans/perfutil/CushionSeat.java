package com.ans.perfutil;

import com.geckolib.constant.dataticket.DataTicket;

public final class CushionSeat {
   public static final DataTicket<Float> TICKET = DataTicket.create("ans_cushion_seat", Float.class);
   public static final float OFFSET = parse();

   private CushionSeat() {
   }

   private static float parse() {
      try {
         return Float.parseFloat(System.getProperty("ans.cushionSeat", "0.28125"));
      } catch (NumberFormatException var1) {
         return 0.28125F;
      }
   }
}
