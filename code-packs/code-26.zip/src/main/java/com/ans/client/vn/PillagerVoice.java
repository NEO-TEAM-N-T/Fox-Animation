package com.ans.client.vn;

import com.ans.client.mob.groups.VillagerNews;
import com.ans.client.sound.PackSounds;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

/**
 * Pillagers talk like villagers do, with raider words: they shout when they are on the attack and mutter now and then
 * when they are just standing around. Each pillager has its own voice pitch. The chattiness setting applies.
 */
public final class PillagerVoice {
   private static final String[] LINES = {"line1", "line2"};
   private static final Map<Entity, Long> NEXT = new WeakHashMap<>();
   private static final Map<Entity, Long> TALKING = new WeakHashMap<>();
   /** How long each line lasts, in ticks (1.9 and 2.5 seconds). */
   private static final long[] LENGTH = {40L, 52L};
   private static final Random RANDOM = new Random();
   private static long globalNext;

   private PillagerVoice() {
   }

   public static void tick(Minecraft mc, long now) {
      if (mc.level == null || mc.player == null || now < globalNext || now % 5L != 0L || !VillagerNews.enabled() || VnChatter.multiplier() <= 0.0) {
         return;
      }

      for (Entity e : mc.level.getEntities((Entity)null, mc.player.getBoundingBox().inflate(28.0), x -> BuiltInRegistries.ENTITY_TYPE.getKey(x.getType()).getPath().equals("pillager"))) {
         if (!(e instanceof Mob m) || !m.isAlive()) {
            continue;
         }

         Long next = NEXT.get(e);
         if (next != null && now < next) {
            continue;
         }

         double dist = e.distanceTo(mc.player);
         boolean attacking = m.isAggressive();
         int chance = attacking && dist < 22.0 ? 12 : dist < 18.0 ? 1 : 0;
         if (RANDOM.nextInt(100) >= chance || !VnChatter.pass()) {
            continue;
         }

         int i = RANDOM.nextInt(LINES.length);
         Identifier event = Identifier.tryParse("ans_pillager:" + LINES[i]);
         if (event == null) {
            return;
         }

         PackSounds.playAt(event, SoundSource.HOSTILE, 1.0F, VnChatter.voicePitch(e), e.getX(), e.getY(), e.getZ());
         VnSubtitles.sayNow(e, "ans_pillager." + LINES[i]);
         TALKING.put(e, now + LENGTH[i]);
         NEXT.put(e, now + (attacking ? 160L : 500L) + RANDOM.nextInt(200));
         globalNext = now + 50L;
         return;
      }
   }

   /** True while the pillager is saying a line: its animation then nods and sways. */
   public static boolean talking(Entity e) {
      Long until = TALKING.get(e);
      return until != null && e.level().getGameTime() < until;
   }
}
