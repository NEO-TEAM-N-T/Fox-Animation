package com.ans.client.vn;

import com.ans.Ans;
import com.ans.client.mob.groups.VillagerNews;
import com.ans.client.sound.PackSounds;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;

/**
 * Pillagers talk like villagers do, in raider words: they notice you, shout while they fight, complain when hurt,
 * plead when badly wounded, gossip about villagers and golems, call out to each other and answer one another.
 * The lines are in assets/ans_pillager/dialogue.json. A line that has its own recording plays it; the others play one
 * of the two first recordings at a random pitch, with the text as subtitle. The chattiness setting applies.
 */
public final class PillagerVoice {
   private record Line(String id, String text, boolean sound) {
   }

   private static final class State {
      long next;
      boolean wasAggressive;
      int hurtBefore;
      boolean wasLow;
      boolean dead;
      String lastLine = "";
   }

   private static final Map<String, List<Line>> LINES = new HashMap<>();
   private static final Map<Entity, State> STATES = new WeakHashMap<>();
   private static final Map<Entity, Long> TALKING = new WeakHashMap<>();
   private static final Random RANDOM = new Random();
   private static boolean loaded;
   private static long globalNext;
   private static long lastSpokeAt = -1000L;
   private static Entity lastSpeaker;
   private static boolean playerWasDead;

   private PillagerVoice() {
   }

   private static void load() {
      loaded = true;
      try (InputStream in = PillagerVoice.class.getResourceAsStream("/assets/ans_pillager/dialogue.json");
         Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
         JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
         for (Map.Entry<String, JsonElement> e : root.entrySet()) {
            List<Line> list = new ArrayList<>();
            for (JsonElement el : (JsonArray)e.getValue()) {
               JsonObject o = el.getAsJsonObject();
               list.add(new Line(o.get("id").getAsString(), o.get("text").getAsString(), o.has("sound") && o.get("sound").getAsBoolean()));
            }

            LINES.put(e.getKey(), list);
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Pillager dialogue could not be loaded: {}", ex.toString());
      }
   }

   private static String path(Entity e) {
      return BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath();
   }

   public static void tick(Minecraft mc, long now) {
      if (mc.level == null || mc.player == null || now % 5L != 0L || !VillagerNews.enabled() || VnChatter.multiplier() <= 0.0) {
         return;
      }

      if (!loaded) {
         load();
      }

      List<Mob> pillagers = new ArrayList<>();
      boolean golem = false;
      boolean villager = false;
      for (Entity e : mc.level.getEntities((Entity)null, mc.player.getBoundingBox().inflate(32.0), x -> true)) {
         String p = path(e);
         if (p.equals("pillager") && e instanceof Mob m) {
            pillagers.add(m);
         } else if (p.equals("iron_golem")) {
            golem = true;
         } else if (p.equals("villager")) {
            villager = true;
         }
      }

      boolean playerDead = mc.player.isDeadOrDying();
      boolean deadNow = playerDead && !playerWasDead;
      playerWasDead = playerDead;
      int fighting = 0;
      for (Mob m : pillagers) {
         if (m.isAlive() && m.isAggressive()) {
            fighting++;
         }
      }

      for (Mob m : pillagers) {
         State st = STATES.computeIfAbsent(m, k -> new State());
         boolean aggressive = m.isAggressive();
         double dist = m.distanceTo(mc.player);
         String situation = null;
         boolean urgent = false;
         if (m.isDeadOrDying()) {
            if (!st.dead) {
               st.dead = true;
               situation = "death";
               urgent = true;
            }
         } else if (m.hurtTime > 0 && st.hurtBefore == 0 && RANDOM.nextInt(100) < 55) {
            situation = "hurt";
            urgent = true;
         } else if (m.getHealth() < m.getMaxHealth() * 0.4F && !st.wasLow) {
            st.wasLow = true;
            situation = "low";
            urgent = true;
         } else if (aggressive && !st.wasAggressive && dist < 28.0) {
            situation = "spot";
            urgent = true;
         } else if (deadNow && dist < 30.0) {
            situation = "player_dead";
         } else if (aggressive && dist < 24.0) {
            if (mc.player.getHealth() <= 6.0F && dist < 16.0 && RANDOM.nextInt(100) < 8) {
               situation = "player_low";
            } else if (RANDOM.nextInt(100) < 7) {
               situation = fighting >= 4 && RANDOM.nextBoolean() ? "raid" : "attack";
            }
         } else if (!aggressive && dist < 22.0) {
            if (BuiltInRegistries.ITEM.getKey(m.getItemBySlot(EquipmentSlot.HEAD).getItem()).getPath().contains("banner") && RANDOM.nextInt(100) < 2) {
               situation = "captain";
            } else if (villager && RANDOM.nextInt(100) < 2) {
               situation = "see_villager";
            } else if (golem && RANDOM.nextInt(100) < 2) {
               situation = "see_golem";
            } else if (RANDOM.nextInt(100) < 1) {
               situation = "idle";
            }
         }

         st.wasAggressive = aggressive;
         st.hurtBefore = m.hurtTime;
         if (situation == null && lastSpeaker != null && lastSpeaker != m && now - lastSpokeAt < 70L && now - lastSpokeAt > 20L
            && m.distanceTo(lastSpeaker) < 14.0 && RANDOM.nextInt(100) < 25) {
            situation = "answer";
         }

         if (situation == null || (!urgent && (now < st.next || now < globalNext))) {
            continue;
         }

         if (!urgent && !VnChatter.pass()) {
            continue;
         }

         if (speak(mc, m, st, situation, now)) {
            if (!urgent) {
               return;
            }
         }
      }
   }

   private static boolean speak(Minecraft mc, Mob m, State st, String situation, long now) {
      List<Line> list = LINES.get(situation);
      if (list == null || list.isEmpty()) {
         return false;
      }

      Line pick = list.get(RANDOM.nextInt(list.size()));
      if (pick.id().equals(st.lastLine) && list.size() > 1) {
         pick = list.get((list.indexOf(pick) + 1) % list.size());
      }

      st.lastLine = pick.id();
      Identifier event = Identifier.tryParse("ans_pillager:" + (pick.sound() ? pick.id() : RANDOM.nextBoolean() ? "line1" : "line2"));
      if (event == null) {
         return false;
      }

      float pitch = VnChatter.voicePitch(m);
      if (!pick.sound()) {
         pitch = Math.max(0.6F, Math.min(1.6F, pitch * (0.85F + RANDOM.nextFloat() * 0.4F)));
      }

      PackSounds.playAt(event, SoundSource.HOSTILE, 1.0F, pitch, m.getX(), m.getY(), m.getZ());
      VnSubtitles.sayText(m, pick.text());
      long length = Math.max(34L, Math.min(120L, pick.text().length() * 2L + 20L));
      TALKING.put(m, now + length);
      st.next = now + 130L + RANDOM.nextInt(220);
      globalNext = now + 35L;
      lastSpokeAt = now;
      lastSpeaker = m;
      return true;
   }

   /** True while the pillager is saying a line: its animation then nods and sways. */
   public static boolean talking(Entity e) {
      Long until = TALKING.get(e);
      return until != null && e.level().getGameTime() < until;
   }
}
