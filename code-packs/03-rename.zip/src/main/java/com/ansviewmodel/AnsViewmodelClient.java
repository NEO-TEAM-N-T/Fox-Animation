package com.ansviewmodel;

import com.ansviewmodel.config.ConfigManager;
import com.ansviewmodel.gui.ViewmodelConfigScreen;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Type;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping.Category;

public final class AnsViewmodelClient implements ClientModInitializer {
   private static KeyMapping openKey;
   private static boolean openRequested;

   public void onInitializeClient() {
      ModContainer ans = (ModContainer)FabricLoader.getInstance().getModContainer("ans").orElse(null);
      if (ans == null) {
         AnsViewmodel.LOGGER.error("[ans_viewmodel] Fox & Stuff (mod id 'ans') is not installed; the viewmodel settings do nothing");
      } else {
         String version = ans.getMetadata().getVersion().getFriendlyString();
         AnsViewmodel.LOGGER.info("[ans_viewmodel] Fox & Stuff {} found", version);
         if (!"0.7.0".equals(version)) {
            AnsViewmodel.LOGGER
               .warn(
                  "[ans_viewmodel] This build was made for Fox & Stuff {}; {} is untested. If A&S changed the hooked internals, Mixin will refuse to start rather than render incorrectly.",
                  "0.7.0",
                  version
               );
         }
      }

      ConfigManager.load();
      openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping("key.ans_viewmodel.open", Type.KEYBOARD, InputConstants.UNKNOWN.getValue(), Category.MISC));
      ClientCommandRegistrationCallback.EVENT
         .register(
            (ClientCommandRegistrationCallback)(dispatcher, registryAccess) -> dispatcher.register(
               (LiteralArgumentBuilder)ClientCommands.literal("minecraft_724").executes(context -> {
                  openRequested = true;
                  return 1;
               })
            )
         );
      ClientTickEvents.END_CLIENT_TICK.register(AnsViewmodelClient::onEndTick);
   }

   private static void onEndTick(Minecraft minecraft) {
      while (openKey.consumeClick()) {
         openRequested = true;
      }

      if (openRequested && minecraft.gui.screen() == null) {
         openRequested = false;
         minecraft.gui.setScreen(new ViewmodelConfigScreen(null));
      }
   }
}
