package com.ans.client.mob.groups;

import com.ans.client.molang.BedrockProperties;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import org.jspecify.annotations.Nullable;

/**
 * Villager News entity properties (the Bedrock "p:" properties). Every property starts at the
 * default declared by the original behavior pack; the dialogue system overrides them per entity.
 */
public final class VnProperties {
   private static final Map<Entity, Map<String, Object>> OVERRIDES = new WeakHashMap<>();

   private VnProperties() {
   }

   public static synchronized void set(Entity entity, String name, @Nullable Object value) {
      Map<String, Object> m = OVERRIDES.computeIfAbsent(entity, k -> new java.util.HashMap<>());
      if (value == null) {
         m.remove(name);
      } else {
         m.put(name, value);
      }
   }

   private static synchronized @Nullable Object override(Entity entity, String name) {
      Map<String, Object> m = OVERRIDES.get(entity);
      return m == null ? null : m.get(name);
   }

   private static void defaults(EntityType<? extends Entity> type, String name, Object value) {
      BedrockProperties.register(type, name, e -> {
         Object o = override(e, name);
         return o != null ? o : value;
      });
   }

   public static void register() {
      defaults(EntityTypes.VILLAGER, "p:bvkgap", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:cdpyit", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:difficulty", 0);
      defaults(EntityTypes.VILLAGER, "p:enczhb", 0);
      defaults(EntityTypes.VILLAGER, "p:fsjsbp", 0);
      defaults(EntityTypes.VILLAGER, "p:gcfsvg", Boolean.TRUE);
      defaults(EntityTypes.VILLAGER, "p:ihxrtl", 0);
      defaults(EntityTypes.VILLAGER, "p:kwtyoa", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:mlxeez", "none");
      defaults(EntityTypes.VILLAGER, "p:mreyue", -1);
      defaults(EntityTypes.VILLAGER, "p:mrlyfj", "clear");
      defaults(EntityTypes.VILLAGER, "p:nhncnz", Boolean.TRUE);
      defaults(EntityTypes.VILLAGER, "p:olbxcw", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:pmpece", 0);
      defaults(EntityTypes.VILLAGER, "p:rynvcz", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:sbkmbc", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:sign", -1);
      defaults(EntityTypes.VILLAGER, "p:twjrsp", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:wjnyei", 0);
      defaults(EntityTypes.VILLAGER, "p:zsuvyv", Boolean.FALSE);
      defaults(EntityTypes.WANDERING_TRADER, "p:bvkgap", Boolean.FALSE);
      defaults(EntityTypes.WANDERING_TRADER, "p:difficulty", 0);
      defaults(EntityTypes.WANDERING_TRADER, "p:floige", Boolean.TRUE);
      defaults(EntityTypes.WANDERING_TRADER, "p:gcfsvg", Boolean.TRUE);
      defaults(EntityTypes.WANDERING_TRADER, "p:kwtyoa", Boolean.FALSE);
      defaults(EntityTypes.WANDERING_TRADER, "p:mrlyfj", "clear");
      defaults(EntityTypes.WANDERING_TRADER, "p:pmpece", 0);
      defaults(EntityTypes.WANDERING_TRADER, "p:rynvcz", Boolean.FALSE);
      defaults(EntityTypes.WANDERING_TRADER, "p:twjrsp", Boolean.FALSE);
      defaults(EntityTypes.SHEEP, "p:gmtjzx", Boolean.FALSE);
      defaults(EntityTypes.SHEEP, "p:gwvveg", Boolean.TRUE);
      defaults(EntityTypes.SHEEP, "p:pmpece", 0);
   }
}
