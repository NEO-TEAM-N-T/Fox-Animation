package com.ans.client.vn;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;

/** Timed subtitles for spoken lines, shown in the action bar. */
public final class VnSubtitles {
   private record Line(long showAt, String key) {
   }

   private static final List<Line> PENDING = new ArrayList<>();

   private VnSubtitles() {
   }

   public static synchronized void show(Entity speaker, double[] times, String[] textKeys) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level == null) {
         return;
      }

      long now = mc.level.getGameTime();
      PENDING.clear();
      for (int i = 0; i < textKeys.length; i++) {
         PENDING.add(new Line(now + Math.round(times[i] * 20.0), textKeys[i]));
      }
   }

   public static synchronized void tick(Minecraft mc) {
      if (mc.level == null || mc.player == null || PENDING.isEmpty()) {
         return;
      }

      long now = mc.level.getGameTime();
      Iterator<Line> it = PENDING.iterator();
      while (it.hasNext()) {
         Line l = it.next();
         if (l.showAt() <= now) {
            mc.gui.setOverlayMessage(Component.translatable(l.key()), false);
            it.remove();
         }
      }
   }
}
