package com.ans.client.vn;

import com.ans.Ans;
import com.ans.client.mob.groups.VillagerNews;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

/** Situations that make Villager News villagers speak. All of them are detected on the client. */
public final class VnTriggers {
   private static final String APPROACH = "xfpjxq";
   private static final String MORNING = "zkoewx";
   private static final String AFTERNOON = "kopthx";
   private static final String EVENING = "qknpqr";
   private static final String NIGHT = "sotbtt";
   private static final String GO_TO_BED = "ioxtmt";
   private static final String ATTACKED = "rueszy";

   private static final class Rule {
      String kind;
      String path;
      String flag;
      String effect;
      boolean baby;
      int day;
      int month;
      double lt = Double.NaN;
      double gt = Double.NaN;
      String has;
      String[] paths;
      String[] groups;
   }

   private static final class State {
      long lastSpoke = -100000L;
      long nextIdle = -1L;
      boolean near;
      boolean wasSleeping;
      int lastHurt;
   }

   private static final Map<Entity, State> STATES = new WeakHashMap<>();
   private static final List<Rule> RULES = new ArrayList<>();
   private static final Random RANDOM = new Random();
   private static boolean installed;
   private static double lastPx;
   private static double lastPz;
   private static long stillSince;

   private VnTriggers() {
   }

   public static synchronized void install() {
      if (installed) {
         return;
      }

      installed = true;
      VnSpeech.install();
      loadRules();
      ClientTickEvents.END_CLIENT_TICK.register(VnTriggers::tick);
   }

   private static void loadRules() {
      try (InputStream in = VnTriggers.class.getResourceAsStream("/assets/ans/vn/triggers.json");
         Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
         for (JsonElement e : JsonParser.parseReader(r).getAsJsonObject().getAsJsonArray("rules")) {
            JsonObject o = e.getAsJsonObject();
            Rule rule = new Rule();
            rule.kind = o.get("k").getAsString();
            rule.path = str(o, "path");
            rule.flag = str(o, "flag");
            rule.effect = str(o, "e");
            rule.has = str(o, "has");
            rule.baby = o.has("baby") && o.get("baby").getAsBoolean();
            rule.day = o.has("d") ? o.get("d").getAsInt() : 0;
            rule.month = o.has("m") ? o.get("m").getAsInt() : 0;
            if (o.has("lt")) {
               rule.lt = o.get("lt").getAsDouble();
            }

            if (o.has("gt")) {
               rule.gt = o.get("gt").getAsDouble();
            }

            if (o.has("paths")) {
               JsonArray a = o.getAsJsonArray("paths");
               rule.paths = new String[a.size()];
               for (int i = 0; i < a.size(); i++) {
                  rule.paths[i] = a.get(i).getAsString();
               }
            }

            JsonArray g = o.getAsJsonArray("g");
            rule.groups = new String[g.size()];
            for (int i = 0; i < g.size(); i++) {
               rule.groups[i] = g.get(i).getAsString();
            }

            RULES.add(rule);
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News trigger rules could not be loaded: {}", ex.toString());
      }

      Ans.LOGGER.info("[ans] Villager News: {} situation rules", RULES.size());
   }

   private static String str(JsonObject o, String k) {
      return o.has(k) ? o.get(k).getAsString() : null;
   }

   private static void tick(Minecraft mc) {
      if (mc.level == null || mc.player == null || mc.isPaused() || !VillagerNews.enabled()) {
         return;
      }

      VnSubtitles.tick(mc);
      long now = mc.level.getGameTime();
      double px = mc.player.getX();
      double pz = mc.player.getZ();
      if (Math.abs(px - lastPx) > 0.02 || Math.abs(pz - lastPz) > 0.02) {
         stillSince = now;
      }

      lastPx = px;
      lastPz = pz;
      AABB box = mc.player.getBoundingBox().inflate(12.0);
      List<Entity> found = mc.level.getEntities((Entity)null, box, e -> e.getType() == EntityTypes.VILLAGER);
      for (Entity e : found) {
         if (!(e instanceof LivingEntity v) || v.isBaby()) {
            continue;
         }

         State st = STATES.computeIfAbsent(e, k -> new State());
         double dist = v.distanceTo(mc.player);
         if (st.nextIdle < 0) {
            st.nextIdle = now + 20L * (10 + RANDOM.nextInt(30));
         }

         boolean sleeping = v.isSleeping();
         if (sleeping && !st.wasSleeping && dist < 16) {
            speak(v, st, now, GO_TO_BED);
         }

         st.wasSleeping = sleeping;
         if (sleeping) {
            continue;
         }

         if (v.hurtTime > 0 && st.lastHurt == 0 && dist < 8) {
            speak(v, st, now, ATTACKED);
         }

         st.lastHurt = v.hurtTime;
         if (dist < 3.5 && !st.near && now - st.lastSpoke > 400L) {
            st.near = true;
            speak(v, st, now, APPROACH);
         } else if (dist > 6.0) {
            st.near = false;
         }

         if (dist < 8.0 && now >= st.nextIdle) {
            st.nextIdle = now + 20L * (30 + RANDOM.nextInt(50));
            String group = chooseSituation(mc, v, now);
            speak(v, st, now, group);
         }
      }
   }

   /** Picks a line for something that is true right now; falls back to the time-of-day lines. */
   private static String chooseSituation(Minecraft mc, LivingEntity v, long now) {
      Set<String> seenMobs = new HashSet<>();
      for (Entity o : mc.level.getEntities(v, v.getBoundingBox().inflate(10.0), x -> x != mc.player)) {
         if (o.getType() == EntityTypes.VILLAGER || !v.hasLineOfSight(o)) {
            continue;
         }

         boolean baby = o instanceof LivingEntity l && l.isBaby();
         seenMobs.add(BuiltInRegistries.ENTITY_TYPE.getKey(o.getType()).getPath() + (baby ? "#baby" : ""));
      }

      List<Rule> matching = new ArrayList<>();
      for (Rule r : RULES) {
         if (matches(r, mc, v, now, seenMobs)) {
            matching.add(r);
         }
      }

      if (!matching.isEmpty() && RANDOM.nextInt(4) != 0) {
         Rule r = matching.get(RANDOM.nextInt(matching.size()));
         String g = r.groups[RANDOM.nextInt(r.groups.length)];
         if (VnSpeech.hasGroup(g)) {
            return g;
         }
      }

      return timeOfDayGroup(mc.level.getDayTime() % 24000L);
   }

   private static boolean matches(Rule r, Minecraft mc, LivingEntity v, long now, Set<String> seenMobs) {
      LocalDate date = LocalDate.now();
      switch (r.kind) {
         case "mob":
            return seenMobs.contains(r.path + (r.baby ? "#baby" : ""));
         case "dow":
            return date.getDayOfWeek().getValue() == r.day;
         case "weekend":
            return date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY;
         case "date":
            return date.getMonthValue() == r.month && date.getDayOfMonth() == r.day;
         case "fri13":
            return date.getDayOfWeek() == DayOfWeek.FRIDAY && date.getDayOfMonth() == 13;
         case "month":
            return date.getMonthValue() == r.month;
         case "hour0":
            return LocalTime.now().getMinute() == 0;
         case "dim":
            return mc.level.dimension().toString().contains(r.has);
         case "y":
            return (!Double.isNaN(r.lt) && v.getY() < r.lt) || (!Double.isNaN(r.gt) && v.getY() > r.gt);
         case "rain":
            return mc.level.isRaining() && mc.level.canSeeSky(v.blockPosition());
         case "effect":
            for (MobEffectInstance inst : mc.player.getActiveEffects()) {
               if (inst.getEffect().getRegisteredName().endsWith(":" + r.effect)) {
                  return true;
               }
            }

            return false;
         case "below":
            String block = BuiltInRegistries.BLOCK.getKey(mc.level.getBlockState(mc.player.blockPosition().below()).getBlock()).getPath();
            for (String p : r.paths) {
               if (p.equals(block)) {
                  return true;
               }
            }

            return false;
         case "player":
            return switch (r.flag) {
               case "crouch" -> mc.player.isShiftKeyDown();
               case "flying" -> mc.player.getAbilities().flying;
               case "elytra" -> mc.player.isFallFlying();
               case "still" -> now - stillSince > 200L;
               default -> false;
            };
         case "vstate":
            return switch (r.flag) {
               case "burning" -> v.isOnFire();
               case "lowhp" -> v.getHealth() <= v.getMaxHealth() * 0.35F;
               default -> false;
            };
         default:
            return false;
      }
   }

   private static String timeOfDayGroup(long t) {
      if (t < 6000L) {
         return MORNING;
      }

      if (t < 11000L) {
         return AFTERNOON;
      }

      return t < 13000L ? EVENING : NIGHT;
   }

   private static void speak(Entity e, State st, long now, String group) {
      if (VnSpeech.anyoneSpeaking()) {
         return;
      }

      if (VnSpeech.say(e, group)) {
         st.lastSpoke = now;
      }
   }
}
