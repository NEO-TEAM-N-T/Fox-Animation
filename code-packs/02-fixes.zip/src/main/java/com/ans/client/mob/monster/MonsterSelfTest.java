package com.ans.client.mob.monster;

/** Developer test harness removed from the release build. */
public final class MonsterSelfTest {
   private MonsterSelfTest() {
   }

   public static void init() {
   }
}
