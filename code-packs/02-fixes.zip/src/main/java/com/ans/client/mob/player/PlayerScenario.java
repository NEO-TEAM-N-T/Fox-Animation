package com.ans.client.mob.player;

/** Developer test harness removed from the release build. */
public final class PlayerScenario {
   private PlayerScenario() {
   }

   public static void init() {
   }
}
