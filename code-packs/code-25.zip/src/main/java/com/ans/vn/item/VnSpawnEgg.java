package com.ans.vn.item;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** A spawn egg for one of the Villager News characters: spawns a normal mob with the character's name. */
public class VnSpawnEgg extends Item {
   private final EntityType<?> type;
   private final String customName;
   private final Item outfit;

   public VnSpawnEgg(Item.Properties properties, EntityType<?> type, String customName) {
      this(properties, type, customName, null);
   }

   /** The outfit, when there is one, is put on the spawned mob's head slot; its attachable draws hat, backpack or camera. */
   public VnSpawnEgg(Item.Properties properties, EntityType<?> type, String customName, Item outfit) {
      super(properties);
      this.type = type;
      this.customName = customName;
      this.outfit = outfit;
   }

   @Override
   public InteractionResult useOn(UseOnContext context) {
      Level level = context.getLevel();
      if (!(level instanceof ServerLevel serverLevel)) {
         return InteractionResult.SUCCESS;
      }

      BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
      Entity entity = this.type.spawn(serverLevel, context.getItemInHand(), context.getPlayer(), pos, EntitySpawnReason.SPAWN_ITEM_USE, true, false);
      if (entity != null) {
         entity.setCustomName(Component.literal(this.customName));
         if (this.outfit != null && entity instanceof net.minecraft.world.entity.LivingEntity living) {
            living.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD, new net.minecraft.world.item.ItemStack(this.outfit));
            com.ans.client.vn.VnReflect.invoke(living, "setDropChance", net.minecraft.world.entity.EquipmentSlot.HEAD, 0.0F);
         }

         if (context.getPlayer() != null && !context.getPlayer().getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
         }
      }

      return InteractionResult.SUCCESS;
   }
}
