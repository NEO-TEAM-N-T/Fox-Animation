#!/usr/bin/env python3
"""Builds the two new villagers' outfits (models, textures, attachable bundles, item icons) from simple boxes.

usage: make_outfits.py <output folder>      (writes assets/ans/...)
An outfit is one head-slot item whose model has several parts, each bound to a part of the wearer:
head (hat), body (backpack, camera) so it fits a villager as well as a player.
"""
import json, math, os, random, sys
from PIL import Image, ImageDraw

OUT = sys.argv[1]
A = f'{OUT}/assets/ans'

# name -> (bone name, binding, list of (origin, size, colour, pattern))
OUTFITS = {
    'explorer': {
        'hat': ("'head'", [
            ([-8, 35.2, -8], [16, 1, 16], (214, 168, 70), 'straw'),
            ([-5, 36.2, -5], [10, 4, 10], (222, 178, 80), 'straw'),
            ([-5.2, 36.2, -5.2], [10.4, 1.5, 10.4], (92, 58, 38), 'plain'),
            ([2, 40.2, -3], [2, 2, 2], (236, 236, 232), 'plain'),
            ([-3.5, 40.2, 0.5], [2, 2, 2], (236, 236, 232), 'plain'),
            ([2, 40.0, -3], [2, 0.8, 2], (196, 52, 52), 'plain'),
            ([-3.5, 40.0, 0.5], [2, 0.8, 2], (62, 140, 70), 'plain'),
        ]),
        'pack': ("'body'", [
            ([-4.5, 6, 4.2], [9, 13, 5], (176, 128, 62), 'weave'),
            ([-4.8, 17.5, 4.0], [9.6, 3, 5.6], (150, 104, 48), 'weave'),
            ([-5.5, 18.5, 4.6], [11, 3, 3], (116, 84, 60), 'plain'),
            ([-4.5, 14, -4.4], [1.4, 12, 0.5], (92, 58, 38), 'plain'),
            ([3.1, 14, -4.4], [1.4, 12, 0.5], (92, 58, 38), 'plain'),
            ([3, 18, 5.2], [1, 22, 1], (112, 84, 60), 'plain'),
            ([2.4, 39.5, 5], [2.2, 1, 1.4], (132, 126, 112), 'plain'),
        ]),
    },
    'camera': {
        'camera': ("'body'", [
            ([-3.5, 12.5, -7.4], [7, 5, 3], (58, 58, 64), 'plain'),
            ([-3.5, 12.5, -7.45], [7, 2.2, 3.05], (196, 196, 202), 'plain'),
            ([-1.6, 13.4, -9.6], [3.2, 3.2, 2.2], (30, 30, 34), 'plain'),
            ([-1.0, 14.0, -9.9], [2, 2, 0.5], (72, 110, 170), 'plain'),
            ([-3.0, 17.5, -6.6], [2, 1, 2], (230, 230, 100), 'plain'),
            ([1.2, 17.5, -6.6], [2.2, 1.4, 2], (40, 40, 44), 'plain'),
            ([-4.6, 18.6, -4.5], [9.2, 0.8, 0.5], (120, 40, 40), 'plain'),
            ([-3.4, 18.8, -4.5], [0.8, 7, 0.5], (120, 40, 40), 'plain'),
            ([2.6, 18.8, -4.5], [0.8, 7, 0.5], (120, 40, 40), 'plain'),
        ]),
    },
}


def clamp(v):
    return max(0, min(255, int(v)))


def build(name, bones):
    rnd = random.Random(name)
    img = Image.new('RGBA', (128, 128), (0, 0, 0, 0))
    px = img.load()
    cursor_x = cursor_y = row_h = 0
    geo_bones = []
    binds = {}
    for bone, (binding, cubes) in bones.items():
        bone_name = f'{name}_{bone}'
        binds[bone_name] = binding
        out_cubes = []
        for origin, size, colour, pattern in cubes:
            w, h, d = (max(1, math.ceil(s)) for s in size)
            tw, th = 2 * (d + w), d + h
            if cursor_x + tw > 128:
                cursor_x, cursor_y, row_h = 0, cursor_y + row_h, 0
            if cursor_y + th > 128:
                raise SystemExit('texture is full')
            for y in range(th):
                for x in range(tw):
                    shade = rnd.uniform(-9, 9)
                    if pattern == 'straw':
                        shade += 10 if (x + y) % 4 < 2 else -8
                    elif pattern == 'weave':
                        shade += 9 if (x // 2 + y // 2) % 2 == 0 else -9
                    px[cursor_x + x, cursor_y + y] = (clamp(colour[0] + shade), clamp(colour[1] + shade), clamp(colour[2] + shade), 255)
            out_cubes.append({'origin': origin, 'size': size, 'uv': [cursor_x, cursor_y]})
            cursor_x += tw
            row_h = max(row_h, th)
        geo_bones.append({'name': bone_name, 'pivot': [0, 24, 0], 'cubes': out_cubes})
    geo = {'format_version': '1.12.0', 'minecraft:geometry': [{
        'description': {'identifier': f'geometry.ans.vn_outfit_{name}', 'texture_width': 128, 'texture_height': 128,
                        'visible_bounds_width': 3, 'visible_bounds_height': 3, 'visible_bounds_offset': [0, 1, 0]},
        'bones': geo_bones}]}
    return img, geo, {bn: b for bn, b in binds.items()}


def write(path, data, raw=False):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if raw:
        data.save(path)
    else:
        json.dump(data, open(path, 'w'), indent=1 if 'lang' in path else None, separators=None if 'lang' in path else (',', ':'))


def icon(name, kind):
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if kind == 'hat':
        d.ellipse([0, 8, 15, 14], fill=(214, 168, 70, 255), outline=(150, 108, 40, 255))
        d.rectangle([4, 3, 11, 10], fill=(222, 178, 80, 255), outline=(150, 108, 40, 255))
        d.rectangle([4, 8, 11, 9], fill=(92, 58, 38, 255))
        d.rectangle([9, 1, 10, 3], fill=(236, 236, 232, 255)); d.rectangle([9, 1, 10, 1], fill=(196, 52, 52, 255))
    elif kind == 'camera':
        d.rectangle([1, 5, 14, 13], fill=(58, 58, 64, 255), outline=(20, 20, 24, 255))
        d.rectangle([2, 6, 13, 8], fill=(196, 196, 202, 255))
        d.ellipse([5, 7, 10, 12], fill=(30, 30, 34, 255), outline=(10, 10, 12, 255)); d.ellipse([6, 8, 9, 11], fill=(72, 110, 170, 255))
        d.rectangle([3, 3, 5, 4], fill=(230, 230, 100, 255)); d.rectangle([10, 3, 13, 4], fill=(40, 40, 44, 255))
    return img


def egg(base, spots):
    img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([3, 1, 12, 14], fill=base + (255,), outline=tuple(int(c * 0.55) for c in base) + (255,))
    for x, y in [(6, 4), (9, 6), (5, 8), (8, 10), (10, 11), (6, 12)]:
        d.rectangle([x, y, x + 1, y + 1], fill=spots + (255,))
    return img


def main():
    for name, bones in OUTFITS.items():
        img, geo, binds = build(name, bones)
        write(f'{A}/textures/oreville/vn/outfit_{name}.png', img, raw=True)
        write(f'{A}/geckolib/models/entity/vn_outfit_{name}.geo.json', geo)
        write(f'{A}/geckolib/animations/entity/vn_outfit_{name}.animation.json', {'format_version': '1.8.0', 'animations': {}})
        model = f'ans:entity/vn_outfit_{name}'
        bundle = {'format': 'ans:bedrock_attachable', 'format_version': 1, 'identifier': f'ans:{name}_outfit',
                  'source': {'layer': 'ans', 'file': 'make_outfits.py', 'min_engine_version': '1.12.0'},
                  'animation_file': f'ans:entity/vn_outfit_{name}',
                  'geometry': {'default': model}, 'textures': {'default': f'ans:textures/oreville/vn/outfit_{name}.png'},
                  'materials': {'default': {'bedrock': 'entity_alphatest', 'render_type': 'cutout'}},
                  'animations': {}, 'scripts': {},
                  'render_controllers': [{'geometry': 'Geometry.default', 'textures': ['Texture.default'],
                                          'materials': [{'*': 'Material.default'}], 'id': 'controller.render.ans.default', 'condition': None}],
                  'bone_bindings': {model: {bn.lower(): b for bn, b in binds.items()}},
                  'sound_effects': {}, 'particle_effects': {}}
        write(f'{A}/attachable/vn_outfit_{name}.json', bundle)
    # items: model definitions and icons
    for item, kind, base, spots in [('explorer_outfit', 'hat', None, None), ('camera_outfit', 'camera', None, None),
                                    ('explorer_villager_spawn_egg', None, (200, 162, 90), (79, 122, 58)),
                                    ('camera_villager_spawn_egg', None, (96, 96, 104), (110, 150, 210))]:
        im = icon(item, kind) if kind else egg(base, spots)
        write(f'{A}/textures/item/{item}.png', im, raw=True)
        write(f'{A}/models/item/{item}.json', {'parent': 'minecraft:item/generated', 'textures': {'layer0': f'ans:item/{item}'}})
        write(f'{A}/items/{item}.json', {'model': {'type': 'minecraft:model', 'model': f'ans:item/{item}'}})


if __name__ == '__main__':
    main()
