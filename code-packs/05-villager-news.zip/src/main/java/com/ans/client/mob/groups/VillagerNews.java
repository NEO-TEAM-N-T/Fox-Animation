package com.ans.client.mob.groups;

import com.ans.Ans;
import com.ans.client.molang.PackSettings;
import java.util.Locale;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import org.jspecify.annotations.Nullable;

/** Chooses the Villager News look for villagers, wandering traders and Wooly the sheep. */
public final class VillagerNews {
   public static final String SETTING = "oreville_ans:villagernews";

   private VillagerNews() {
   }

   public static boolean enabled() {
      return PackSettings.enabled(SETTING);
   }

   public static @Nullable Identifier villagerBundle(Entity entity) {
      if (!enabled()) {
         return null;
      }

      String n = name(entity);
      String id = "vn_villager";
      if (n.contains("mayor")) {
         id = "vn_mayor";
      } else if (n.contains("testificate")) {
         id = "vn_testificate";
      } else if (n.contains("unreachable") || n.contains("untouchable")) {
         id = "vn_unreachable";
      } else if (n.matches(".*(number|no\\.?|#)\\s*5\\b.*")) {
         id = "vn_villager5";
      } else if (n.matches(".*(number|no\\.?|#)\\s*9\\b.*")) {
         id = "vn_villager9";
      }

      return Ans.id("entity/" + id + ".json");
   }

   public static @Nullable Identifier traderBundle(Entity entity) {
      return enabled() ? Ans.id("entity/vn_wandering_trader.json") : null;
   }

   public static @Nullable Identifier sheepBundle(Entity entity) {
      return enabled() && name(entity).contains("wooly") ? Ans.id("entity/vn_wooly.json") : null;
   }

   private static String name(Entity entity) {
      return entity.getCustomName() == null ? "" : entity.getCustomName().getString().toLowerCase(Locale.ROOT);
   }
}
