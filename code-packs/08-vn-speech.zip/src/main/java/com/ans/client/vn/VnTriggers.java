package com.ans.client.vn;

import com.ans.client.mob.groups.VillagerNews;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;

/** First set of situations that make Villager News villagers speak (all detected on the client). */
public final class VnTriggers {
   private static final String APPROACH = "xfpjxq";
   private static final String MORNING = "zkoewx";
   private static final String AFTERNOON = "kopthx";
   private static final String EVENING = "qknpqr";
   private static final String NIGHT = "sotbtt";
   private static final String GO_TO_BED = "ioxtmt";
   private static final String ATTACKED = "rueszy";

   private static final class State {
      long lastSpoke = -100000L;
      long nextIdle = -1L;
      boolean near;
      boolean wasSleeping;
      int lastHurt;
   }

   private static final Map<Entity, State> STATES = new WeakHashMap<>();
   private static final Random RANDOM = new Random();
   private static boolean installed;

   private VnTriggers() {
   }

   public static synchronized void install() {
      if (installed) {
         return;
      }

      installed = true;
      VnSpeech.install();
      ClientTickEvents.END_CLIENT_TICK.register(VnTriggers::tick);
   }

   private static void tick(Minecraft mc) {
      if (mc.level == null || mc.player == null || mc.isPaused() || !VillagerNews.enabled()) {
         return;
      }

      long now = mc.level.getGameTime();
      AABB box = mc.player.getBoundingBox().inflate(12.0);
      List<Entity> found = mc.level.getEntities((Entity)null, box, e -> e.getType() == EntityTypes.VILLAGER);
      for (Entity e : found) {
         if (!(e instanceof LivingEntity v) || v.isBaby()) {
            continue;
         }

         State st = STATES.computeIfAbsent(e, k -> new State());
         double dist = v.distanceTo(mc.player);
         if (st.nextIdle < 0) {
            st.nextIdle = now + 20L * (10 + RANDOM.nextInt(30));
         }

         boolean sleeping = v.isSleeping();
         if (sleeping && !st.wasSleeping && dist < 16) {
            speak(v, st, now, GO_TO_BED);
         }

         st.wasSleeping = sleeping;
         if (sleeping) {
            continue;
         }

         if (v.hurtTime > 0 && st.lastHurt == 0 && dist < 8) {
            speak(v, st, now, ATTACKED);
         }

         st.lastHurt = v.hurtTime;
         if (dist < 3.5 && !st.near && now - st.lastSpoke > 400L) {
            st.near = true;
            speak(v, st, now, APPROACH);
         } else if (dist > 6.0) {
            st.near = false;
         }

         if (dist < 8.0 && now >= st.nextIdle) {
            st.nextIdle = now + 20L * (40 + RANDOM.nextInt(50));
            speak(v, st, now, timeOfDayGroup(mc.level.getDayTime() % 24000L));
         }
      }
   }

   private static String timeOfDayGroup(long t) {
      if (t < 6000L) {
         return MORNING;
      }

      if (t < 11000L) {
         return AFTERNOON;
      }

      return t < 13000L ? EVENING : NIGHT;
   }

   private static void speak(Entity e, State st, long now, String group) {
      if (VnSpeech.anyoneSpeaking()) {
         return;
      }

      if (VnSpeech.say(e, group)) {
         st.lastSpoke = now;
      }
   }
}
