package com.ans.client.vn;

import net.minecraft.world.entity.Entity;

/** Subtitle display for spoken lines (text is shown by the HUD layer added in a later step). */
public final class VnSubtitles {
   private VnSubtitles() {
   }

   public static void show(Entity speaker, double[] times, String[] textKeys) {
      // Subtitles are drawn by a HUD overlay; this hook is where it will receive each line.
   }
}
