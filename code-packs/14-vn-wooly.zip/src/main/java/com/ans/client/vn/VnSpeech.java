package com.ans.client.vn;

import com.ans.Ans;
import com.ans.client.bedrock.EntityRuntime;
import com.ans.client.molang.MolangVars;
import com.ans.client.sound.PackSounds;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import net.minecraft.world.entity.Entity;

/**
 * Villager News speech: plays a spoken line (voice + mouth + gesture) on a villager.
 * A line is a "clip": a timeline of variable assignments that the model animations read.
 */
public final class VnSpeech {
   public record Variant(String anim, String sound, double duration, double weight, double[] subTimes, String[] subKeys) {
   }

   public record Group(String id, String title, String body, List<Variant> variants) {
   }

   private static final class Clip {
      double length;
      double[] times;
      String[][] names;
      Object[][] values;
   }

   private static final class Active {
      Clip clip;
      Group group;
      Variant variant;
      int startTick;
      int next;
   }

   private static final Map<String, Group> GROUPS = new HashMap<>();
   private static final Map<String, Clip> CLIPS = new HashMap<>();
   private static final Map<Entity, Active> ACTIVE = new WeakHashMap<>();
   private static final Random RANDOM = new Random();
   private static boolean loaded;
   private static boolean installed;

   private VnSpeech() {
   }

   public static synchronized void install() {
      if (installed) {
         return;
      }

      installed = true;
      load();
      EntityRuntime.addPreAnimationHook((entity, runtime, ctx) -> apply(entity, runtime, ctx.partialTick));
   }

   private static Reader open(String path) throws IOException {
      InputStream in = VnSpeech.class.getResourceAsStream(path);
      if (in == null) {
         throw new IOException("Missing resource " + path);
      }

      return new InputStreamReader(in, StandardCharsets.UTF_8);
   }

   private static synchronized void load() {
      if (loaded) {
         return;
      }

      loaded = true;
      try (Reader r = open("/assets/ans/vn/dialogue.json")) {
         JsonObject groups = JsonParser.parseReader(r).getAsJsonObject().getAsJsonObject("groups");
         for (Map.Entry<String, JsonElement> e : groups.entrySet()) {
            JsonObject g = e.getValue().getAsJsonObject();
            List<Variant> vs = new ArrayList<>();
            for (JsonElement ve : g.getAsJsonArray("v")) {
               JsonObject v = ve.getAsJsonObject();
               JsonArray subs = v.getAsJsonArray("subs");
               double[] st = new double[subs.size()];
               String[] sk = new String[subs.size()];
               for (int i = 0; i < subs.size(); i++) {
                  JsonArray s = subs.get(i).getAsJsonArray();
                  st[i] = s.get(0).getAsDouble();
                  sk[i] = s.get(1).getAsString();
               }

               vs.add(new Variant(
                  v.get("anim").getAsString(), v.get("sound").getAsString(), v.get("dur").getAsDouble(), v.get("w").getAsDouble(), st, sk
               ));
            }

            String title = g.has("title") ? g.get("title").getAsString() : "";
            String body = g.has("body") ? g.get("body").getAsString() : "";
            GROUPS.put(e.getKey(), new Group(e.getKey(), title, body, vs));
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News dialogue data could not be loaded: {}", ex.toString());
      }

      try (Reader r = open("/assets/ans/vn/clips.json")) {
         for (Map.Entry<String, JsonElement> e : JsonParser.parseReader(r).getAsJsonObject().entrySet()) {
            JsonObject o = e.getValue().getAsJsonObject();
            Clip c = new Clip();
            c.length = o.get("len").getAsDouble();
            JsonArray ev = o.getAsJsonArray("ev");
            c.times = new double[ev.size()];
            c.names = new String[ev.size()][];
            c.values = new Object[ev.size()][];
            for (int i = 0; i < ev.size(); i++) {
               JsonArray pair = ev.get(i).getAsJsonArray();
               c.times[i] = pair.get(0).getAsDouble();
               JsonArray items = pair.get(1).getAsJsonArray();
               c.names[i] = new String[items.size()];
               c.values[i] = new Object[items.size()];
               for (int j = 0; j < items.size(); j++) {
                  JsonArray it = items.get(j).getAsJsonArray();
                  c.names[i][j] = it.get(0).getAsString();
                  JsonElement val = it.get(1);
                  c.values[i][j] = val.getAsJsonPrimitive().isNumber() ? (Object) val.getAsDouble() : val.getAsString();
               }
            }

            CLIPS.put(e.getKey(), c);
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News speech clips could not be loaded: {}", ex.toString());
      }

      Ans.LOGGER.info("[ans] Villager News dialogue: {} groups, {} clips", GROUPS.size(), CLIPS.size());
   }

   public static java.util.Collection<Group> groups() {
      load();
      return GROUPS.values();
   }

   public static boolean hasGroup(String id) {
      return GROUPS.containsKey(id);
   }

   public static synchronized boolean isSpeaking(Entity entity) {
      return ACTIVE.containsKey(entity);
   }

   public static synchronized boolean anyoneSpeaking() {
      return !ACTIVE.isEmpty();
   }

   /** Starts a random (weighted) line of the given dialogue group on the entity. */
   public static boolean say(Entity entity, String groupId) {
      load();
      Group g = GROUPS.get(groupId);
      if (g == null || g.variants().isEmpty() || isSpeaking(entity)) {
         return false;
      }

      double total = 0.0;
      for (Variant v : g.variants()) {
         total += Math.max(v.weight(), 0.0001);
      }

      double roll = RANDOM.nextDouble() * total;
      Variant pick = g.variants().get(0);
      for (Variant v : g.variants()) {
         roll -= Math.max(v.weight(), 0.0001);
         if (roll <= 0) {
            pick = v;
            break;
         }
      }

      PackSounds.play(entity, 0.0F, List.of("oreville_vn:" + pick.sound()), "villager_news", "dialogue");
      Clip clip = CLIPS.get(pick.anim());
      if (clip != null) {
         Active a = new Active();
         a.clip = clip;
         a.group = g;
         a.variant = pick;
         a.startTick = entity.tickCount;
         synchronized (VnSpeech.class) {
            ACTIVE.put(entity, a);
         }
      }

      VnSubtitles.show(entity, pick.subTimes(), pick.subKeys());
      return true;
   }

   private static void apply(Entity entity, EntityRuntime runtime, float partialTick) {
      Active a;
      synchronized (VnSpeech.class) {
         a = ACTIVE.get(entity);
      }

      if (a == null) {
         return;
      }

      double t = (entity.tickCount + partialTick - a.startTick) / 20.0;
      Clip c = a.clip;
      while (a.next < c.times.length && c.times[a.next] <= t) {
         for (int j = 0; j < c.names[a.next].length; j++) {
            int slot = MolangVars.id(c.names[a.next][j]);
            Object val = c.values[a.next][j];
            if (val instanceof Double d) {
               runtime.variables().set(slot, d.doubleValue());
            } else {
               runtime.variables().set(slot, val);
            }
         }

         a.next++;
      }

      if (t >= c.length + 0.1 && a.next >= c.times.length) {
         synchronized (VnSpeech.class) {
            ACTIVE.remove(entity);
         }
      }
   }
}
