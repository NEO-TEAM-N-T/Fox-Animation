package com.ans.client.vn;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** In-game handbook (/vnhandbook) and quick spawn helper (/vnspawn). */
public final class VnHandbook {
   private VnHandbook() {
   }

   public static void install() {
      ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
         dispatcher.register(
            ClientCommands.literal("vnhandbook")
               .executes(ctx -> {
                  handbook(ctx, "");
                  return 1;
               })
               .then(
                  ClientCommands.argument("search", StringArgumentType.greedyString())
                     .executes(ctx -> {
                        handbook(ctx, StringArgumentType.getString(ctx, "search"));
                        return 1;
                     })
               )
         );
         dispatcher.register(
            ClientCommands.literal("vnspawn")
               .executes(ctx -> {
                  ctx.getSource().sendFeedback(Component.literal("Use /vnspawn <mayor|testificate|villager5|villager9|unreachable|villager|trader|wooly> (needs cheats)"));
                  return 1;
               })
               .then(
                  ClientCommands.argument("who", StringArgumentType.word())
                     .executes(ctx -> {
                        spawn(ctx, StringArgumentType.getString(ctx, "who"));
                        return 1;
                     })
               )
         );
      });
   }

   private static void handbook(CommandContext<FabricClientCommandSource> ctx, String query) {
      FabricClientCommandSource src = ctx.getSource();
      String q = query.trim().toLowerCase(Locale.ROOT);
      List<VnSpeech.Group> hits = new ArrayList<>();
      for (VnSpeech.Group g : VnSpeech.groups()) {
         if (!g.title().isEmpty() && (q.isEmpty() || g.title().toLowerCase(Locale.ROOT).contains(q))) {
            hits.add(g);
         }
      }

      hits.sort((a, b) -> a.title().compareToIgnoreCase(b.title()));
      if (q.isEmpty()) {
         src.sendFeedback(Component.literal("§eVillager News handbook: §7" + hits.size() + " situations. Search with §f/vnhandbook <words>§7, for example §f/vnhandbook bed"));
         return;
      }

      if (hits.isEmpty()) {
         src.sendFeedback(Component.literal("§7No handbook entry matches \"" + query + "\"."));
         return;
      }

      VnSpeech.Group exact = null;
      for (VnSpeech.Group g : hits) {
         if (g.title().equalsIgnoreCase(q)) {
            exact = g;
         }
      }

      if (hits.size() == 1 || exact != null) {
         VnSpeech.Group g = exact != null ? exact : hits.get(0);
         src.sendFeedback(Component.literal("§6" + g.title()));
         src.sendFeedback(Component.literal(g.body()));
         return;
      }

      src.sendFeedback(Component.literal("§e" + hits.size() + " entries:"));
      for (int i = 0; i < Math.min(hits.size(), 15); i++) {
         src.sendFeedback(Component.literal("§7- " + hits.get(i).title()));
      }

      if (hits.size() > 15) {
         src.sendFeedback(Component.literal("§7... narrow the search to see more."));
      }
   }

   private static void spawn(CommandContext<FabricClientCommandSource> ctx, String who) {
      String command;
      switch (who.toLowerCase(Locale.ROOT)) {
         case "mayor" -> command = "summon minecraft:villager ~ ~ ~ {CustomName:\"Mayor Villager\"}";
         case "testificate" -> command = "summon minecraft:villager ~ ~ ~ {CustomName:\"Testificate Man\"}";
         case "villager5" -> command = "summon minecraft:villager ~ ~ ~ {CustomName:\"Villager Number 5\"}";
         case "villager9" -> command = "summon minecraft:villager ~ ~ ~ {CustomName:\"Villager Number 9\"}";
         case "unreachable" -> command = "summon minecraft:villager ~ ~ ~ {CustomName:\"Villager Unreachable\"}";
         case "villager" -> command = "summon minecraft:villager ~ ~ ~";
         case "trader" -> command = "summon minecraft:wandering_trader ~ ~ ~";
         case "wooly" -> command = "summon minecraft:sheep ~ ~ ~ {CustomName:\"Wooly\"}";
         default -> {
            ctx.getSource().sendFeedback(Component.literal("§7Unknown. Use mayor, testificate, villager5, villager9, unreachable, villager, trader or wooly."));
            return;
         }
      }

      Minecraft mc = Minecraft.getInstance();
      if (mc.getConnection() != null) {
         mc.getConnection().sendCommand(command);
      }
   }
}
