package com.ans.vn.item;

import com.ans.vn.net.VnNet;
import com.ans.vn.net.VnSpecials;
import net.fabricmc.api.ModInitializer;

/** Runs on both the client and the server: registers the Villager News items, trades, the network packet and the special villagers. */
public class VnCommon implements ModInitializer {
   @Override
   public void onInitialize() {
      VnItems.register();
      VnVillagerItems.register();
      VnSpecialTrades.register();
      VnNet.install();
      VnSpecials.install();
   }
}
