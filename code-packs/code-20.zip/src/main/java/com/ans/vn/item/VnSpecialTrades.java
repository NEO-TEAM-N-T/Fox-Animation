package com.ans.vn.item;

import com.ans.Ans;
import com.ans.client.vn.VnReflect;
import java.util.List;
import java.util.Locale;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Four of the special villagers sell a Villager News item for emeralds, like in the original add-on:
 * the Mayor sells the Mayor Hat (24), Testificate Man his helmet (16), Villager Number 5 the Moustache (16)
 * and Villager Number 9 the Microphone (16). Each trade can be used 16 times.
 */
public final class VnSpecialTrades {
   private static boolean failed;

   private VnSpecialTrades() {
   }

   public static void register() {
      UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
         if (level instanceof ServerLevel && entity instanceof Villager v && !v.isBaby() && !player.isSpectator()) {
            try {
               ensure(v);
            } catch (ReflectiveOperationException | RuntimeException ex) {
               if (!failed) {
                  failed = true;
                  Ans.LOGGER.warn("[ans] Could not add the special villager trade: {}", ex.toString());
               }
            }
         }

         return InteractionResult.PASS;
      });
   }

   /** Makes sure a special villager has its trade; named villagers from eggs, commands and new villages all get it. */
   private static void ensure(Villager v) throws ReflectiveOperationException {
      if (v.getCustomName() == null) {
         return;
      }

      String name = v.getCustomName().getString().toLowerCase(Locale.ROOT);
      Item item;
      int price;
      if (name.contains("mayor")) {
         item = VnItems.MAYOR_HAT;
         price = 24;
      } else if (name.contains("testificate")) {
         item = VnItems.TESTIFICATE_HELMET;
         price = 16;
      } else if (name.contains("5") && !name.contains("9")) {
         item = VnItems.MOUSTACHE;
         price = 16;
      } else if (name.contains("9") && !name.contains("5")) {
         item = VnItems.MICROPHONE;
         price = 16;
      } else {
         return;
      }

      Object offers = VnReflect.invoke(v, "getOffers");
      if (!(offers instanceof List<?> list)) {
         return;
      }

      for (Object o : list) {
         Object result = VnReflect.invoke(o, "getResult");
         if (result instanceof ItemStack s && s.getItem() == item) {
            return;
         }
      }

      Class<?> costType = Class.forName("net.minecraft.world.item.trading.ItemCost");
      Class<?> offerType = Class.forName("net.minecraft.world.item.trading.MerchantOffer");
      Class<?> itemLike = Class.forName("net.minecraft.world.level.ItemLike");
      Object cost = costType.getConstructor(itemLike, int.class).newInstance(Items.EMERALD, price);
      Object offer = offerType.getConstructor(costType, ItemStack.class, int.class, int.class, float.class)
         .newInstance(cost, new ItemStack(item), 16, 2, 0.1F);
      VnReflect.invoke(offers, "add", offer);
   }
}
