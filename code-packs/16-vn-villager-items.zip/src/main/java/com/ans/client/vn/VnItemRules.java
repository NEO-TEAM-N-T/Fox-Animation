package com.ans.client.vn;

import com.ans.Ans;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/** Dialogue groups for the Villager News items (loaded from items.json). */
public final class VnItemRules {
   public static final Map<String, String[][]> COSMETIC = new HashMap<>();
   public static final Map<String, String[]> FOOD_BABY = new HashMap<>();
   public static final Map<String, String[]> FOOD_ADULT = new HashMap<>();
   public static final Map<String, String[]> LISTS = new HashMap<>();
   private static boolean loaded;

   private VnItemRules() {
   }

   private static String[] ids(JsonElement e) {
      JsonArray a = e.getAsJsonArray();
      String[] r = new String[a.size()];
      for (int i = 0; i < r.length; i++) {
         r[i] = a.get(i).getAsString();
      }

      return r;
   }

   public static synchronized void load() {
      if (loaded) {
         return;
      }

      loaded = true;
      try (InputStream in = VnItemRules.class.getResourceAsStream("/assets/ans/vn/items.json");
         Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
         JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
         for (Map.Entry<String, JsonElement> e : root.entrySet()) {
            String key = e.getKey();
            JsonElement v = e.getValue();
            if (key.equals("cosmetic")) {
               for (Map.Entry<String, JsonElement> c : v.getAsJsonObject().entrySet()) {
                  JsonObject o = c.getValue().getAsJsonObject();
                  COSMETIC.put(c.getKey(), new String[][]{ids(o.get("adult")), ids(o.get("baby")), {o.get("code").getAsString()}});
               }
            } else if (key.equals("foodBaby")) {
               for (Map.Entry<String, JsonElement> c : v.getAsJsonObject().entrySet()) {
                  FOOD_BABY.put(c.getKey(), ids(c.getValue()));
               }
            } else if (key.equals("foodAdult")) {
               for (Map.Entry<String, JsonElement> c : v.getAsJsonObject().entrySet()) {
                  FOOD_ADULT.put(c.getKey(), ids(c.getValue()));
               }
            } else if (v.isJsonArray()) {
               LISTS.put(key, ids(v));
            }
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News item rules could not be loaded: {}", ex.toString());
      }
   }

   public static String[] list(String key) {
      load();
      return LISTS.get(key);
   }
}
