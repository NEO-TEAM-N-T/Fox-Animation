package com.ans.client.vn;

import com.ans.Ans;
import com.ans.client.mob.groups.VillagerNews;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.MerchantScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;

/** Reactions to what the player does: using, placing and breaking blocks, trading, and villager changes. */
public final class VnActions {
   private record Rule(String match, String[] groups) {
      boolean test(String path) {
         char c = match.charAt(0);
         String m = match.substring(1);
         return c == '=' ? path.equals(m) : path.contains(m);
      }
   }

   private static final List<Rule> USE = new ArrayList<>();
   private static final List<Rule> PLACE = new ArrayList<>();
   private static final List<Rule> BREAK = new ArrayList<>();
   private static final Map<String, String[]> WORK = new HashMap<>();
   private static final Map<String, String[]> EVENTS = new HashMap<>();
   private static final Map<String, String[]> CAST_MEET = new HashMap<>();
   private static final Map<String, String[]> SPEAKERS = new HashMap<>();
   private static final List<Rule> ATTACK = new ArrayList<>();
   private static final Map<Entity, Long> ATTACKED_AT = new WeakHashMap<>();
   private static String[] attackDefault;
   private static boolean installed;
   private static Entity tradingWith;
   private static int emeraldsAtOpen;

   private VnActions() {
   }

   public static synchronized boolean recentAttack(Entity e, long now) {
      Long t = ATTACKED_AT.get(e);
      return t != null && now - t < 12L;
   }

   /** Makes the villager nearest to the player react (used for things the player does that are not tied to a block). */
   public static void reactNearPlayer(Minecraft mc, String[] groups) {
      if (groups == null || mc.level == null || mc.player == null) {
         return;
      }

      LivingEntity best = null;
      double bestDist = 14.0 * 14.0;
      for (Entity e : mc.level.getEntities((Entity)null, mc.player.getBoundingBox().inflate(14.0), x -> x instanceof Villager)) {
         double d = e.distanceToSqr(mc.player);
         if (d < bestDist && e instanceof LivingEntity le && !le.isBaby()) {
            best = le;
            bestDist = d;
         }
      }

      if (best != null) {
         VnTriggers.react(best, groups);
      }
   }

   public static String[] events(String key) {
      return EVENTS.get(key);
   }

   public static String[] workGroups(String profession) {
      return WORK.get(profession);
   }

   public static String[] castMeet(String cast) {
      return CAST_MEET.get(cast);
   }

   public static String[] speakerGroups(String speaker) {
      return SPEAKERS.get(speaker);
   }

   public static synchronized void install() {
      if (installed) {
         return;
      }

      installed = true;
      load();
      UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
         Minecraft mc = Minecraft.getInstance();
         if (level != mc.level || player != mc.player || !VillagerNews.enabled()) {
            return InteractionResult.PASS;
         }

         BlockPos pos = hit.getBlockPos();
         String block = BuiltInRegistries.BLOCK.getKey(level.getBlockState(pos).getBlock()).getPath();
         ItemStack held = player.getItemInHand(hand);
         String[] groups = null;
         if (!player.isShiftKeyDown()) {
            groups = match(USE, block);
         }

         if (groups == null && held.getItem() instanceof BlockItem) {
            groups = match(PLACE, BuiltInRegistries.ITEM.getKey(held.getItem()).getPath());
            if (groups == null) {
               groups = EVENTS.get("placeAny");
            }
         }

         if (block.contains("campfire") && held.has(net.minecraft.core.component.DataComponents.FOOD)) {
            groups = VnItemRules.list("cook");
         }

         react(mc, pos, groups);
         return InteractionResult.PASS;
      });
      AttackBlockCallback.EVENT.register((player, level, hand, pos, direction) -> {
         Minecraft mc = Minecraft.getInstance();
         if (level != mc.level || player != mc.player || !VillagerNews.enabled()) {
            return InteractionResult.PASS;
         }

         String block = BuiltInRegistries.BLOCK.getKey(level.getBlockState(pos).getBlock()).getPath();
         String[] groups = match(BREAK, block);
         if (groups == null) {
            groups = EVENTS.get("breakAny");
         }

         react(mc, pos, groups);
         return InteractionResult.PASS;
      });
      AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
         Minecraft mc = Minecraft.getInstance();
         if (level != mc.level || player != mc.player || !VillagerNews.enabled() || !(entity instanceof Villager v)) {
            return InteractionResult.PASS;
         }

         synchronized (VnActions.class) {
            ATTACKED_AT.put(entity, mc.level.getGameTime());
         }

         String[] groups;
         if (v.isBaby()) {
            groups = EVENTS.get("babyHurt");
         } else {
            groups = match(ATTACK, BuiltInRegistries.ITEM.getKey(player.getItemInHand(hand).getItem()).getPath());
            if (groups == null) {
               groups = attackDefault;
            }
         }

         VnTriggers.react(v, groups);
         return InteractionResult.PASS;
      });
      UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
         Minecraft mc = Minecraft.getInstance();
         if (level != mc.level || player != mc.player || !VillagerNews.enabled()) {
            return InteractionResult.PASS;
         }

         if (entity.getType() == EntityTypes.SHEEP && entity instanceof LivingEntity sheep && VillagerNews.isWooly(entity)) {
            boolean shears = BuiltInRegistries.ITEM.getKey(player.getItemInHand(hand).getItem()).getPath().equals("shears");
            VnTriggers.react(sheep, EVENTS.get(shears ? "woolyShear" : "woolyInteract"));
            return InteractionResult.PASS;
         }

         if (entity.getType() == EntityTypes.SHEEP && !VillagerNews.isWooly(entity)
            && BuiltInRegistries.ITEM.getKey(player.getItemInHand(hand).getItem()).getPath().equals("shears")) {
            reactNearPlayer(mc, VnItemRules.list("shearSheep"));
            return InteractionResult.PASS;
         }

         if (!(entity instanceof Villager v)) {
            return InteractionResult.PASS;
         }

         String heldPath = BuiltInRegistries.ITEM.getKey(player.getItemInHand(hand).getItem()).getPath();
         if (player.getItemInHand(hand).getItem() == com.ans.vn.item.VnItems.VILLAGER_NOSE
            && !v.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.OFFHAND).is(com.ans.vn.item.VnItems.VILLAGER_NOSE)) {
            VnTriggers.react(v, VnItemRules.list("noseSecond"));
            return InteractionResult.PASS;
         }

         if ((heldPath.equals("bread") || heldPath.equals("carrot") || heldPath.equals("potato") || heldPath.equals("beetroot"))
            && (v.isBaby() || player.isShiftKeyDown())) {
            String[] g = v.isBaby() ? VnItemRules.FOOD_BABY.get(heldPath) : VnItemRules.FOOD_ADULT.get(heldPath);
            if (g == null && !v.isBaby()) {
               g = VnItemRules.FOOD_ADULT.get("any");
            }

            VnTriggers.react(v, g);
            return InteractionResult.PASS;
         }

         String prof = profession(v);
         if (v.isBaby()) {
            VnTriggers.react(v, EVENTS.get("babyTrade"));
         } else if (prof.equals("nitwit")) {
            VnTriggers.react(v, EVENTS.get("nitwitTrade"));
         } else if (prof.equals("none")) {
            VnTriggers.react(v, EVENTS.get("unemployedTrade"));
         }

         return InteractionResult.PASS;
      });
      ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
         if (!(screen instanceof MerchantScreen) || !VillagerNews.enabled()) {
            return;
         }

         Entity target = client.crosshairPickEntity;
         tradingWith = target instanceof Villager ? target : null;
         emeraldsAtOpen = countEmeralds(client);
         if (tradingWith instanceof LivingEntity v) {
            VnTriggers.react(v, EVENTS.get("openTrade"));
         }

         ScreenEvents.remove(screen).register(closed -> {
            if (tradingWith instanceof LivingEntity v) {
               boolean bought = countEmeralds(client) != emeraldsAtOpen;
               VnTriggers.react(v, EVENTS.get(bought ? "closeBought" : "closeNot"));
            }

            tradingWith = null;
         });
      });
   }

   public static String profession(Villager v) {
      String name = v.getVillagerData().profession().getRegisteredName();
      return name.substring(name.indexOf(':') + 1);
   }

   private static int countEmeralds(Minecraft mc) {
      if (mc.player == null) {
         return 0;
      }

      int total = 0;
      for (int i = 0; i < mc.player.getInventory().getContainerSize(); i++) {
         ItemStack s = mc.player.getInventory().getItem(i);
         if (!s.isEmpty() && BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().equals("emerald")) {
            total += s.getCount();
         }
      }

      return total;
   }

   private static String[] match(List<Rule> rules, String path) {
      for (Rule r : rules) {
         if (r.test(path)) {
            return r.groups();
         }
      }

      return null;
   }

   private static void react(Minecraft mc, BlockPos pos, String[] groups) {
      if (groups == null || mc.level == null) {
         return;
      }

      LivingEntity best = null;
      double bestDist = 14.0 * 14.0;
      for (Entity e : mc.level.getEntities((Entity)null, mc.player.getBoundingBox().inflate(14.0), x -> x instanceof Villager)) {
         double d = e.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
         if (d < bestDist && e instanceof LivingEntity le && !le.isBaby() && le.hasLineOfSight(mc.player)) {
            best = le;
            bestDist = d;
         }
      }

      if (best != null) {
         VnTriggers.react(best, groups);
      }
   }

   private static String[] ids(JsonElement e) {
      JsonArray a = e.getAsJsonArray();
      String[] r = new String[a.size()];
      for (int i = 0; i < r.length; i++) {
         r[i] = a.get(i).getAsString();
      }

      return r;
   }

   private static void rules(JsonObject root, String key, List<Rule> into) {
      for (JsonElement e : root.getAsJsonArray(key)) {
         JsonObject o = e.getAsJsonObject();
         into.add(new Rule(o.get("m").getAsString(), ids(o.get("g"))));
      }
   }

   private static void load() {
      try (InputStream in = VnActions.class.getResourceAsStream("/assets/ans/vn/actions.json");
         Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
         JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
         rules(root, "use", USE);
         rules(root, "place", PLACE);
         rules(root, "break", BREAK);
         for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("work").entrySet()) {
            WORK.put(e.getKey(), ids(e.getValue()));
         }

         for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("events").entrySet()) {
            if (e.getValue().isJsonArray()) {
               EVENTS.put(e.getKey(), ids(e.getValue()));
            }
         }

         for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("cast").entrySet()) {
            CAST_MEET.put(e.getKey(), ids(e.getValue().getAsJsonObject().get("meet")));
         }

         for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("speakers").entrySet()) {
            SPEAKERS.put(e.getKey(), ids(e.getValue()));
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News action rules could not be loaded: {}", ex.toString());
      }

      try (InputStream in = VnActions.class.getResourceAsStream("/assets/ans/vn/more.json");
         Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
         JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
         for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("events").entrySet()) {
            EVENTS.put(e.getKey(), ids(e.getValue()));
         }

         rules(root, "attack", ATTACK);
         attackDefault = ids(root.get("attackDefault"));
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News extra rules could not be loaded: {}", ex.toString());
      }
   }
}
