package com.ans.vn.item;

import java.util.List;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Server side: putting Villager News items on villagers, taking noses, signs and food. */
public final class VnVillagerItems {
   public static final List<String> SIGNS = List.of(
      "oak_sign", "spruce_sign", "birch_sign", "jungle_sign", "acacia_sign", "dark_oak_sign",
      "mangrove_sign", "cherry_sign", "pale_oak_sign", "bamboo_sign", "crimson_sign", "warped_sign"
   );
   private static final List<String> FOODS = List.of("bread", "carrot", "potato", "beetroot");

   private VnVillagerItems() {
   }

   public static boolean noseless(Villager v) {
      return v.getItemBySlot(EquipmentSlot.OFFHAND).is(VnItems.VILLAGER_NOSE);
   }

   private static void consume(Player player, ItemStack stack) {
      if (!player.getAbilities().instabuild) {
         stack.shrink(1);
      }
   }

   public static void register() {
      UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
         if (!(level instanceof ServerLevel) || !(entity instanceof Villager v) || player.isSpectator()) {
            return InteractionResult.PASS;
         }

         ItemStack stack = player.getItemInHand(hand);
         Item item = stack.getItem();
         String path = BuiltInRegistries.ITEM.getKey(item).getPath();
         boolean sneak = player.isShiftKeyDown();
         if (item == VnItems.MAYOR_HAT || item == VnItems.MOUSTACHE || item == VnItems.TESTIFICATE_HELMET) {
            if (!v.getItemBySlot(EquipmentSlot.HEAD).isEmpty()) {
               return InteractionResult.SUCCESS;
            }

            v.setItemSlot(EquipmentSlot.HEAD, stack.copyWithCount(1));
            consume(player, stack);
            return InteractionResult.SUCCESS;
         }

         if (item == VnItems.MICROPHONE) {
            if (v.getItemBySlot(EquipmentSlot.MAINHAND).isEmpty()) {
               v.setItemSlot(EquipmentSlot.MAINHAND, stack.copyWithCount(1));
               consume(player, stack);
            }

            return InteractionResult.SUCCESS;
         }

         if (item == VnItems.VILLAGER_NOSE) {
            if (noseless(v)) {
               v.setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
               consume(player, stack);
            }

            return InteractionResult.SUCCESS;
         }

         if (sneak && path.equals("shears") && !noseless(v) && hand == InteractionHand.MAIN_HAND) {
            v.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(VnItems.VILLAGER_NOSE));
            player.addItem(new ItemStack(VnItems.VILLAGER_NOSE));
            stack.setDamageValue(stack.getDamageValue() + 1);
            if (stack.getDamageValue() >= stack.getMaxDamage()) {
               stack.shrink(1);
            }

            return InteractionResult.SUCCESS;
         }

         if (sneak && SIGNS.contains(path) && v.getItemBySlot(EquipmentSlot.MAINHAND).isEmpty()) {
            v.setItemSlot(EquipmentSlot.MAINHAND, stack.copyWithCount(1));
            consume(player, stack);
            return InteractionResult.SUCCESS;
         }

         if (sneak && stack.isEmpty() && hand == InteractionHand.MAIN_HAND) {
            ItemStack head = v.getItemBySlot(EquipmentSlot.HEAD);
            ItemStack main = v.getItemBySlot(EquipmentSlot.MAINHAND);
            if (VnItems.isVn(head)) {
               player.addItem(head.copy());
               v.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
               return InteractionResult.SUCCESS;
            }

            if (!main.isEmpty() && (VnItems.isVn(main) || SIGNS.contains(BuiltInRegistries.ITEM.getKey(main.getItem()).getPath()))) {
               player.addItem(main.copy());
               v.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
               return InteractionResult.SUCCESS;
            }
         }

         if (FOODS.contains(path) && (v.isBaby() || sneak)) {
            v.getInventory().addItem(stack.copyWithCount(1));
            consume(player, stack);
            return InteractionResult.SUCCESS;
         }

         return InteractionResult.PASS;
      });
   }
}
