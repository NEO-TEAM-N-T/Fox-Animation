package com.ans.vn.item;

import net.fabricmc.api.ModInitializer;

/** Runs on both the client and the server: registers the Villager News items. */
public class VnCommon implements ModInitializer {
   @Override
   public void onInitialize() {
      VnItems.register();
      VnVillagerItems.register();
   }
}
