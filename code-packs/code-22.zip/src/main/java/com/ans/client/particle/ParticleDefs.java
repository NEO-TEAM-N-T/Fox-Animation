package com.ans.client.particle;

import com.ans.Ans;
import com.ans.client.molang.PackSettings;
import com.ans.client.bedrock.AnimationLookup;
import com.ans.client.settings.Experience;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.Reader;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import org.jspecify.annotations.Nullable;

public final class ParticleDefs {
   private static final Map<String, Optional<ParticleDef>> CACHE = new HashMap<>();
   private static int seenGeneration = -1;
   private static String seenExperience = "";

   private ParticleDefs() {
   }

   public static synchronized @Nullable ParticleDef get(String identifier) {
      int generation = AnimationLookup.generation();
      String experience = Experience.current();
      if (generation != seenGeneration || !experience.equals(seenExperience)) {
         seenGeneration = generation;
         seenExperience = experience;
         CACHE.clear();
      }

      return CACHE.computeIfAbsent(identifier.toLowerCase(Locale.ROOT), ParticleDefs::load).orElse(null);
   }

   /** The Actions & Stuff 1.13 particle (particle13/) is used when it exists and the 1.13 data setting is on. */
   private static Identifier preferNew(Identifier file, String ns, String name) {
      String setting = PackSettings.value("oreville_ans:a13data");
      if (!setting.isEmpty() && !PackSettings.enabled("oreville_ans:a13data")) {
         return file;
      }

      Identifier alt = Identifier.tryParse("ans:particle13/" + ns + "/" + name + ".json");
      return alt != null && Minecraft.getInstance().getResourceManager().getResource(alt).isPresent() ? alt : file;
   }

   private static Optional<ParticleDef> load(String identifier) {
      int colon = identifier.indexOf(58);
      String ns = colon < 0 ? "minecraft" : identifier.substring(0, colon);
      String name = colon < 0 ? identifier : identifier.substring(colon + 1);
      Identifier file = Identifier.tryParse("ans:particle/" + ns + "/" + name + ".json");
      if (file == null) {
         return Optional.empty();
      }

      file = Experience.resolve(file);
      file = preferNew(file, ns, name);
      Optional<Resource> resource = Minecraft.getInstance().getResourceManager().getResource(file);
      if (resource.isEmpty()) {
         Ans.LOGGER.warn("[ans] particle effect {} is not defined by the pack ({} missing); not emitted", identifier, file);
         return Optional.empty();
      }

      try (Reader reader = resource.get().openAsReader()) {
         JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
         ParticleDef def = new ParticleDef(identifier, root);
         if (!def.unsupported().isEmpty()) {
            Ans.LOGGER.warn("[ans] particle effect {}: unsupported components ignored: {}", identifier, def.unsupported());
         }

         return Optional.of(def);
      } catch (Exception e) {
         Ans.LOGGER.error("[ans] could not read particle effect {}", file, e);
         return Optional.empty();
      }
   }
}
