package com.ans.client.bedrock;

import com.ans.Ans;
import com.ans.client.molang.PackSettings;
import com.ans.client.settings.Experience;
import com.google.gson.JsonParser;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import org.jspecify.annotations.Nullable;

public final class EntityBundles {
   private static final Map<Identifier, Optional<EntityBundle>> CACHE = new HashMap<>();
   private static int seenGeneration = -1;

   private EntityBundles() {
   }

   public static synchronized @Nullable EntityBundle get(String mobId, Identifier file) {
      int generation = AnimationLookup.generation();
      if (generation != seenGeneration) {
         seenGeneration = generation;
         CACHE.clear();
         PackSettings.invalidate();
      }

      Identifier resolved = preferNew(Experience.resolve(file));
      return CACHE.computeIfAbsent(resolved, f -> Optional.ofNullable(load(mobId, f))).orElse(null);
   }

   /**
    * The Actions & Stuff 1.13 bundles live next to the older ones in entity13/. A mob uses its 1.13 bundle when it has
    * one and the "Actions & Stuff 1.13 data" setting is on; otherwise it keeps its older bundle.
    */
   private static Identifier preferNew(Identifier file) {
      if (!file.getNamespace().equals("ans") || !file.getPath().startsWith("entity/")) {
         return file;
      }

      String setting = PackSettings.value("oreville_ans:a13data");
      if (!setting.isEmpty() && !PackSettings.enabled("oreville_ans:a13data")) {
         return file;
      }

      Identifier alt = Ans.id("entity13/" + file.getPath().substring("entity/".length()));
      return Minecraft.getInstance().getResourceManager().getResource(alt).isPresent() ? alt : file;
   }

   private static @Nullable EntityBundle load(String mobId, Identifier file) {
      Optional<Resource> resource = Minecraft.getInstance().getResourceManager().getResource(file);
      if (resource.isEmpty()) {
         Ans.LOGGER.error("[ans] Entity bundle {} not found: run the converter (actions-and-stuff/work/converter) for '{}'", file, mobId);
         return null;
      }

      try (Reader reader = resource.get().openAsReader()) {
         EntityBundle bundle = EntityBundle.parse(mobId, JsonParser.parseReader(reader).getAsJsonObject(), file.toString());
         Ans.LOGGER
            .info(
               "[ans] Loaded {}: {} animations, {} controllers, {} render controllers",
               new Object[]{file, bundle.animations.size(), bundle.controllers.size(), bundle.renderControllers.size()}
            );
         return bundle;
      } catch (Exception e) {
         Ans.LOGGER.error("[ans] Could not read entity bundle {}", file, e);
         return null;
      }
   }
}
