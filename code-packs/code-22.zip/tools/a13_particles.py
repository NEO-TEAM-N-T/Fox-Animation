#!/usr/bin/env python3
"""Actions & Stuff 1.13 particles -> side-by-side mod data (assets/ans/particle13/<namespace>/<name>.json).

usage: a13_particles.py <extracted resource pack> <output folder>
The engine reads the Bedrock components, curves and events as they are; the texture and the blend mode are lifted to the top.
"""
import glob, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bedrock_to_bundle import Pack, jload


def main():
    root, out = sys.argv[1], sys.argv[2]
    from PIL import Image
    pack = Pack(root)
    n = missing = 0
    missing_tex = set()
    for f in sorted(glob.glob(root + '/particles/*.json')):
        try:
            p = jload(f)['particle_effect']
        except Exception:
            continue
        desc = p['description']
        ident = desc['identifier']
        ns, name = ident.split(':', 1) if ':' in ident else ('minecraft', ident)
        brp = desc.get('basic_render_parameters', {})
        mat = pack.mat.get(brp.get('material', ''), brp.get('material', '')).lower()
        render = 'blend' if 'blend' in mat else 'add' if 'add' in mat else 'opaque' if 'opaque' in mat else 'alpha'
        tex = None
        t = brp.get('texture')
        if t:
            src = next((root + '/' + t + e for e in ('.png', '.tga') if os.path.exists(root + '/' + t + e)), None)
            if src and os.path.getsize(src) > 0:
                dst = f'{out}/assets/ans/{t}.png'
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                Image.open(src).convert('RGBA').save(dst)
                tex = f'ans:{t}.png'
            else:
                # a vanilla Bedrock texture that Java does not have under that name: keep the older particle file
                missing += 1
                missing_tex.add(t)
                continue
        data = {'identifier': ident, 'texture': tex, 'render': render, 'components': p.get('components', {})}
        if 'curves' in p:
            data['curves'] = p['curves']
        if 'events' in p:
            data['events'] = p['events']
        dst = f'{out}/assets/ans/particle13/{ns}/{name}.json'
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        json.dump(data, open(dst, 'w'), separators=(',', ':'))
        n += 1
    print(n, 'particles written;', missing, 'skipped because their texture is a vanilla Bedrock one:', sorted(missing_tex))


if __name__ == '__main__':
    main()
