#!/usr/bin/env python3
"""Extract Bedrock .brarchive files: magic(8) count(u32) version(u32), then count records of 256 bytes
[nameLen u8][name][...][offset u32 @248][length u32 @252], then the data."""
import os, struct, sys
MAGIC = bytes.fromhex('7d2725b1a0527026')

def extract(path, out):
    b = open(path, 'rb').read()
    assert b[:8] == MAGIC, path
    count, ver = struct.unpack('<II', b[8:16])
    start = 16 + count * 256
    n = 0
    for i in range(count):
        rec = 16 + i * 256
        ln = b[rec]
        name = b[rec + 1: rec + 1 + ln].decode('utf-8', 'replace')
        off, size = struct.unpack('<II', b[rec + 248: rec + 256])
        data = b[start + off: start + off + size]
        dst = os.path.join(out, name)
        os.makedirs(os.path.dirname(dst) or '.', exist_ok=True)
        open(dst, 'wb').write(data)
        n += 1
    return n

def walk(root):
    total = 0
    for dp, dn, fn in os.walk(root):
        for f in fn:
            if f.endswith('.brarchive'):
                p = os.path.join(dp, f)
                rel = os.path.relpath(p, root)           # __brarchive/sounds/oreville.brarchive
                parts = rel.split(os.sep)
                # strip the __brarchive component wherever it is
                parts = [x for x in parts if x != '__brarchive']
                parts[-1] = parts[-1][:-len('.brarchive')]
                # the archive name (last part) is the folder, e.g. entity.brarchive -> entity/
                # subpack roots keep their own prefix
                base = os.sep.join(parts[:-1])
                out = os.path.join(root, base, parts[-1]) if base else os.path.join(root, parts[-1])
                total += extract(p, out)
    return total

if __name__ == '__main__':
    print(walk(sys.argv[1]), 'files extracted')
