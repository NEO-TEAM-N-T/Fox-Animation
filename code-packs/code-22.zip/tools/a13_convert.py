#!/usr/bin/env python3
"""Actions & Stuff 1.13 (extracted with brar.py) -> side-by-side mod data, our own converter.

usage: a13_convert.py <extracted resource pack> <output folder>

For every client entity whose animations, geometry, render controllers and textures are all inside the pack it writes
  assets/ans/entity13/<java id>.json              the bundle (the engine prefers it over entity/<id>.json)
  assets/ans/geckolib/models/entity/a13_*.geo.json
  assets/ans/geckolib/animations/entity/a13_*.animation.json
  assets/ans/textures/...png                      the textures it uses (tga converted)
Entities that need vanilla Bedrock resources which are not in the pack are listed and skipped.
"""
import glob, json, os, shutil, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bedrock_to_bundle import Pack, convert, jload

SPECIAL = {'villager_v2': 'villager', 'zombie_villager_v2': 'zombie_villager', 'tropicalfish': 'tropical_fish',
           'zombie_pigman': 'zombified_piglin', 'evocation_illager': 'evoker', 'evocation_fang': 'evoker_fangs',
           'ender_crystal': 'end_crystal', 'eye_of_ender_signal': 'eye_of_ender', 'fireworks_rocket': 'firework_rocket',
           'fishing_hook': 'fishing_bobber', 'thrown_trident': 'trident', 'xp_bottle': 'experience_bottle',
           'xp_orb': 'experience_orb', 'wind_charge_projectile': 'wind_charge'}


def main():
    root, out = sys.argv[1], sys.argv[2]
    from PIL import Image
    pack = Pack(root)
    tmp = tempfile.mkdtemp()
    kept, skipped = [], []
    def version(d):
        try:
            return tuple(int(x) for x in str(d.get('min_engine_version') or '0').split('.'))
        except ValueError:
            return (0,)

    # an identifier can be defined several times; the game uses the one with the highest min_engine_version
    chosen = {}
    for f in sorted(glob.glob(root + '/entity/*.json')):
        try:
            d = jload(f)['minecraft:client_entity']['description']
        except Exception:
            continue
        jid = SPECIAL.get(d['identifier'].split(':')[1], d['identifier'].split(':')[1])
        if jid not in chosen or version(d) > chosen[jid][0]:
            chosen[jid] = (version(d), f)
    for jid, (_, f) in sorted(chosen.items()):
        d = jload(f)['minecraft:client_entity']['description']
        ident = d['identifier']
        name = 'a13_' + jid
        bundle, rep = convert(pack, f, name, ident, tmp)
        bad = [k for k, v in rep.items() if v and k != 'geo_files']
        if bad:
            skipped.append((jid, bad))
            continue
        kept.append(jid)
        os.makedirs(out + '/assets/ans/entity13', exist_ok=True)
        shutil.move(f'{tmp}/assets/ans/entity/{name}.json', f'{out}/assets/ans/entity13/{jid}.json')
        for kind, ext in (('models', 'geo.json'), ('animations', 'animation.json')):
            os.makedirs(f'{out}/assets/ans/geckolib/{kind}/entity', exist_ok=True)
        for g in glob.glob(f'{tmp}/assets/ans/geckolib/models/entity/{name}_*.geo.json'):
            shutil.move(g, f'{out}/assets/ans/geckolib/models/entity/' + os.path.basename(g))
        shutil.move(f'{tmp}/assets/ans/geckolib/animations/entity/{name}.animation.json',
                    f'{out}/assets/ans/geckolib/animations/entity/{name}.animation.json')
        for t in bundle['textures'].values():
            if not t.startswith('ans:'):
                continue
            rel = t.split(':', 1)[1][:-4]
            src = next((root + '/' + rel + e for e in ('.png', '.tga') if os.path.exists(root + '/' + rel + e)), None)
            dst = f'{out}/assets/ans/{rel}.png'
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            Image.open(src).convert('RGBA').save(dst)
    shutil.rmtree(tmp)
    print(len(kept), 'entities written;', len(skipped), 'skipped (need vanilla Bedrock resources):')
    for jid, bad in skipped:
        print(' ', jid, bad)


if __name__ == '__main__':
    main()
