package com.ans.client.vn;

import com.ans.Ans;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;

/** Timed subtitles for spoken lines. Shown in the action bar when the game offers it, otherwise in chat. */
public final class VnSubtitles {
   private record Line(long showAt, String key) {
   }

   private static final List<Line> PENDING = new ArrayList<>();
   private static Method method;
   private static Object target;
   private static int mode;
   private static boolean resolved;

   private VnSubtitles() {
   }

   public static synchronized void show(Entity speaker, double[] times, String[] textKeys) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level == null) {
         return;
      }

      long now = mc.level.getGameTime();
      PENDING.clear();
      for (int i = 0; i < textKeys.length; i++) {
         PENDING.add(new Line(now + Math.round(times[i] * 20.0), textKeys[i]));
      }
   }

   public static synchronized void tick(Minecraft mc) {
      if (mc.level == null || mc.player == null || PENDING.isEmpty()) {
         return;
      }

      long now = mc.level.getGameTime();
      Iterator<Line> it = PENDING.iterator();
      while (it.hasNext()) {
         Line l = it.next();
         if (l.showAt() <= now) {
            display(mc, Component.translatable(l.key()));
            it.remove();
         }
      }
   }

   private static void display(Minecraft mc, Component text) {
      if (!resolved) {
         resolved = true;
         resolve(mc);
      }

      if (method == null) {
         return;
      }

      try {
         switch (mode) {
            case 1 -> method.invoke(target, text, Boolean.FALSE);
            case 2 -> method.invoke(target, text, Boolean.TRUE);
            default -> method.invoke(target, text);
         }
      } catch (ReflectiveOperationException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Subtitle display failed: {}", ex.toString());
         method = null;
      }
   }

   private static void resolve(Minecraft mc) {
      Object[][] candidates = {
         {mc.gui, "setOverlayMessage", 1},
         {mc.player, "displayClientMessage", 2},
         {mc.player, "sendOverlayMessage", 0},
         {mc.player, "sendSystemMessage", 0}
      };
      for (Object[] c : candidates) {
         int m = (Integer)c[2];
         try {
            method = c[0].getClass().getMethod((String)c[1], m == 0 ? new Class<?>[]{Component.class} : new Class<?>[]{Component.class, boolean.class});
            target = c[0];
            mode = m;
            Ans.LOGGER.info("[ans] Villager News subtitles use {}", c[1]);
            return;
         } catch (NoSuchMethodException ignored) {
            // try the next candidate
         }
      }

      Ans.LOGGER.warn("[ans] No way found to show Villager News subtitles");
   }
}
