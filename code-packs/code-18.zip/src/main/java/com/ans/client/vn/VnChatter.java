package com.ans.client.vn;

import com.ans.client.molang.PackSettings;
import java.util.Random;

/** The chattiness and rare voice line settings, with the same rules as the original add-on. */
public final class VnChatter {
   public static final String CHATTER_SETTING = "oreville_ans:vnchatter";
   public static final String RARE_SETTING = "oreville_ans:vnrare";
   public static final String SPECIAL_SETTING = "oreville_ans:vnspecial";
   private static final Random RANDOM = new Random();

   private VnChatter() {
   }

   /** Muted 0, Shy 0.5, Chatty 1 (default), Super Chatty 5. */
   public static double multiplier() {
      return switch (PackSettings.value(CHATTER_SETTING)) {
         case "muted" -> 0.0;
         case "shy" -> 0.5;
         case "super_chatty" -> 5.0;
         default -> 1.0;
      };
   }

   /** Whether a villager may speak this time: always when chatty, half of the time when shy, never when muted. */
   public static boolean pass() {
      double m = multiplier();
      return m >= 1.0 || m > 0.0 && RANDOM.nextDouble() < m;
   }

   /** Scales a waiting time: shy waits twice as long, super chatty a fifth of the time, muted practically forever. */
   public static long delay(long ticks) {
      double m = multiplier();
      return m <= 0.0 ? Long.MAX_VALUE / 4L : Math.max(1L, Math.round(ticks / m));
   }

   /**
    * Weight of a line in its group: normally the line's own weight; with rare lines "often" the weights are turned
    * upside down; with "never" only lines close to the group's most common weight are kept.
    */
   public static double weight(double w, double lowest, double highest) {
      return switch (PackSettings.value(RARE_SETTING)) {
         case "often" -> highest + lowest - w;
         case "never" -> w >= 0.8 * highest ? w : 0.0;
         default -> w;
      };
   }

   /** Special villagers may spawn in new villages (default on). */
   public static boolean specialsEnabled() {
      String v = PackSettings.value(SPECIAL_SETTING);
      return v.isEmpty() || PackSettings.enabled(SPECIAL_SETTING);
   }
}
