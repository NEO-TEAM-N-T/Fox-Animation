package com.ans.client.vn;

import com.ans.Ans;
import com.ans.client.mob.groups.VillagerNews;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Iterator;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.phys.AABB;

/** Situations that make Villager News villagers speak. All of them are detected on the client. */
public final class VnTriggers {
   private static final String APPROACH = "xfpjxq";
   private static final String MORNING = "zkoewx";
   private static final String AFTERNOON = "kopthx";
   private static final String EVENING = "qknpqr";
   private static final String NIGHT = "sotbtt";
   private static final String GO_TO_BED = "ioxtmt";
   private static final String ATTACKED = "rueszy";

   private static final class Rule {
      String kind;
      String path;
      String flag;
      String effect;
      boolean baby;
      int day;
      int month;
      double lt = Double.NaN;
      double gt = Double.NaN;
      int n;
      double r;
      String has;
      String[] paths;
      String[] groups;
   }

   private static final class State {
      long lastSpoke = -100000L;
      long nextIdle = -1L;
      boolean near;
      boolean wasSleeping;
      int lastHurt;
      String profession;
      int level = -1;
      boolean wasBaby;
      boolean seen;
      double lastX;
      double lastZ;
      String cosmetic = "none";
      boolean noseless;
      int sign = -1;
      boolean eatingBefore;
   }

   private static final Map<Entity, State> STATES = new WeakHashMap<>();
   private static final List<Rule> RULES = new ArrayList<>();
   private static final Random RANDOM = new Random();
   private static final Set<String> MOB_PATHS = new HashSet<>();
   private static final List<Object[]> LATER = new ArrayList<>();
   private static boolean installed;
   private static double lastPx;
   private static double lastPz;
   private static long stillSince;
   private static boolean wasCreative;
   private static boolean wasDying;
   private static boolean eatingNow;
   private static int deaths;
   private static String lastDifficulty;
   private static double lastPy;

   private VnTriggers() {
   }

   public static synchronized void install() {
      if (installed) {
         return;
      }

      installed = true;
      VnSpeech.install();
      loadRules();
      VnItemRules.load();
      VnActions.install();
      VnHandbook.install();
      VnNetClient.install();
      VnSubtitleBox.install();
      com.ans.vn.net.VnSpecials.enabled = VnChatter::specialsEnabled;
      ClientTickEvents.END_CLIENT_TICK.register(VnTriggers::tick);
   }

   private static void loadRules() {
      try (InputStream in = VnTriggers.class.getResourceAsStream("/assets/ans/vn/triggers.json");
         Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
         for (JsonElement e : JsonParser.parseReader(r).getAsJsonObject().getAsJsonArray("rules")) {
            readRule(e.getAsJsonObject());
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News trigger rules could not be loaded: {}", ex.toString());
      }

      loadMore();
      for (Rule r : RULES) {
         if (r.kind.equals("mob") && r.path != null) {
            MOB_PATHS.add(r.path);
         }
      }

      Ans.LOGGER.info("[ans] Villager News: {} situation rules", RULES.size());
   }

   /** More situation rules (more2.json) in the same format as triggers.json. */
   private static void loadMore() {
      try (InputStream in = VnTriggers.class.getResourceAsStream("/assets/ans/vn/more2.json");
         Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
         JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
         if (root.has("rules")) {
            for (JsonElement e : root.getAsJsonArray("rules")) {
               readRule(e.getAsJsonObject());
            }
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News extra situation rules could not be loaded: {}", ex.toString());
      }
   }

   public static boolean hasMobRule(String path) {
      return MOB_PATHS.contains(path);
   }

   /** Runs something a number of ticks later (on the client thread). */
   public static void later(long ticks, Runnable task) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null) {
         LATER.add(new Object[]{mc.level.getGameTime() + ticks, task});
      }
   }

   private static void runLater(long now) {
      Iterator<Object[]> it = LATER.iterator();
      List<Runnable> due = new ArrayList<>();
      while (it.hasNext()) {
         Object[] t = it.next();
         if ((Long)t[0] <= now) {
            due.add((Runnable)t[1]);
            it.remove();
         }
      }

      for (Runnable r : due) {
         try {
            r.run();
         } catch (RuntimeException ex) {
            Ans.LOGGER.warn("[ans] Villager News delayed task failed: {}", ex.toString());
         }
      }
   }

   /** Speaks a line right now, even if the villager is asleep or dying (sleep talk, last words). */
   public static void speakNow(LivingEntity v, String[] groups) {
      if (groups == null || groups.length == 0 || !VillagerNews.enabled() || !VnChatter.pass()) {
         return;
      }

      String g = groups[RANDOM.nextInt(groups.length)];
      if (VnSpeech.hasGroup(g) && !VnSpeech.isSpeaking(v)) {
         VnSpeech.say(v, g);
         State st = STATES.computeIfAbsent(v, k -> new State());
         st.lastSpoke = v.level().getGameTime();
      }
   }

   private static void readRule(JsonObject o) {
      Rule rule = new Rule();
      rule.kind = o.get("k").getAsString();
      rule.path = str(o, "path");
      rule.flag = str(o, "flag");
      rule.effect = str(o, "e");
      rule.has = str(o, "has");
      rule.baby = o.has("baby") && o.get("baby").getAsBoolean();
      rule.day = o.has("d") ? o.get("d").getAsInt() : 0;
      rule.month = o.has("m") ? o.get("m").getAsInt() : 0;
      rule.n = o.has("n") ? o.get("n").getAsInt() : 0;
      rule.r = o.has("r") ? o.get("r").getAsDouble() : 0.0;
      if (o.has("lt")) {
         rule.lt = o.get("lt").getAsDouble();
      }

      if (o.has("gt")) {
         rule.gt = o.get("gt").getAsDouble();
      }

      if (o.has("paths")) {
         JsonArray a = o.getAsJsonArray("paths");
         rule.paths = new String[a.size()];
         for (int i = 0; i < a.size(); i++) {
            rule.paths[i] = a.get(i).getAsString();
         }
      }

      JsonArray g = o.getAsJsonArray("g");
      rule.groups = new String[g.size()];
      for (int i = 0; i < g.size(); i++) {
         rule.groups[i] = g.get(i).getAsString();
      }
      RULES.add(rule);
   }

   private static String str(JsonObject o, String k) {
      return o.has(k) ? o.get(k).getAsString() : null;
   }

   private static void tick(Minecraft mc) {
      if (mc.level == null || mc.player == null || mc.isPaused() || !VillagerNews.enabled()) {
         return;
      }

      VnSubtitles.tick(mc);
      long now = mc.level.getGameTime();
      runLater(now);
      VnHandbook.tick(mc);
      VnWatch.tick(mc, now);
      double px = mc.player.getX();
      double pz = mc.player.getZ();
      if (Math.abs(px - lastPx) > 0.02 || Math.abs(pz - lastPz) > 0.02) {
         stillSince = now;
      }

      watchPlayer(mc, px, mc.player.getY(), pz);
      lastPx = px;
      lastPz = pz;
      AABB box = mc.player.getBoundingBox().inflate(12.0);
      List<Entity> found = mc.level.getEntities(
         (Entity)null, box, e -> e.getType() == EntityTypes.VILLAGER || e.getType() == EntityTypes.WANDERING_TRADER
            || (e.getType() == EntityTypes.SHEEP && VillagerNews.isWooly(e))
      );
      for (Entity e : found) {
         if (!(e instanceof LivingEntity v)) {
            continue;
         }

         State st = STATES.computeIfAbsent(e, k -> new State());
         double dist = v.distanceTo(mc.player);
         boolean wooly = e.getType() == EntityTypes.SHEEP;
         boolean trader = e.getType() == EntityTypes.WANDERING_TRADER || wooly;
         if (e instanceof Villager vil) {
            watchChanges(vil, st, now, dist);
         }

         if (v.isBaby()) {
            double speed = Math.hypot(v.getX() - st.lastX, v.getZ() - st.lastZ);
            st.lastX = v.getX();
            st.lastZ = v.getZ();
            if (speed > 0.12 && dist < 10 && now >= st.nextIdle) {
               st.nextIdle = now + VnChatter.delay(20L * (20 + RANDOM.nextInt(30)));
               boolean weekend = LocalDate.now().getDayOfWeek().getValue() >= 6;
               String[] g = weekend && RANDOM.nextBoolean() ? VnActions.events("babySprintWeekend") : VnActions.events("babySprint");
               react(v, g);
            } else if (st.nextIdle < 0) {
               st.nextIdle = now + VnChatter.delay(20L * (5 + RANDOM.nextInt(15)));
            }

            continue;
         }

         String cast = VillagerNews.cast(e);
         if (st.nextIdle < 0) {
            st.nextIdle = now + VnChatter.delay(20L * (10 + RANDOM.nextInt(30)));
         }

         boolean sleeping = v.isSleeping();
         if (sleeping && !st.wasSleeping && dist < 16 && !trader) {
            speak(v, st, now, GO_TO_BED);
         }

         st.wasSleeping = sleeping;
         if (sleeping) {
            continue;
         }

         if (v.hurtTime > 0 && st.lastHurt == 0 && dist < 8 && !trader && !VnActions.recentAttack(e, now)) {
            react(v, VnActions.events("villagerHurt"));
         }

         st.lastHurt = v.hurtTime;
         if (dist < 3.5 && !st.near && now - st.lastSpoke > 400L) {
            st.near = true;
            String[] meet = cast != null ? VnActions.castMeet(cast) : null;
            String[] special = trader ? null : VnWatch.approach(mc, v);
            if (special != null && RANDOM.nextInt(100) < 75) {
               speak(v, st, now, special[RANDOM.nextInt(special.length)]);
            } else if (meet != null) {
               speak(v, st, now, meet[RANDOM.nextInt(meet.length)]);
            } else if (!trader) {
               speak(v, st, now, APPROACH);
            }
         } else if (dist > 6.0) {
            st.near = false;
         }

         if (dist < 8.0 && now >= st.nextIdle) {
            st.nextIdle = now + VnChatter.delay(20L * (30 + RANDOM.nextInt(50)));
            boolean talked = !trader && VnChatter.pass() && VnConversations.idle(mc, v, now);
            String[] tSit = trader && !wooly && RANDOM.nextInt(3) == 0 ? VnWatch.traderSituation(mc, v) : null;
            String group = talked
               ? null
               : tSit != null
                  ? tSit[RANDOM.nextInt(tSit.length)]
                  : trader ? chooseSpeaker(wooly ? "wooly" : "wandering_trader") : chooseSituation(mc, v, now, cast);
            if (group != null) {
               speak(v, st, now, group);
            }
         }
      }
   }

   /** Reactions to things the player does that are not tied to a block or a mob. */
   private static void watchPlayer(Minecraft mc, double px, double py, double pz) {
      boolean creative = mc.gameMode != null && mc.gameMode.getPlayerMode().isCreative();
      if (creative && !wasCreative && lastDifficulty != null) {
         VnActions.reactNearPlayer(mc, VnActions.events("creative"));
      }

      wasCreative = creative;
      String diff = mc.level.getDifficulty().name();
      if (lastDifficulty != null && !diff.equals(lastDifficulty)) {
         String key = diff.equals("HARD") ? "diffHard" : diff.equals("PEACEFUL") ? "diffPeaceful" : "diffChange";
         VnActions.reactNearPlayer(mc, VnActions.events(key));
      }

      lastDifficulty = diff;
      boolean dying = mc.player.isDeadOrDying();
      if (dying && !wasDying) {
         deaths++;
         boolean hardcore = mc.level.getLevelData().isHardcore();
         VnActions.reactNearPlayer(mc, VnActions.events(hardcore ? "playerDiesHardcore" : deaths > 1 ? "playerDiesAgain" : "playerDies"));
      }

      wasDying = dying;
      double jump = Math.sqrt((px - lastPx) * (px - lastPx) + (py - lastPy) * (py - lastPy) + (pz - lastPz) * (pz - lastPz));
      if (jump > 8.0 && jump < 80.0 && !dying && lastPx != 0.0) {
         VnActions.reactNearPlayer(mc, VnActions.events("enderTeleport"));
      }

      boolean eating = mc.player.isUsingItem() && mc.player.getUseItem().has(DataComponents.FOOD);
      if (eating && !eatingNow) {
         VnActions.reactNearPlayer(mc, VnItemRules.list("eat"));
      }

      eatingNow = eating;
      lastPy = py;
   }

   /** Notices a villager getting a job, levelling up or growing up. */
   private static void watchChanges(Villager v, State st, long now, double dist) {
      String prof = VnActions.profession(v);
      int level = v.getVillagerData().level();
      boolean baby = v.isBaby();
      if (st.seen && dist < 16) {
         if (st.wasBaby && !baby) {
            react(v, VnActions.events("growup"));
         } else if ("none".equals(st.profession) && !prof.equals("none") && !prof.equals("nitwit")) {
            react(v, VnActions.events("jobs"));
         } else if (level > st.level && st.level >= 0) {
            react(v, VnActions.events(level >= 5 ? "master" : "levelup"));
         }
      }

      String cosmetic = com.ans.vn.item.VnItems.cosmeticCode(v.getItemBySlot(EquipmentSlot.HEAD));
      if (cosmetic == null) {
         cosmetic = com.ans.vn.item.VnItems.cosmeticCode(v.getItemBySlot(EquipmentSlot.MAINHAND));
      }

      if (cosmetic == null) {
         cosmetic = "none";
      }

      boolean noseless = v.getItemBySlot(EquipmentSlot.OFFHAND).is(com.ans.vn.item.VnItems.VILLAGER_NOSE);
      int sign = com.ans.vn.item.VnVillagerItems.SIGNS.indexOf(
         BuiltInRegistries.ITEM.getKey(v.getItemBySlot(EquipmentSlot.MAINHAND).getItem()).getPath()
      );
      if (st.seen && dist < 16) {
         if (!cosmetic.equals(st.cosmetic)) {
            if ("none".equals(cosmetic)) {
               react(v, VnItemRules.list("remove"));
            } else {
               for (Map.Entry<String, String[][]> c : VnItemRules.COSMETIC.entrySet()) {
                  if (c.getValue()[2][0].equals(cosmetic)) {
                     react(v, baby ? c.getValue()[1] : c.getValue()[0]);
                  }
               }
            }
         } else if (noseless != st.noseless) {
            react(v, VnItemRules.list(noseless ? "noseShear" : "noseGive"));
         } else if (sign != st.sign) {
            react(v, sign >= 0 ? VnItemRules.list("sign") : VnItemRules.list("remove"));
         }
      }

      st.cosmetic = cosmetic;
      st.noseless = noseless;
      st.sign = sign;
      st.profession = prof;
      st.level = level;
      st.wasBaby = baby;
      st.seen = true;
   }

   private static String chooseSpeaker(String speaker) {
      String[] g = VnActions.speakerGroups(speaker);
      return g == null || g.length == 0 ? null : g[RANDOM.nextInt(g.length)];
   }

   /** Speaks one of the lines for a situation (used by the action reactions); false if it was not possible. */
   public static boolean react(LivingEntity v, String[] groups) {
      Minecraft mc = Minecraft.getInstance();
      if (groups == null || groups.length == 0 || mc.level == null || v.isSleeping() || !VillagerNews.enabled()) {
         return false;
      }

      long now = mc.level.getGameTime();
      State st = STATES.computeIfAbsent(v, k -> new State());
      if (now - st.lastSpoke < VnChatter.delay(160L)) {
         return false;
      }

      String g = groups[RANDOM.nextInt(groups.length)];
      if (!VnSpeech.hasGroup(g)) {
         return false;
      }

      speak(v, st, now, g);
      return st.lastSpoke == now;
   }

   /** Picks a line for something that is true right now; falls back to the time-of-day lines. */
   private static String chooseSituation(Minecraft mc, LivingEntity v, long now, String cast) {
      Set<String> seenMobs = new HashSet<>();
      for (Entity o : mc.level.getEntities(v, v.getBoundingBox().inflate(10.0), x -> x != mc.player)) {
         boolean baby = o instanceof LivingEntity l && l.isBaby();
         if ((o.getType() == EntityTypes.VILLAGER && !baby) || !v.hasLineOfSight(o)) {
            continue;
         }

         String path = BuiltInRegistries.ENTITY_TYPE.getKey(o.getType()).getPath();
         seenMobs.add(path + (baby ? "#baby" : ""));
         if (path.contains("boat")) {
            seenMobs.add(o.isInWater() ? "boat#water" : "boat#land");
         }
      }

      List<Rule> matching = new ArrayList<>();
      for (Rule r : RULES) {
         if (matches(r, mc, v, now, seenMobs)) {
            matching.add(r);
         }
      }

      List<String[]> candidates = new ArrayList<>();
      for (Rule r : matching) {
         candidates.add(r.groups);
      }

      if (v instanceof Villager vil) {
         long dayTime = VnClock.timeOfDay(mc.level);
         String[] work = VnActions.workGroups(VnActions.profession(vil));
         if (work != null && dayTime > 2000L && dayTime < 9000L) {
            candidates.add(work);
         }
      }

      if (v instanceof Villager self) {
         boolean selfNoseless = self.getItemBySlot(EquipmentSlot.OFFHAND).is(com.ans.vn.item.VnItems.VILLAGER_NOSE);
         int others = 0;
         boolean cosmeticSeen = false;
         for (Entity o : mc.level.getEntities(v, v.getBoundingBox().inflate(10.0), x -> x instanceof Villager)) {
            Villager ov = (Villager)o;
            if (ov.getItemBySlot(EquipmentSlot.OFFHAND).is(com.ans.vn.item.VnItems.VILLAGER_NOSE)) {
               others++;
            }

            if (com.ans.vn.item.VnItems.isVn(ov.getItemBySlot(EquipmentSlot.HEAD))) {
               cosmeticSeen = true;
            }
         }

         if (selfNoseless) {
            candidates.add(VnItemRules.list("noseless"));
         }

         if (others >= 2) {
            candidates.add(VnItemRules.list("twoNoseless"));
         } else if (others == 1 && !selfNoseless) {
            candidates.add(VnItemRules.list("otherNoseless"));
         }

         if (cosmeticSeen) {
            candidates.add(VnItemRules.list("seeCosmetic"));
         }

         if (self.getItemBySlot(EquipmentSlot.HEAD).is(com.ans.vn.item.VnItems.TESTIFICATE_HELMET)) {
            candidates.add(VnItemRules.list("helmetWorn"));
         }
      }

      if (v instanceof Villager) {
         candidates.addAll(VnWatch.situations(mc, v));
      }

      candidates.removeIf(c -> c == null || c.length == 0);
      if (cast != null) {
         String[] own = VnActions.speakerGroups(cast);
         if (own != null && RANDOM.nextInt(3) != 0) {
            return own[RANDOM.nextInt(own.length)];
         }
      }

      if (!candidates.isEmpty() && RANDOM.nextInt(4) != 0) {
         String[] groups = candidates.get(RANDOM.nextInt(candidates.size()));
         String g = groups[RANDOM.nextInt(groups.length)];
         if (VnSpeech.hasGroup(g)) {
            return g;
         }
      }

      return timeOfDayGroup(VnClock.timeOfDay(mc.level));
   }

   private static boolean matches(Rule r, Minecraft mc, LivingEntity v, long now, Set<String> seenMobs) {
      LocalDate date = LocalDate.now();
      switch (r.kind) {
         case "mob":
            return seenMobs.contains(r.path + (r.baby ? "#baby" : ""));
         case "dow":
            return date.getDayOfWeek().getValue() == r.day;
         case "weekend":
            return date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY;
         case "date":
            return date.getMonthValue() == r.month && date.getDayOfMonth() == r.day;
         case "fri13":
            return date.getDayOfWeek() == DayOfWeek.FRIDAY && date.getDayOfMonth() == 13;
         case "month":
            return date.getMonthValue() == r.month;
         case "hour0":
            return LocalTime.now().getMinute() == 0;
         case "dim":
            return mc.level.dimension().toString().contains(r.has);
         case "y":
            return (!Double.isNaN(r.lt) && v.getY() < r.lt) || (!Double.isNaN(r.gt) && v.getY() > r.gt);
         case "rain":
            return mc.level.isRaining() && mc.level.canSeeSky(v.blockPosition());
         case "effect":
            for (MobEffectInstance inst : mc.player.getActiveEffects()) {
               if (inst.getEffect().getRegisteredName().endsWith(":" + r.effect)) {
                  return true;
               }
            }

            return false;
         case "below":
            String block = BuiltInRegistries.BLOCK.getKey(mc.level.getBlockState(mc.player.blockPosition().below()).getBlock()).getPath();
            for (String p : r.paths) {
               if (p.equals(block)) {
                  return true;
               }
            }

            return false;
         case "player":
            return switch (r.flag) {
               case "crouch" -> mc.player.isShiftKeyDown();
               case "flying" -> mc.player.getAbilities().flying;
               case "elytra" -> mc.player.isFallFlying();
               case "still" -> now - stillSince > 200L;
               default -> false;
            };
         case "head":
            return BuiltInRegistries.ITEM.getKey(mc.player.getItemBySlot(EquipmentSlot.HEAD).getItem()).getPath().equals(r.path);
         case "hand":
            return BuiltInRegistries.ITEM.getKey(mc.player.getMainHandItem().getItem()).getPath().equals(r.path);
         case "vstate":
            return switch (r.flag) {
               case "burning" -> v.isOnFire();
               case "lowhp" -> v.getHealth() <= v.getMaxHealth() * 0.35F;
               default -> false;
            };
         case "boatland":
            return seenMobs.contains("boat#land");
         case "boatwater":
            return seenMobs.contains("boat#water");
         case "armor":
            return armorMatches(mc, r.flag);
         case "broken":
            ItemStack held = mc.player.getMainHandItem();
            return held.isDamageableItem() && held.getDamageValue() >= held.getMaxDamage() * 0.9;
         case "effects":
            return mc.player.getActiveEffects().size() >= r.n;
         case "vehicle":
            return mc.player.getVehicle() != null
               && BuiltInRegistries.ENTITY_TYPE.getKey(mc.player.getVehicle().getType()).getPath().contains(r.has);
         case "shallow":
            return mc.player.isInWater() && !mc.player.isSwimming();
         case "nearblock":
            return nearBlock(mc, r.paths);
         case "crowd":
            return mc.level.getEntities(v, v.getBoundingBox().inflate(r.r), x -> x.getType() == EntityTypes.VILLAGER).size() + 1 >= r.n;
         case "prof":
            return v instanceof Villager vil && VnActions.profession(vil).equals(r.path);
         case "biome":
            return biomeMatches(mc, v, r.paths);
         case "otherdim":
            return !mc.level.dimension().toString().contains("overworld");
         case "pile":
            return mc.level.getEntities(v, v.getBoundingBox().inflate(r.r > 0 ? r.r : 6.0), x -> x instanceof net.minecraft.world.entity.item.ItemEntity).size() >= r.n;
         case "profblock":
            return v instanceof Villager pv && VnActions.profession(pv).equals(r.path) && VnWatch.blockNear(mc, v.blockPosition(), 6, 2, r.has);
         case "always":
            return true;
         case "weekend_baby":
            return false;
         default:
            return false;
      }
   }

   private static boolean biomeMatches(Minecraft mc, LivingEntity v, String[] words) {
      String biome = mc.level.getBiome(v.blockPosition()).unwrapKey().map(k -> k.identifier().getPath()).orElse("");
      for (String w : words) {
         if (biome.contains(w)) {
            return true;
         }
      }

      return false;
   }

   private static boolean armorMatches(Minecraft mc, String flag) {
      EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
      String[] mats = new String[4];
      int worn = 0;
      boolean high = false;
      boolean allIron = true;
      boolean same = true;
      String first = null;
      for (int i = 0; i < 4; i++) {
         ItemStack s = mc.player.getItemBySlot(slots[i]);
         if (s.isEmpty()) {
            allIron = false;
            continue;
         }

         String p = BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
         int us = p.indexOf('_');
         mats[i] = us > 0 ? p.substring(0, us) : p;
         worn++;
         high |= mats[i].equals("diamond") || mats[i].equals("netherite");
         allIron &= mats[i].equals("iron");
         if (first == null) {
            first = mats[i];
         } else if (!first.equals(mats[i])) {
            same = false;
         }
      }

      return switch (flag) {
         case "any" -> worn > 0;
         case "iron" -> worn == 4 && allIron;
         case "mixed" -> worn >= 2 && !same;
         case "high" -> high;
         default -> false;
      };
   }

   private static boolean nearBlock(Minecraft mc, String[] paths) {
      net.minecraft.core.BlockPos base = mc.player.blockPosition();
      for (int dx = -2; dx <= 2; dx++) {
         for (int dy = -1; dy <= 2; dy++) {
            for (int dz = -2; dz <= 2; dz++) {
               String b = BuiltInRegistries.BLOCK.getKey(mc.level.getBlockState(base.offset(dx, dy, dz)).getBlock()).getPath();
               for (String p : paths) {
                  if (b.equals(p)) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   private static String timeOfDayGroup(long t) {
      if (t < 6000L) {
         return MORNING;
      }

      if (t < 11000L) {
         return AFTERNOON;
      }

      return t < 13000L ? EVENING : NIGHT;
   }

   private static void speak(Entity e, State st, long now, String group) {
      if (!VnChatter.pass() || VnSpeech.anyoneSpeaking()) {
         return;
      }

      if (VnSpeech.say(e, group)) {
         st.lastSpoke = now;
      }
   }
}
