package com.ans.client.vn;

import com.ans.Ans;
import com.ans.client.mob.groups.VillagerNews;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.MerchantScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

/**
 * Everyday situations that need watching the world over time: pick ups, damage, panic, sleep, births, cures,
 * time jumps, staring, nudging and more. Everything here is detected on the client.
 */
public final class VnWatch {
   private static final String[] PANIC = {"uzdxum"};
   private static final String[] CALM = {"wbbxpo"};
   private static final String[] CALM_BABY = {"wsxfok"};
   private static final String[] DEATH = {"hivgme"};
   private static final String[] SEE_DEATH = {"pmqrpb"};
   private static final String[] SEE_HURT = {"pkvhpv"};
   private static final String[] BABY_HURT = {"ecslqo"};
   private static final String[] FREED = {"fxbysi"};
   private static final String[] SPLASH = {"hmadgp"};
   private static final String[] POISON = {"onindz"};
   private static final String[] SLOWNESS = {"xemyaj"};
   private static final String[] WEAKNESS = {"yebifs"};
   private static final String[] HARMING = {"gacgtq"};
   private static final String[] WAKE_NATURAL = {"ctptjt"};
   private static final String[] WAKE_PLAYER = {"viwaal"};
   private static final String[] SLEEPING = {"asqzby"};
   private static final String[] START_WORK = {"qawras"};
   private static final String[] NO_BELL = {"trphsn"};
   private static final String[] NO_WORKSTATION = {"ywzhwz"};
   private static final String[] GO_HOME = {"wkfbuv"};
   private static final String[] NO_BED = {"uqguqj"};
   private static final String[] HOME_OTHER = {"uhbigm"};
   private static final String[] HOME_NETHER = {"bvtmmz"};
   private static final String[] HOME_END = {"iubjul"};
   private static final String[] BABY_MEET = {"wtuguc"};
   private static final String[] BABY_HERO = {"fzyrfm"};
   private static final String[] BABY_BAD_REP = {"jfuftm"};
   private static final String[] BABY_GOLEM = {"mqnapy"};
   private static final String[] BABY_CHASE = {"rfnirh"};
   private static final String[] PICK_UP = {"dxmmiu"};
   private static final String[] PICK_ARMOR = {"zjwpzi"};
   private static final String[] PICK_ENCHANTED = {"habfnx"};
   private static final String[] PICK_FROM_PLAYER = {"vkhrme"};
   private static final String[] PICK_FROM_VILLAGER = {"ujyxfg"};
   private static final String[] SHARE_FOOD = {"locuih"};
   private static final String[] RECEIVE_FOOD = {"saxuwk"};
   private static final String[] SPAWN_VILLAGER = {"vskjkl"};
   private static final String[] SPAWN_BABY = {"abfwiv"};
   private static final String[] BORN = {"lgjtnf"};
   private static final String[] HAVE_BABY = {"fbuabj"};
   private static final String[] CURE = {"ivumgm"};
   private static final String[] CURE_BABY = {"ggitzq"};
   private static final String[] TIME_SKIP = {"uqwdqn"};
   private static final String[] TIME_SKIP_BABY = {"durjjd"};
   private static final String[] SUDDEN_DAY = {"mgmzeh"};
   private static final String[] SUDDEN_DAY_BABY = {"wkwcrf"};
   private static final String[] SUDDEN_NIGHT = {"ohdwnz"};
   private static final String[] SUDDEN_NIGHT_BABY = {"msemoe"};
   private static final String[] STARE = {"cavwps"};
   private static final String[] NUDGE = {"ajexrq"};
   private static final String[] NUDGE_BOAT = {"zvbnea"};
   private static final String[] TWO_IN_BOAT = {"zqfvby"};
   private static final String[] FIREWORK = {"dfdkli"};
   private static final String[] GAMEMODE = {"fhhqxg"};
   private static final String[] PLAYER_WAKES = {"bipqej"};
   private static final String[] PLAYER_WAKES_ARMOR = {"hevyeb"};
   private static final String[] TRAMPLE = {"pizztd"};
   private static final String[] TRADE_DONE = {"xmkwxd"};
   private static final String[] TRADE_DONE_TRADER = {"bvrbhy"};
   private static final String[] REFUSE_RAID = {"klabhl"};
   private static final String[] REFUSE_REP = {"lhdgsy"};
   private static final String[] REP_SWORD = {"stuirs"};
   private static final String[][] APPROACH_REP = {{"zstdjn"}, {"tfzlsw"}, null, {"omgcte"}, {"kcbenk"}};
   private static final String[][] TRADE_REP = {{"xduuwm"}, {"qmdvft"}, null, {"kuhvdv"}, {"vlrsrn"}};
   private static final String[] BAD_OMEN = {"jlendb"};
   private static final String[] HERO = {"gnetsk"};
   private static final String[] RAIN_TRADER = {"kxoqky"};
   private static final String[] INVISIBLE_TRADER = {"dbzjqi"};
   private static final String[] POTION_TRADER = {"vggdrt"};
   private static final String[] POTION_ONE_LLAMA = {"jkeahu"};
   private static final String[] POTION_TWO_LLAMAS = {"myajyt"};
   private static final String[] BEE = {"bmimxe"};
   private static final String[] FISH_GROUP = {"trkugw"};
   private static final String[] JOCKEY = {"dxeaal"};
   private static final String[] TAMED_WOLF = {"aqxgxh"};
   private static final String[] TAMED_BABY_WOLF = {"sxikgq"};
   private static final String[] UNKNOWN_MOB = {"gjtuqd"};
   private static final String[] GOLEM_TARGET = {"qffeco"};
   private static final String[] FARMING = {"aobqjt"};
   private static final String[] DROPPED_PILE = {"zywcju"};
   private static final String[] OTHER_PLAYERS = {"cstyvg"};

   private static final Set<String> HOSTILE = Set.of(
      "zombie", "husk", "drowned", "zombie_villager", "pillager", "vindicator", "evoker", "ravager", "vex", "witch",
      "zoglin", "skeleton", "stray", "creeper", "spider", "cave_spider", "phantom", "wither_skeleton", "bogged", "zombified_piglin"
   );
   private static final Set<String> RAIDERS = Set.of("pillager", "vindicator", "evoker", "ravager", "vex", "witch");
   private static final Set<String> FISH = Set.of("cod", "salmon", "tropical_fish", "pufferfish");
   private static final Set<String> FOOD = Set.of("bread", "carrot", "potato", "beetroot");
   private static final Set<String> CROPS = Set.of("wheat", "carrots", "potatoes", "beetroots", "nether_wart", "farmland");
   private static final Set<String> KNOWN = new HashSet<>(Set.of(
      "player", "villager", "wandering_trader", "armor_stand", "item", "experience_orb", "arrow", "spectral_arrow", "trident",
      "fishing_bobber", "painting", "item_frame", "glow_item_frame", "leash_knot", "marker", "text_display", "item_display",
      "block_display", "interaction", "area_effect_cloud", "egg", "ender_pearl", "snowball", "potion", "splash_potion",
      "lingering_potion", "fireball", "small_fireball", "wind_charge", "breeze_wind_charge", "eye_of_ender", "experience_bottle"
   ));

   private static final class W {
      boolean seen;
      long firstTick;
      double lastX;
      double lastZ;
      double speed;
      boolean panic;
      long lastDanger;
      Set<String> effects = new HashSet<>();
      boolean suffocating;
      long suffocateAt;
      boolean wasSleeping;
      boolean dying;
      int hurt;
      boolean wasInvisible;
      boolean near;
      long day = -1L;
      long dayWork = -1L;
      long dayStation = -1L;
      long dayHome = -1L;
      long dayBell = -1L;
      long nextSleepTalk;
      long lastNudge;
      long lastGolem;
   }

   private static final class ItemInfo {
      double x;
      double y;
      double z;
      boolean armor;
      boolean enchanted;
      boolean food;
      int origin;
   }

   private record Gone(double x, double y, double z, boolean baby, long tick) {
   }

   private record Newborn(LivingEntity entity, long tick, boolean baby) {
   }

   private static final class Scan {
      final List<LivingEntity> villagers = new ArrayList<>();
      final List<LivingEntity> traders = new ArrayList<>();
      final List<Entity> hostiles = new ArrayList<>();
      final List<ItemEntity> items = new ArrayList<>();
      final List<Entity> boats = new ArrayList<>();
      final List<Entity> golems = new ArrayList<>();
      final List<Entity> zombieVillagers = new ArrayList<>();
      final List<Entity> llamas = new ArrayList<>();
      final List<Entity> fireworks = new ArrayList<>();
      final List<LivingEntity> otherLiving = new ArrayList<>();
   }

   private static final Map<Entity, W> STATES = new WeakHashMap<>();
   private static final Map<Integer, ItemInfo> ITEMS = new HashMap<>();
   private static final Map<Integer, Integer> OTHER_HURT = new HashMap<>();
   private static final Set<Integer> FIREWORKS_SEEN = new HashSet<>();
   private static final Map<Integer, double[]> CONVERTING = new HashMap<>();
   private static final List<Gone> GONE = new ArrayList<>();
   private static final List<Newborn> NEWBORNS = new ArrayList<>();
   private static final Map<Integer, Long> BOAT_PAIRS = new HashMap<>();
   private static final Random RANDOM = new Random();
   private static int errors;
   private static long lastDayTime = Long.MIN_VALUE;
   private static long playerSleptAt = -10000L;
   private static boolean playerSleeping;
   private static String lastMode;
   private static BlockPos lastFarmland;
   private static long stare;
   private static double lastPx;
   private static double lastPz;
   private static long tradeSignature = Long.MIN_VALUE;
   private static long tradeAt = -1000L;
   private static long lastTradeEvent = -1000L;

   private VnWatch() {
   }

   private static String path(Entity e) {
      return BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath();
   }

   private static String block(Minecraft mc, BlockPos pos) {
      return BuiltInRegistries.BLOCK.getKey(mc.level.getBlockState(pos).getBlock()).getPath();
   }

   private static String itemPath(ItemStack s) {
      return BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
   }

   private static W state(Entity e) {
      return STATES.computeIfAbsent(e, k -> new W());
   }

   private static double flat(Entity a, double x, double z) {
      return Math.hypot(a.getX() - x, a.getZ() - z);
   }

   private static boolean villagerLike(Entity e) {
      return e.getType() == EntityTypes.VILLAGER;
   }

   private static boolean raidersNear(Entity v, Scan s) {
      int n = 0;
      for (Entity h : s.hostiles) {
         if (RAIDERS.contains(path(h)) && h.distanceToSqr(v) < 40.0 * 40.0) {
            n++;
         }
      }

      return n >= 3;
   }

   /** True when a raid is going on around the villager (server information when the server has the mod). */
   public static boolean raidNear(Minecraft mc, Entity v) {
      if (VnNetClient.raid(v)) {
         return true;
      }

      int n = 0;
      for (Entity e : mc.level.getEntities((Entity)null, v.getBoundingBox().inflate(40.0), x -> RAIDERS.contains(path(x)))) {
         n++;
      }

      return n >= 3;
   }

   // ------------------------------------------------------------------------------------------------ main tick

   public static void tick(Minecraft mc, long now) {
      if (mc.level == null || mc.player == null || errors > 20) {
         return;
      }

      try {
         Scan s = scan(mc);
         items(mc, now, s);
         conversions(mc, now, s);
         newborns(mc, now, s);
         for (LivingEntity v : s.villagers) {
            villager(mc, now, s, v);
         }

         for (LivingEntity t : s.traders) {
            trader(mc, now, s, t);
         }

         worldEvents(mc, now, s);
         clock(mc, now);
         player(mc, now, s);
         trading(mc, now, s);
      } catch (RuntimeException ex) {
         errors++;
         Ans.LOGGER.warn("[ans] Villager News watch failed ({}): {}", errors, ex.toString());
      }
   }

   private static Scan scan(Minecraft mc) {
      Scan s = new Scan();
      AABB box = mc.player.getBoundingBox().inflate(28.0);
      for (Entity e : mc.level.getEntities((Entity)null, box, x -> x != mc.player)) {
         if (e instanceof ItemEntity ie) {
            s.items.add(ie);
            continue;
         }

         String p = path(e);
         if (e.getType() == EntityTypes.VILLAGER && e instanceof LivingEntity l) {
            s.villagers.add(l);
         } else if (p.equals("wandering_trader") && e instanceof LivingEntity l) {
            s.traders.add(l);
         } else if (HOSTILE.contains(p)) {
            s.hostiles.add(e);
            if (p.equals("zombie_villager")) {
               s.zombieVillagers.add(e);
            }
         } else if (p.contains("boat") || p.contains("raft")) {
            s.boats.add(e);
         } else if (p.equals("iron_golem")) {
            s.golems.add(e);
         } else if (p.equals("firework_rocket")) {
            s.fireworks.add(e);
         } else if (p.equals("trader_llama")) {
            s.llamas.add(e);
         }

         if (e instanceof LivingEntity l && !(e instanceof Player)) {
            s.otherLiving.add(l);
         }
      }

      return s;
   }

   // ------------------------------------------------------------------------------------------------ items

   private static void items(Minecraft mc, long now, Scan s) {
      Set<Integer> present = new HashSet<>();
      for (ItemEntity ie : s.items) {
         int id = ie.getId();
         present.add(id);
         ItemInfo info = ITEMS.get(id);
         ItemStack stack = ie.getItem();
         if (info == null) {
            info = new ItemInfo();
            info.armor = stack.has(DataComponents.EQUIPPABLE);
            info.enchanted = stack.hasFoil();
            info.food = FOOD.contains(itemPath(stack));
            if (ie.tickCount < 12) {
               if (flat(mc.player, ie.getX(), ie.getZ()) < 2.2) {
                  info.origin = 1;
               } else {
                  for (LivingEntity v : s.villagers) {
                     if (flat(v, ie.getX(), ie.getZ()) < 2.0) {
                        info.origin = 2;
                        break;
                     }
                  }
               }
            }

            ITEMS.put(id, info);
         }

         info.x = ie.getX();
         info.y = ie.getY();
         info.z = ie.getZ();
      }

      Iterator<Map.Entry<Integer, ItemInfo>> it = ITEMS.entrySet().iterator();
      while (it.hasNext()) {
         Map.Entry<Integer, ItemInfo> en = it.next();
         if (present.contains(en.getKey())) {
            continue;
         }

         it.remove();
         ItemInfo info = en.getValue();
         if (flat(mc.player, info.x, info.z) < 2.6 && Math.abs(mc.player.getY() - info.y) < 2.5) {
            continue;
         }

         LivingEntity picker = null;
         for (LivingEntity v : s.villagers) {
            if (flat(v, info.x, info.z) < 2.6 && Math.abs(v.getY() - info.y) < 2.5) {
               picker = v;
               break;
            }
         }

         if (picker == null) {
            continue;
         }

         String[] g;
         if (info.food && picker.isBaby() && info.origin == 2) {
            g = RECEIVE_FOOD;
         } else if (info.food && info.origin == 2) {
            g = SHARE_FOOD;
         } else if (info.armor && info.enchanted) {
            g = PICK_ENCHANTED;
         } else if (info.armor) {
            g = PICK_ARMOR;
         } else if (info.origin == 1) {
            g = PICK_FROM_PLAYER;
         } else if (info.origin == 2) {
            g = PICK_FROM_VILLAGER;
         } else {
            g = PICK_UP;
         }

         VnTriggers.react(picker, g);
      }
   }

   // ------------------------------------------------------------------------------------------------ cures and births

   private static void conversions(Minecraft mc, long now, Scan s) {
      Set<Integer> present = new HashSet<>();
      for (Entity z : s.zombieVillagers) {
         if (VnReflect.bool(z, "isConverting")) {
            present.add(z.getId());
            boolean baby = z instanceof LivingEntity l && l.isBaby();
            CONVERTING.put(z.getId(), new double[]{z.getX(), z.getY(), z.getZ(), baby ? 1.0 : 0.0});
         }
      }

      Iterator<Map.Entry<Integer, double[]>> it = CONVERTING.entrySet().iterator();
      while (it.hasNext()) {
         Map.Entry<Integer, double[]> en = it.next();
         if (!present.contains(en.getKey())) {
            double[] d = en.getValue();
            GONE.add(new Gone(d[0], d[1], d[2], d[3] > 0.5, now));
            it.remove();
         }
      }

      GONE.removeIf(g -> now - g.tick() > 60L);
   }

   private static void newborns(Minecraft mc, long now, Scan s) {
      for (LivingEntity v : s.villagers) {
         W w = state(v);
         if (!w.seen) {
            w.seen = true;
            w.firstTick = now;
            w.lastX = v.getX();
            w.lastZ = v.getZ();
            if (v.tickCount < 20) {
               NEWBORNS.add(new Newborn(v, now, v.isBaby()));
            }
         }
      }

      Iterator<Newborn> it = NEWBORNS.iterator();
      while (it.hasNext()) {
         Newborn n = it.next();
         if (now - n.tick() < 4L) {
            continue;
         }

         it.remove();
         LivingEntity e = n.entity();
         if (e.isRemoved()) {
            continue;
         }

         Gone cured = null;
         for (Gone g : GONE) {
            if (Math.hypot(e.getX() - g.x(), e.getZ() - g.z()) < 4.0) {
               cured = g;
               break;
            }
         }

         if (cured != null) {
            GONE.remove(cured);
            VnTriggers.react(e, n.baby() ? CURE_BABY : CURE);
         } else if (now - VnActions.lastSpawnEgg() < 80L && e.distanceTo(mc.player) < 14.0) {
            VnTriggers.react(e, n.baby() ? SPAWN_BABY : SPAWN_VILLAGER);
         } else if (n.baby()) {
            LivingEntity parent = null;
            int adults = 0;
            for (LivingEntity v : s.villagers) {
               if (!v.isBaby() && v.distanceTo(e) < 8.0) {
                  adults++;
                  if (parent == null) {
                     parent = v;
                  }
               }
            }

            if (adults >= 2) {
               VnTriggers.react(e, BORN);
               if (parent != null) {
                  final LivingEntity p = parent;
                  VnTriggers.later(60L, () -> VnTriggers.react(p, HAVE_BABY));
               }
            }
         }
      }
   }

   // ------------------------------------------------------------------------------------------------ villagers

   private static void villager(Minecraft mc, long now, Scan s, LivingEntity v) {
      W w = state(v);
      double dist = v.distanceTo(mc.player);
      boolean baby = v.isBaby();
      double sp = Math.hypot(v.getX() - w.lastX, v.getZ() - w.lastZ);
      w.lastX = v.getX();
      w.lastZ = v.getZ();
      w.speed = w.speed * 0.7 + sp * 0.3;

      if (v.isDeadOrDying()) {
         if (!w.dying) {
            w.dying = true;
            VnTriggers.speakNow(v, DEATH);
            for (LivingEntity o : s.villagers) {
               if (o != v && !o.isBaby() && !o.isDeadOrDying() && o.distanceTo(v) < 16.0 && o.hasLineOfSight(v)) {
                  VnTriggers.react(o, SEE_DEATH);
                  break;
               }
            }
         }

         return;
      }

      boolean sleeping = v.isSleeping();
      if (sleeping) {
         if (!w.wasSleeping) {
            w.nextSleepTalk = now + 20L * (20 + RANDOM.nextInt(40));
         } else if (now >= w.nextSleepTalk && dist < 10.0) {
            w.nextSleepTalk = now + 20L * (40 + RANDOM.nextInt(60));
            VnTriggers.speakNow(v, SLEEPING);
         }
      } else if (w.wasSleeping && !baby) {
         VnTriggers.react(v, dist < 4.5 || VnActions.recentAttack(v, now) ? WAKE_PLAYER : WAKE_NATURAL);
      }

      w.wasSleeping = sleeping;
      if (sleeping) {
         return;
      }

      // damage
      if (v.hurtTime > 0 && w.hurt == 0 && dist < 16.0 && !VnActions.recentAttack(v, now)) {
         hurt(mc, now, v, w, baby);
      }

      w.hurt = v.hurtTime;
      effects(v, w);
      if (w.suffocating && now - w.suffocateAt > 80L) {
         w.suffocating = false;
         VnTriggers.react(v, FREED);
      }

      // panic and calming down
      double nearestDanger = Double.MAX_VALUE;
      for (Entity h : s.hostiles) {
         nearestDanger = Math.min(nearestDanger, h.distanceToSqr(v));
      }

      boolean danger = nearestDanger < 10.0 * 10.0 && dist < 24.0;
      if (danger) {
         w.lastDanger = now;
         if (!w.panic && w.speed > 0.12) {
            w.panic = true;
            if (!baby) {
               VnTriggers.react(v, PANIC);
            }
         }
      } else if (w.panic && now - w.lastDanger > 120L) {
         w.panic = false;
         VnTriggers.react(v, baby ? CALM_BABY : CALM);
      }

      // the day's routine
      long tod = VnClock.timeOfDay(mc.level);
      long day = now / 24000L;
      if (!baby && dist < 16.0) {
         routine(mc, now, v, w, tod, day);
      }

      if (baby) {
         baby(mc, now, s, v, w, dist);
      } else {
         adultContact(mc, now, v, w, dist);
      }
   }

   private static void routine(Minecraft mc, long now, LivingEntity v, W w, long tod, long day) {
      String prof = VnActions.profession((net.minecraft.world.entity.npc.villager.Villager)v);
      if (tod >= 2000L && tod < 2600L && w.dayWork != day && !prof.equals("none") && !prof.equals("nitwit")) {
         w.dayWork = day;
         VnTriggers.react(v, START_WORK);
      }

      if (tod >= 3000L && tod < 3600L && w.dayStation != day && !prof.equals("none") && !prof.equals("nitwit")) {
         w.dayStation = day;
         String station = workstation(prof);
         if (station != null && !blockNear(mc, v.blockPosition(), 16, 4, station)) {
            VnTriggers.react(v, NO_WORKSTATION);
         }
      }

      if (tod >= 9000L && tod < 9600L && w.dayBell != day) {
         w.dayBell = day;
         if (!blockNear(mc, v.blockPosition(), 16, 4, "bell")) {
            VnTriggers.react(v, NO_BELL);
         }
      }

      if (tod >= 11000L && tod < 11600L && w.dayHome != day) {
         w.dayHome = day;
         String dim = mc.level.dimension().toString();
         if (dim.contains("the_nether")) {
            VnTriggers.react(v, HOME_NETHER);
         } else if (dim.contains("the_end")) {
            VnTriggers.react(v, HOME_END);
         } else if (!dim.contains("overworld")) {
            VnTriggers.react(v, HOME_OTHER);
         } else if (!blockNear(mc, v.blockPosition(), 12, 4, "_bed")) {
            VnTriggers.react(v, NO_BED);
         } else {
            VnTriggers.react(v, GO_HOME);
         }
      }
   }

   /** The block a profession works at, or null for professions without one. */
   private static String workstation(String profession) {
      return switch (profession) {
         case "farmer" -> "composter";
         case "armorer" -> "blast_furnace";
         case "butcher" -> "smoker";
         case "cartographer" -> "cartography_table";
         case "cleric" -> "brewing_stand";
         case "fisherman" -> "barrel";
         case "fletcher" -> "fletching_table";
         case "leatherworker" -> "cauldron";
         case "librarian" -> "lectern";
         case "mason" -> "stonecutter";
         case "shepherd" -> "loom";
         case "toolsmith" -> "smithing_table";
         case "weaponsmith" -> "grindstone";
         default -> null;
      };
   }

   /** True if a block whose name contains the text is within the given distance. */
   static boolean blockNear(Minecraft mc, BlockPos base, int rx, int ry, String text) {
      for (int dx = -rx; dx <= rx; dx++) {
         for (int dy = -ry; dy <= ry; dy++) {
            for (int dz = -rx; dz <= rx; dz++) {
               if (block(mc, base.offset(dx, dy, dz)).contains(text)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   private static void hurt(Minecraft mc, long now, LivingEntity v, W w, boolean baby) {
      String id = VnReflect.damageId(v);
      String[] g = null;
      if (id.contains("fall") && !id.contains("anvil") && !id.contains("stalactite")) {
         g = new String[]{"cifbit"};
      } else if (id.contains("cactus")) {
         g = new String[]{"rogpvp"};
      } else if (id.contains("lava")) {
         g = new String[]{"elryje"};
      } else if (id.contains("freeze")) {
         g = new String[]{"igebly"};
      } else if (id.contains("stalagmite") || id.contains("stalactite")) {
         g = new String[]{"nsxmkr"};
      } else if (id.contains("inwall")) {
         g = new String[]{"vnaodx"};
         w.suffocating = true;
         w.suffocateAt = now;
      } else if (id.contains("explosion")) {
         g = new String[]{"fcbygh"};
      } else if (id.contains("anvil")) {
         g = new String[]{"yzqpvi"};
      } else if (id.contains("magic")) {
         g = hasEffect(v, "poison") ? POISON : HARMING;
      }

      if (g == null && baby) {
         g = BABY_HURT;
      }

      if (g != null) {
         VnTriggers.react(v, g);
      }
   }

   private static boolean hasEffect(LivingEntity v, String name) {
      for (MobEffectInstance inst : v.getActiveEffects()) {
         if (inst.getEffect().getRegisteredName().endsWith(":" + name)) {
            return true;
         }
      }

      return false;
   }

   private static void effects(LivingEntity v, W w) {
      Set<String> now = new HashSet<>();
      for (MobEffectInstance inst : v.getActiveEffects()) {
         String n = inst.getEffect().getRegisteredName();
         now.add(n.substring(n.indexOf(':') + 1));
      }

      for (String e : now) {
         if (w.effects.contains(e)) {
            continue;
         }

         switch (e) {
            case "poison" -> VnTriggers.react(v, POISON);
            case "slowness" -> VnTriggers.react(v, SLOWNESS);
            case "weakness" -> VnTriggers.react(v, WEAKNESS);
            default -> {
            }
         }
      }

      w.effects = now;
   }

   private static void baby(Minecraft mc, long now, Scan s, LivingEntity v, W w, double dist) {
      if (dist < 3.5 && !w.near) {
         w.near = true;
         if (hasPlayerEffect(mc, "hero_of_the_village")) {
            VnTriggers.react(v, BABY_HERO);
         } else if (VnNetClient.tier(v) < 0) {
            VnTriggers.react(v, BABY_BAD_REP);
         } else {
            VnTriggers.react(v, BABY_MEET);
         }
      } else if (dist > 6.0) {
         w.near = false;
      }

      if (now - w.lastGolem > 2400L) {
         for (Entity g : s.golems) {
            if (g.distanceTo(v) < 10.0 && v.hasLineOfSight(g)) {
               w.lastGolem = now;
               VnTriggers.react(v, BABY_GOLEM);
               break;
            }
         }
      }

      if (w.speed > 0.1) {
         for (LivingEntity o : s.villagers) {
            if (o != v && o.isBaby() && o.distanceTo(v) < 5.0 && state(o).speed > 0.1) {
               VnTriggers.react(v, BABY_CHASE);
               break;
            }
         }
      }
   }

   /** Staring and nudging: contact between the player and an adult villager. */
   private static void adultContact(Minecraft mc, long now, LivingEntity v, W w, double dist) {
      double speed = Math.hypot(mc.player.getX() - lastPx, mc.player.getZ() - lastPz);
      if (dist < 1.0 && speed > 0.04 && Math.abs(v.getY() - mc.player.getY()) < 1.2 && now - w.lastNudge > 200L) {
         w.lastNudge = now;
         boolean boat = v.getVehicle() != null && path(v.getVehicle()).contains("boat");
         VnTriggers.react(v, boat ? NUDGE_BOAT : NUDGE);
      }
   }

   private static boolean hasPlayerEffect(Minecraft mc, String name) {
      for (MobEffectInstance inst : mc.player.getActiveEffects()) {
         if (inst.getEffect().getRegisteredName().endsWith(":" + name)) {
            return true;
         }
      }

      return false;
   }

   // ------------------------------------------------------------------------------------------------ traders

   private static void trader(Minecraft mc, long now, Scan s, LivingEntity t) {
      W w = state(t);
      boolean invisible = t.isInvisible();
      if (invisible && !w.wasInvisible && t.distanceTo(mc.player) < 24.0) {
         int llamas = 0;
         for (Entity l : s.llamas) {
            if (l.distanceTo(t) < 10.0) {
               llamas++;
            }
         }

         VnTriggers.react(t, llamas >= 2 ? POTION_TWO_LLAMAS : llamas == 1 ? POTION_ONE_LLAMA : POTION_TRADER);
      }

      w.wasInvisible = invisible;
   }

   /** A line a wandering trader may say about its situation, or null. */
   public static String[] traderSituation(Minecraft mc, LivingEntity t) {
      if (t.isInvisible()) {
         return INVISIBLE_TRADER;
      }

      if (mc.level.isRaining() && mc.level.canSeeSky(t.blockPosition())) {
         return RAIN_TRADER;
      }

      return null;
   }

   // ------------------------------------------------------------------------------------------------ world events

   private static void worldEvents(Minecraft mc, long now, Scan s) {
      for (Entity f : s.fireworks) {
         if (FIREWORKS_SEEN.add(f.getId()) && f.tickCount < 6) {
            VnActions.reactNearPlayer(mc, FIREWORK);
         }
      }

      if (FIREWORKS_SEEN.size() > 300) {
         FIREWORKS_SEEN.clear();
      }

      for (Entity b : s.boats) {
         int n = 0;
         LivingEntity first = null;
         for (Entity p : b.getPassengers()) {
            if (villagerLike(p) && p instanceof LivingEntity l) {
               n++;
               if (first == null) {
                  first = l;
               }
            }
         }

         if (n >= 2 && first != null) {
            Long last = BOAT_PAIRS.get(b.getId());
            if (last == null || now - last > 1200L) {
               BOAT_PAIRS.put(b.getId(), now);
               VnTriggers.react(first, TWO_IN_BOAT);
            }
         }
      }

      for (LivingEntity o : s.otherLiving) {
         int hurt = o.hurtTime;
         Integer before = OTHER_HURT.put(o.getId(), hurt);
         if (hurt > 0 && (before == null || before == 0) && !VnActions.recentAttack(o, now)) {
            VnActions.reactNearPlayer(mc, SEE_HURT);
         }
      }

      if (OTHER_HURT.size() > 500) {
         OTHER_HURT.clear();
      }
   }

   private static void clock(Minecraft mc, long now) {
      long day = VnClock.dayTime(mc.level);
      if (mc.player.isSleeping()) {
         playerSleptAt = now;
      }

      if (lastDayTime != Long.MIN_VALUE && Math.abs(day - lastDayTime) > 250L && now - playerSleptAt > 100L) {
         long before = Math.floorMod(lastDayTime, 24000L);
         long after = Math.floorMod(day, 24000L);
         boolean wasNight = before >= 13000L;
         boolean isNight = after >= 13000L;
         LivingEntity v = nearestVillager(mc, 16.0, null);
         if (v != null) {
            boolean baby = v.isBaby();
            if (wasNight && !isNight) {
               VnTriggers.react(v, baby ? SUDDEN_DAY_BABY : RANDOM.nextInt(3) != 0 ? SUDDEN_DAY : TIME_SKIP);
            } else if (!wasNight && isNight) {
               VnTriggers.react(v, baby ? SUDDEN_NIGHT_BABY : RANDOM.nextInt(3) != 0 ? SUDDEN_NIGHT : TIME_SKIP);
            } else {
               VnTriggers.react(v, baby ? TIME_SKIP_BABY : TIME_SKIP);
            }
         }
      }

      lastDayTime = day;
   }

   private static LivingEntity nearestVillager(Minecraft mc, double range, Boolean babyOnly) {
      LivingEntity best = null;
      double bestDist = range * range;
      for (Entity e : mc.level.getEntities((Entity)null, mc.player.getBoundingBox().inflate(range), x -> villagerLike(x))) {
         if (e instanceof LivingEntity l && !l.isSleeping() && (babyOnly == null || l.isBaby() == babyOnly)) {
            double d = e.distanceToSqr(mc.player);
            if (d < bestDist) {
               best = l;
               bestDist = d;
            }
         }
      }

      return best;
   }

   // ------------------------------------------------------------------------------------------------ the player

   private static void player(Minecraft mc, long now, Scan s) {
      Player p = mc.player;
      String mode = mc.gameMode == null ? null : mc.gameMode.getPlayerMode().name();
      if (lastMode != null && mode != null && !mode.equals(lastMode) && !mode.equals("CREATIVE")) {
         VnActions.reactNearPlayer(mc, GAMEMODE);
      }

      lastMode = mode;
      boolean sleeping = p.isSleeping();
      if (playerSleeping && !sleeping) {
         boolean armor = false;
         for (net.minecraft.world.entity.EquipmentSlot slot : new net.minecraft.world.entity.EquipmentSlot[]{
            net.minecraft.world.entity.EquipmentSlot.HEAD, net.minecraft.world.entity.EquipmentSlot.CHEST,
            net.minecraft.world.entity.EquipmentSlot.LEGS, net.minecraft.world.entity.EquipmentSlot.FEET}) {
            armor |= !p.getItemBySlot(slot).isEmpty();
         }

         VnActions.reactNearPlayer(mc, armor ? PLAYER_WAKES_ARMOR : PLAYER_WAKES);
      }

      playerSleeping = sleeping;

      // staring at a villager
      Entity target = mc.crosshairPickEntity;
      if (target != null && villagerLike(target) && target instanceof LivingEntity l && !l.isBaby() && !l.isSleeping() && l.distanceTo(p) < 7.0) {
         stare++;
         if (stare > 100L) {
            stare = -240L;
            VnTriggers.react(l, STARE);
         }
      } else if (stare > 0L) {
         stare = 0L;
      } else if (stare < 0L) {
         stare++;
      }

      // trampling farmland
      if (lastFarmland != null && block(mc, lastFarmland).equals("dirt")) {
         lastFarmland = null;
         VnActions.reactNearPlayer(mc, TRAMPLE);
      }

      if (p.onGround()) {
         BlockPos below = p.blockPosition().below();
         lastFarmland = block(mc, below).equals("farmland") ? below : null;
      }

      lastPx = p.getX();
      lastPz = p.getZ();
   }

   // ------------------------------------------------------------------------------------------------ trading

   private static long inventorySignature(Minecraft mc) {
      long sig = 17L;
      for (int i = 0; i < mc.player.getInventory().getContainerSize(); i++) {
         ItemStack st = mc.player.getInventory().getItem(i);
         if (!st.isEmpty()) {
            sig = sig * 31L + itemPath(st).hashCode() * 7L + st.getCount();
         }
      }

      return sig;
   }

   private static void trading(Minecraft mc, long now, Scan s) {
      Entity with = VnActions.tradingEntity();
      if (!(mc.gui.screen() instanceof MerchantScreen) || with == null) {
         tradeSignature = Long.MIN_VALUE;
         return;
      }

      long sig = inventorySignature(mc);
      if (tradeSignature != Long.MIN_VALUE && sig != tradeSignature && now - lastTradeEvent > 15L && with instanceof LivingEntity v) {
         lastTradeEvent = now;
         VnTriggers.react(v, path(v).equals("wandering_trader") ? TRADE_DONE_TRADER : TRADE_DONE);
      }

      tradeSignature = sig;
   }

   /** Lines when the trading window opens: raids, then the reputation of the player. Null for the normal opening line. */
   public static String[] tradeOpening(Minecraft mc, LivingEntity v) {
      if (raidNear(mc, v)) {
         return REFUSE_RAID;
      }

      int tier = VnNetClient.tier(v);
      if (tier < 0 && RANDOM.nextInt(3) == 0) {
         return REFUSE_REP;
      }

      return tier == 0 ? null : TRADE_REP[tier + 2];
   }

   // ------------------------------------------------------------------------------------------------ approach and idle

   /** What a villager says when the player walks up while having a special status, or null. */
   public static String[] approach(Minecraft mc, LivingEntity v) {
      if (hasPlayerEffect(mc, "hero_of_the_village")) {
         return HERO;
      }

      if (hasPlayerEffect(mc, "bad_omen") || hasPlayerEffect(mc, "raid_omen")) {
         return BAD_OMEN;
      }

      int tier = VnNetClient.tier(v);
      if (tier != 0) {
         if (tier == -2 && itemPath(mc.player.getMainHandItem()).endsWith("_sword")) {
            return REP_SWORD;
         }

         return APPROACH_REP[tier + 2];
      }

      return null;
   }

   /** Extra situations an adult villager may comment on while idle. */
   public static List<String[]> situations(Minecraft mc, LivingEntity v) {
      List<String[]> out = new ArrayList<>();
      int piles = 0;
      for (Entity e : mc.level.getEntities(v, v.getBoundingBox().inflate(10.0), x -> true)) {
         if (!v.hasLineOfSight(e)) {
            continue;
         }

         String p = path(e);
         if (e instanceof ItemEntity) {
            piles++;
         } else if (p.equals("bee") && e instanceof Mob m && m.getTarget() != null) {
            out.add(BEE);
         } else if (FISH.contains(p)) {
            out.add(FISH_GROUP);
         } else if (e instanceof Mob m && e.getVehicle() instanceof Mob && (HOSTILE.contains(p))) {
            out.add(JOCKEY);
         } else if (p.equals("wolf") && VnReflect.bool(e, "isTame")) {
            out.add(e instanceof LivingEntity l && l.isBaby() ? TAMED_BABY_WOLF : TAMED_WOLF);
         } else if (p.equals("iron_golem") && e instanceof Mob m && m.isAggressive() && e.distanceTo(mc.player) < 20.0) {
            out.add(GOLEM_TARGET);
         } else if (e instanceof LivingEntity && !(e instanceof Player) && !KNOWN.contains(p) && !VnTriggers.hasMobRule(p)) {
            out.add(UNKNOWN_MOB);
         }
      }

      if (piles >= 10) {
         out.add(DROPPED_PILE);
      }

      if (VnReflect.bool(v, "isBaby")) {
         return out;
      }

      String prof = v instanceof net.minecraft.world.entity.npc.villager.Villager vil ? VnActions.profession(vil) : "";
      if (prof.equals("farmer") && blockNear(mc, v.blockPosition(), 6, 2, "farmland")) {
         out.add(FARMING);
      }

      int others = mc.level.getEntities(mc.player, mc.player.getBoundingBox().inflate(6.0), x -> x instanceof Player).size();
      if (others >= 1) {
         out.add(OTHER_PLAYERS);
      }

      return out;
   }
}
