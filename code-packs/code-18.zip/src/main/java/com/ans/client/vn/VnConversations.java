package com.ans.client.vn;

import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.villager.Villager;

/**
 * Conversations between two villagers: wandering together, gossip, a campfire story and a witnessed attack.
 * Each conversation is a list of parts; the villagers speak them in turn, each starting when the other has finished.
 */
public final class VnConversations {
   private static final String[][] BOTH_NOSES = {
      {"gmrypkswxeva", "gmrypkbayahw", "gmrypkmudlec"},
      {"gmrypkoallbt", "gmrypkfobzlt", "gmrypkcljvls"},
      {"gmrypkhiqnpi", "gmrypkvkuidc", "gmrypkhnvsiu", "gmrypkvswnrg"},
      {"gmrypkmwtiaf", "gmrypkgougka"}
   };
   private static final String[][] ONE_NOSELESS = {
      {"bygaxwswxeva", "bygaxwbayahw"},
      {"bygaxwoallbt", "bygaxwfobzlt", "bygaxwcljvls"},
      {"bygaxwhiqnpi", "bygaxwhiqnpi"}
   };
   private static final String[][] NO_NOSES = {
      {"loicswswxeva", "loicswbayahw"},
      {"loicswrotbcq"},
      {"loicswhiqnpi", "loicswvkuidc", "loicswhnvsiu"}
   };
   private static final String[] GOSSIP = {"wrjbddswxeva", "wrjbddbayahw", "wrjbddmudlec", "wrjbddtvewwu", "wrjbddsrlwzw"};
   private static final String[] GOSSIP_SINGLE = {"wrjbdd"};
   private static final String[] CAMPFIRE = {"wrswgiswxeva", "wrswgibayahw", "wrswgimudlec", "wrswgitvewwu", "wrswgisrlwzw", "wrswgicsmkgk"};
   private static final String[] WITNESS = {"slbqfwswxeva", "slbqfwbayahw"};

   private static final Map<Entity, Long> LAST = new WeakHashMap<>();
   private static final Random RANDOM = new Random();

   private VnConversations() {
   }

   private record Convo(LivingEntity a, LivingEntity b, String[] parts, boolean campfire) {
   }

   private static boolean noseless(LivingEntity v) {
      return v.getItemBySlot(EquipmentSlot.OFFHAND).is(com.ans.vn.item.VnItems.VILLAGER_NOSE);
   }

   private static boolean valid(Minecraft mc, LivingEntity e) {
      return e.isAlive() && !e.isRemoved() && !e.isDeadOrDying() && !e.isSleeping() && e.distanceTo(mc.player) < 16.0;
   }

   private static boolean complete(String[] parts) {
      for (String p : parts) {
         if (!VnSpeech.hasGroup(p)) {
            return false;
         }
      }

      return true;
   }

   /** The villager standing next to v that it could talk with, or null. */
   private static LivingEntity partner(Minecraft mc, LivingEntity v, long now) {
      LivingEntity best = null;
      double bestDist = 2.5 * 2.5;
      for (Entity e : mc.level.getEntities(v, v.getBoundingBox().inflate(2.5), x -> x instanceof Villager o && !o.isBaby())) {
         if (!(e instanceof LivingEntity o) || !valid(mc, o) || VnSpeech.isSpeaking(o) || !v.hasLineOfSight(o)) {
            continue;
         }

         Long last = LAST.get(o);
         if (last != null && now - last < 1400L) {
            continue;
         }

         double d = o.distanceToSqr(v);
         if (d < bestDist) {
            best = o;
            bestDist = d;
         }
      }

      return best;
   }

   /** Called when an idle villager would speak: it may start a conversation with a neighbour instead. */
   public static boolean idle(Minecraft mc, LivingEntity v, long now) {
      if (!(v instanceof Villager) || v.isBaby() || VnSpeech.anyoneSpeaking() || RANDOM.nextInt(100) >= 80) {
         return false;
      }

      Long last = LAST.get(v);
      if (last != null && now - last < 1400L) {
         return false;
      }

      LivingEntity other = partner(mc, v, now);
      if (other == null) {
         return false;
      }

      long tod = VnClock.timeOfDay(mc.level);
      String[] parts;
      boolean campfire = false;
      if (VnWatch.blockNear(mc, v.blockPosition(), 6, 2, "campfire")) {
         parts = CAMPFIRE;
         campfire = true;
      } else if (tod >= 8000L && tod < 10000L && RANDOM.nextBoolean()) {
         parts = RANDOM.nextBoolean() ? GOSSIP : GOSSIP_SINGLE;
      } else {
         int without = (noseless(v) ? 1 : 0) + (noseless(other) ? 1 : 0);
         String[][] set = without == 0 ? BOTH_NOSES : without == 1 ? ONE_NOSELESS : NO_NOSES;
         parts = set[RANDOM.nextInt(set.length)];
      }

      if (!complete(parts)) {
         return false;
      }

      LAST.put(v, now);
      LAST.put(other, now);
      return step(new Convo(v, other, parts, campfire), v, 0);
   }

   /** A villager that saw the attack: another awake adult villager standing close by, indoors. */
   public static LivingEntity witnessFor(Minecraft mc, LivingEntity victim) {
      for (Entity e : mc.level.getEntities(victim, victim.getBoundingBox().inflate(4.0), x -> x instanceof Villager o && !o.isBaby())) {
         if (e instanceof LivingEntity o && valid(mc, o) && !mc.level.canSeeSky(o.blockPosition())) {
            return o;
         }
      }

      return null;
   }

   /** The victim cries out, then the witness answers. Returns true when the conversation took over the reaction. */
   public static boolean witness(LivingEntity victim, LivingEntity witness) {
      if (!complete(WITNESS) || VnSpeech.anyoneSpeaking()) {
         return false;
      }

      if (!VnChatter.pass()) {
         return true;
      }

      return step(new Convo(victim, witness, WITNESS, false), victim, 0);
   }

   /** Plays part i by the speaker, then schedules the next part for when this one is over. */
   private static boolean step(Convo c, LivingEntity speaker, int i) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.level == null || mc.player == null || i >= c.parts().length) {
         return i > 0;
      }

      LivingEntity other = speaker == c.a() ? c.b() : c.a();
      if (!valid(mc, speaker) || !valid(mc, other) || VnSpeech.isSpeaking(speaker) || i == 0 && VnSpeech.anyoneSpeaking()) {
         return false;
      }

      if (!VnSpeech.say(speaker, c.parts()[i])) {
         return false;
      }

      int finished = i + 1;
      // at a campfire the storyteller keeps the word after the second and the fourth part
      LivingEntity next = c.campfire() && (finished == 2 || finished == 4) ? speaker : other;
      long wait = Math.round(VnSpeech.lastDuration() * 20.0) + 6L;
      if (finished < c.parts().length) {
         VnTriggers.later(wait, () -> step(c, next, finished));
      }

      return true;
   }
}
