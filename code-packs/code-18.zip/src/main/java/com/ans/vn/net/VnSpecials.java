package com.ans.vn.net;

import com.ans.Ans;
import com.ans.client.vn.VnReflect;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.BooleanSupplier;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.ItemStack;

/**
 * The special Villager News characters turn up by themselves: a villager that appears with a brand new village
 * far from the world spawn becomes one of them. Every character appears once per world, and never within 150
 * blocks of another one. The same rules as the original add-on.
 */
public final class VnSpecials {
   /** Set by the client from the "Spawn Special Villagers" setting; a dedicated server always allows them. */
   public static volatile BooleanSupplier enabled = () -> true;

   private static final String TAG = "vn_special";
   private static final String[] VILLAGERS = {"Mayor Villager", "Testificate Man", "Villager Number 5", "Villager Number 9", "Villager Unreachable"};
   private static final String WOOLY = "Wooly";
   private static final Random RANDOM = new Random();
   private static final List<Villager> PENDING = new ArrayList<>();
   /** Name of the character to where it was placed: x, z. */
   private static final Map<String, double[]> PLACED = new LinkedHashMap<>();
   private static boolean installed;
   private static boolean loaded;

   private VnSpecials() {
   }

   public static synchronized void install() {
      if (installed) {
         return;
      }

      installed = true;
      ServerEntityEvents.ENTITY_LOAD.register((entity, level) -> {
         if (entity instanceof Villager v && !v.isBaby() && v.getCustomName() == null) {
            synchronized (PENDING) {
               PENDING.add(v);
            }
         }
      });
      ServerTickEvents.END_SERVER_TICK.register(VnSpecials::process);
      ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
         if (entity.getTags().contains(TAG) && entity.getCustomName() != null) {
            synchronized (PLACED) {
               PLACED.remove(entity.getCustomName().getString());
            }

            MinecraftServer server = entity.level() instanceof ServerLevel sl ? sl.getServer() : null;
            if (server != null) {
               save(server);
            }
         }
      });
   }

   private static Path file(MinecraftServer server) {
      try {
         Class<?> res = Class.forName("net.minecraft.world.level.storage.LevelResource");
         Object root = res.getField("ROOT").get(null);
         Object path = VnReflect.invoke(server, "getWorldPath", root);
         return path instanceof Path p ? p.resolve("vn_specials.json") : null;
      } catch (ReflectiveOperationException | RuntimeException ex) {
         return null;
      }
   }

   private static synchronized void load(MinecraftServer server) {
      if (loaded) {
         return;
      }

      loaded = true;
      Path f = file(server);
      if (f == null || !Files.exists(f)) {
         return;
      }

      try {
         JsonObject o = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8)).getAsJsonObject();
         for (Map.Entry<String, JsonElement> e : o.entrySet()) {
            JsonArray a = e.getValue().getAsJsonArray();
            PLACED.put(e.getKey(), new double[]{a.get(0).getAsDouble(), a.get(1).getAsDouble()});
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Could not read the special villager list: {}", ex.toString());
      }
   }

   private static void save(MinecraftServer server) {
      Path f = file(server);
      if (f == null) {
         return;
      }

      JsonObject o = new JsonObject();
      synchronized (PLACED) {
         for (Map.Entry<String, double[]> e : PLACED.entrySet()) {
            JsonArray a = new JsonArray();
            a.add(e.getValue()[0]);
            a.add(e.getValue()[1]);
            o.add(e.getKey(), a);
         }
      }

      try {
         Files.writeString(f, new Gson().toJson(o), StandardCharsets.UTF_8);
      } catch (IOException ex) {
         Ans.LOGGER.warn("[ans] Could not save the special villager list: {}", ex.toString());
      }
   }

   private static void process(MinecraftServer server) {
      List<Villager> batch;
      synchronized (PENDING) {
         if (PENDING.isEmpty()) {
            return;
         }

         batch = new ArrayList<>(PENDING);
         PENDING.clear();
      }

      if (!enabled.getAsBoolean()) {
         return;
      }

      load(server);
      for (Villager v : batch) {
         try {
            consider(server, v);
         } catch (RuntimeException ex) {
            Ans.LOGGER.warn("[ans] Special villager check failed: {}", ex.toString());
            return;
         }
      }
   }

   private static void consider(MinecraftServer server, Villager v) {
      if (v.isRemoved() || !v.isAlive() || v.getCustomName() != null || !(v.level() instanceof ServerLevel level)) {
         return;
      }

      if (!level.dimension().toString().contains("overworld")) {
         return;
      }

      // only villagers that come with a freshly generated village: nobody has spent time in their chunk yet
      Object chunk = VnReflect.invoke(level, "getChunkAt", v.blockPosition());
      Object inhabited = VnReflect.invoke(chunk, "getInhabitedTime");
      if (!(inhabited instanceof Number n) || n.longValue() > 0L) {
         return;
      }

      double sx = 0.0;
      double sz = 0.0;
      Object spawn = VnReflect.invoke(level, "getSharedSpawnPos");
      if (spawn instanceof BlockPos p) {
         sx = p.getX();
         sz = p.getZ();
      }

      if (Math.hypot(v.getX() - sx, v.getZ() - sz) < 1000.0) {
         return;
      }

      String name;
      synchronized (PLACED) {
         for (double[] at : PLACED.values()) {
            if (Math.hypot(v.getX() - at[0], v.getZ() - at[1]) < 150.0) {
               return;
            }
         }

         List<String> left = new ArrayList<>();
         for (String s : VILLAGERS) {
            if (!PLACED.containsKey(s)) {
               left.add(s);
            }
         }

         if (!PLACED.containsKey(WOOLY)) {
            left.add(WOOLY);
         }

         if (left.isEmpty()) {
            return;
         }

         name = left.get(RANDOM.nextInt(left.size()));
         PLACED.put(name, new double[]{v.getX(), v.getZ()});
      }

      if (name.equals(WOOLY)) {
         Entity sheep = EntityTypes.SHEEP.spawn(level, ItemStack.EMPTY, null, v.blockPosition(), EntitySpawnReason.SPAWN_ITEM_USE, false, false);
         if (sheep == null) {
            synchronized (PLACED) {
               PLACED.remove(name);
            }

            return;
         }

         sheep.setCustomName(Component.literal(name));
         sheep.addTag(TAG);
      } else {
         v.setCustomName(Component.literal(name));
         v.addTag(TAG);
      }

      save(server);
      Ans.LOGGER.info("[ans] {} appeared near {} {}", name, (int)v.getX(), (int)v.getZ());
   }
}
