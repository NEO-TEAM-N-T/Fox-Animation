#!/usr/bin/env python3
"""Actions & Stuff 1.13 attachables -> side-by-side mod data (attachable13/), with shared models and animations.

usage: a13_attachables.py <extracted resource pack> <output folder>
Writes assets/ans/attachable13/<id>.json (bundles), attachable13/_index.json (item -> bundles + condition),
geckolib models/animations named by content hash so identical ones are stored once, and the textures they use.
Attachables that need vanilla Bedrock textures which are not in the pack are skipped (the older data keeps them).
"""
import glob, hashlib, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bedrock_to_bundle import Pack, jload, tok, render_type

NS = 'ans'


def h(obj):
    return hashlib.sha1(json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()).hexdigest()[:12]


def version(d):
    try:
        return tuple(int(x) for x in str(d.get('min_engine_version') or '0').split('.'))
    except ValueError:
        return (0,)


def main():
    root, out = sys.argv[1], sys.argv[2]
    from PIL import Image
    pack = Pack(root)
    base = f'{out}/assets/{NS}'
    for p in ('attachable13', 'geckolib/models/entity', 'geckolib/animations/entity'):
        os.makedirs(f'{base}/{p}', exist_ok=True)
    chosen = {}
    for f in sorted(glob.glob(root + '/attachables/*.json')):
        try:
            d = jload(f)['minecraft:attachable']['description']
        except Exception:
            continue
        ident = d['identifier']
        if ident not in chosen or version(d) > chosen[ident][0]:
            chosen[ident] = (version(d), d)
    index, skipped, kept, tex_done = {}, {}, 0, set()
    for ident, (_, d) in sorted(chosen.items()):
        name = ident.replace(':', '_').replace('minecraft_', '')
        problems = []
        geometry, bone_bindings = {}, {}
        for key, gid in d.get('geometry', {}).items():
            gid = gid.split(':')[0]
            if gid not in pack.geo:
                problems.append('geo')
                continue
            g = json.loads(json.dumps(pack.geo[gid]))
            binds = {}
            for b in g.get('bones', []):
                if 'binding' in b:
                    binds[b['name'].lower()] = b.pop('binding')
            g['description']['identifier'] = 'geometry.ans.tmp'
            gh = 'a13g_' + h(g)
            g['description']['identifier'] = f'geometry.{NS}.{gh}'
            path = f'{base}/geckolib/models/entity/{gh}.geo.json'
            if not os.path.exists(path):
                json.dump({'format_version': '1.12.0', 'minecraft:geometry': [g]}, open(path, 'w'), separators=(',', ':'))
            geometry[key] = f'{NS}:entity/{gh}'
            if binds:
                bone_bindings[f'{NS}:entity/{gh}'] = binds
        textures = {}
        for key, t in d.get('textures', {}).items():
            src = next((root + '/' + t + e for e in ('.png', '.tga') if os.path.exists(root + '/' + t + e)), None)
            if src and os.path.getsize(src) > 0:
                textures[key] = f'{NS}:{t}.png'
            else:
                problems.append('tex')
        materials = {}
        for key, m in d.get('materials', {}).items():
            parent = pack.mat.get(m, m)
            rt, cm, multi = render_type(parent)
            e = {'bedrock': parent, 'render_type': rt}
            if cm:
                e['color_mask'] = True
            if multi:
                e['multi_texture'] = True
            materials[key] = e
        anim_file, animations = {}, {}
        for key, v in d.get('animations', {}).items():
            if v.startswith('controller.animation.'):
                c = pack.ctrl.get(v)
                if c is None:
                    problems.append('ctrl')
                    animations[key] = {'bedrock': v, 'missing': True}
                else:
                    animations[key] = {'bedrock': v, 'controller': json.loads(json.dumps(c))}
            else:
                a = pack.anim.get(v)
                if a is None:
                    problems.append('anim')
                    animations[key] = {'bedrock': v, 'missing': True}
                    continue
                e = {'bedrock': v, 'animation': v}
                for k in ('loop', 'animation_length', 'anim_time_update', 'blend_weight', 'start_delay', 'loop_delay',
                          'override_previous_animation', 'timeline'):
                    if k in a:
                        e[k] = a[k]
                rel = [bn for bn, b in (a.get('bones') or {}).items()
                       if isinstance(b, dict) and isinstance(b.get('relative_to'), dict) and b['relative_to'].get('rotation') == 'entity']
                if rel:
                    e['relative_to_entity'] = rel
                animations[key] = e
                anim_file[v] = {k: x for k, x in a.items() if k not in ('timeline', 'sound_effects', 'particle_effects')}
        rcs = []
        for ent in d.get('render_controllers', []):
            rid, cond = (ent, None) if isinstance(ent, str) else next(iter(ent.items()))
            r = pack.rc.get(rid)
            if r is None:
                problems.append('rc')
                continue
            r = json.loads(json.dumps(r))
            if 'arrays' in r:
                r['arrays'] = {an: vals for grp in r['arrays'].values() for an, vals in grp.items()}
            r['id'] = rid
            r['condition'] = cond
            rcs.append(r)
        if problems:
            skipped[ident] = sorted(set(problems))
            continue
        ah = 'a13a_' + h(anim_file)
        apath = f'{base}/geckolib/animations/entity/{ah}.animation.json'
        if not os.path.exists(apath):
            json.dump({'format_version': '1.8.0', 'animations': anim_file}, open(apath, 'w'), separators=(',', ':'))
        for t in textures.values():
            rel = t.split(':', 1)[1][:-4]
            if rel not in tex_done:
                tex_done.add(rel)
                src = next(root + '/' + rel + e for e in ('.png', '.tga') if os.path.exists(root + '/' + rel + e))
                dst = f'{base}/{rel}.png'
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                Image.open(src).convert('RGBA').save(dst)
        scripts = {k: v for k, v in (d.get('scripts') or {}).items() if k != 'variables'}
        bundle = {'format': f'{NS}:bedrock_attachable', 'format_version': 1, 'identifier': ident,
                  'source': {'layer': 'RP', 'min_engine_version': str(d.get('min_engine_version') or '')},
                  'animation_file': f'{NS}:entity/{ah}', 'geometry': geometry, 'textures': textures, 'materials': materials,
                  'animations': animations, 'scripts': scripts, 'render_controllers': rcs, 'bone_bindings': bone_bindings,
                  'sound_effects': {}, 'particle_effects': {}}
        json.dump(bundle, open(f'{base}/attachable13/{name}.json', 'w'), separators=(',', ':'))
        kept += 1
        items = d.get('item') or {ident: None}
        for item, cond in items.items():
            index.setdefault(item, []).append([f'{NS}:attachable13/{name}', cond])
    json.dump({'items': index}, open(f'{base}/attachable13/_index.json', 'w'), separators=(',', ':'))
    print(kept, 'attachables written;', len(skipped), 'skipped:')
    for k, v in list(skipped.items())[:25]:
        print(' ', k, v)


if __name__ == '__main__':
    main()
