package com.ans.vn.item;

import com.ans.vn.net.VnNet;
import net.fabricmc.api.ModInitializer;

/** Runs on both the client and the server: registers the Villager News items and the network packet. */
public class VnCommon implements ModInitializer {
   @Override
   public void onInitialize() {
      VnItems.register();
      VnVillagerItems.register();
      VnNet.install();
   }
}
