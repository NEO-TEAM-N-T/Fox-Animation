package com.ans.vn.net;

import com.ans.Ans;
import com.ans.client.vn.VnReflect;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

/**
 * Server to client information the client cannot see by itself: what each nearby villager thinks of the player
 * (its reputation) and whether a raid is going on around it. Sent a few times a second to players near villagers.
 */
public final class VnNet {
   /** Flat list of triples: entity id, reputation of the receiving player, flags (bit 0 = raid around the villager). */
   public record InfoPayload(List<Integer> data) implements CustomPacketPayload {
      public static final CustomPacketPayload.Type<InfoPayload> TYPE = new CustomPacketPayload.Type<>(Ans.id("vn_info"));
      public static final StreamCodec<RegistryFriendlyByteBuf, InfoPayload> CODEC = StreamCodec.composite(
         ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list()), InfoPayload::data, InfoPayload::new
      );

      @Override
      public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
         return TYPE;
      }
   }

   private static boolean installed;
   private static boolean payloadRegistered;
   private static int failures;

   private VnNet() {
   }

   public static boolean available() {
      return payloadRegistered;
   }

   /** Runs on both sides: registers the packet type; on a server also starts sending. */
   public static synchronized void install() {
      if (installed) {
         return;
      }

      installed = true;
      payloadRegistered = registerPayload();
      if (!payloadRegistered) {
         Ans.LOGGER.warn("[ans] Villager News: could not register its network packet; reputation and raid reactions stay client-side");
         return;
      }

      ServerTickEvents.END_SERVER_TICK.register(VnNet::serverTick);
   }

   /** The registry method was renamed between Fabric versions, so both names are tried. */
   private static boolean registerPayload() {
      for (String name : new String[]{"playS2C", "clientboundPlay"}) {
         try {
            Class<?> registry = Class.forName("net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry");
            Method getter = registry.getMethod(name);
            Object reg = getter.invoke(null);
            for (Method m : getter.getReturnType().getMethods()) {
               if (m.getName().equals("register") && m.getParameterCount() == 2) {
                  m.invoke(reg, InfoPayload.TYPE, InfoPayload.CODEC);
                  return true;
               }
            }
         } catch (ReflectiveOperationException | RuntimeException ex) {
            // try the next name
         }
      }

      return false;
   }

   private static void serverTick(MinecraftServer server) {
      if (server.getTickCount() % 40 != 0) {
         return;
      }

      for (ServerPlayer player : server.getPlayerList().getPlayers()) {
         try {
            send(player);
         } catch (RuntimeException ex) {
            if (failures++ < 3) {
               Ans.LOGGER.warn("[ans] Villager News: could not send village information: {}", ex.toString());
            }
         }
      }
   }

   private static void send(ServerPlayer player) {
      Level lv = player.level();
      if (!(lv instanceof ServerLevel level)) {
         return;
      }

      AABB box = player.getBoundingBox().inflate(24.0);
      List<Villager> villagers = level.getEntitiesOfClass(Villager.class, box);
      if (villagers.isEmpty()) {
         return;
      }

      List<Integer> data = new ArrayList<>();
      for (Villager v : villagers) {
         int rep = VnReflect.integer(v, "getPlayerReputation", 0, player);
         Object raid = VnReflect.invoke(level, "getRaidAt", v.blockPosition());
         int flags = raid != null && !Boolean.FALSE.equals(VnReflect.invoke(raid, "isActive")) ? 1 : 0;
         data.add(v.getId());
         data.add(rep);
         data.add(flags);
      }

      ServerPlayNetworking.send(player, new InfoPayload(data));
   }
}
