package com.ans.client.vn;

import com.ans.Ans;
import java.lang.reflect.Method;
import net.minecraft.world.level.Level;

/** Time of day. The game has moved this around between versions, so the method is looked up once. */
public final class VnClock {
   private static final String[] NAMES = {"getDayTime", "dayTime", "getOverworldClockTime", "getDefaultClockTime"};
   private static Method method;
   private static boolean resolved;

   private VnClock() {
   }

   private static void resolve(Level level) {
      resolved = true;
      for (String n : NAMES) {
         try {
            Method m = level.getClass().getMethod(n);
            if (Number.class.isAssignableFrom(box(m.getReturnType()))) {
               method = m;
               Ans.LOGGER.info("[ans] Villager News time of day uses {}", n);
               return;
            }
         } catch (NoSuchMethodException ignored) {
            // try the next name
         }
      }

      Ans.LOGGER.info("[ans] Villager News time of day uses the game time");
   }

   private static Class<?> box(Class<?> c) {
      if (c == long.class) {
         return Long.class;
      }

      return c == int.class ? Integer.class : c;
   }

   public static long dayTime(Level level) {
      if (!resolved) {
         resolve(level);
      }

      if (method != null) {
         try {
            Object o = method.invoke(level);
            if (o instanceof Number n) {
               return n.longValue();
            }
         } catch (ReflectiveOperationException | RuntimeException ex) {
            method = null;
         }
      }

      return level.getGameTime();
   }

   /** 0..23999, where 0 is sunrise. */
   public static long timeOfDay(Level level) {
      return Math.floorMod(dayTime(level), 24000L);
   }
}
