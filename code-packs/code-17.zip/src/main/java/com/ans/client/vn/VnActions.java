package com.ans.client.vn;

import com.ans.Ans;
import com.ans.client.mob.groups.VillagerNews;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.Random;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.MerchantScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

/** Reactions to what the player does: using, placing and breaking blocks, trading, and villager changes. */
public final class VnActions {
   private record Rule(String match, String[] groups) {
      boolean test(String path) {
         char c = match.charAt(0);
         String m = match.substring(1);
         return c == '=' ? path.equals(m) : path.contains(m);
      }
   }

   private static final List<Rule> USE = new ArrayList<>();
   private static final List<Rule> PLACE = new ArrayList<>();
   private static final List<Rule> BREAK = new ArrayList<>();
   private static final Map<String, String[]> WORK = new HashMap<>();
   private static final Map<String, String[]> EVENTS = new HashMap<>();
   private static final Map<String, String[]> CAST_MEET = new HashMap<>();
   private static final Map<String, String[]> SPEAKERS = new HashMap<>();
   private static final List<Rule> ATTACK = new ArrayList<>();
   private static final Map<Entity, Long> ATTACKED_AT = new WeakHashMap<>();
   private static String[] attackDefault;
   private static boolean installed;
   private static Entity tradingWith;
   private static int emeraldsAtOpen;
   private static final Random RANDOM = new Random();
   private static final long[] RECENT_BREAKS = new long[8];
   private static int breakIndex;
   private static long lastSpawnEgg = -100000L;
   private static final String[] DOOR_SHUT = {"pfelrr"};
   private static final String[] GATE_SHUT = {"pvwkxp"};
   private static final String[] CARVE = {"xemdbt"};
   private static final String[] CAMPFIRE_OUT = {"uvgkny"};
   private static final String[] CANDLE_OUT = {"repalq"};
   private static final String[] CHEST_AT_HOME = {"qfhrlh"};
   private static final String[] HARVEST = {"tdomqw"};
   private static final String[] HARVEST_FARMER = {"gytgzn"};
   private static final String[] MANY_BREAKS = {"awappv"};
   private static final String[] GOLEM_FRAME = {"gjsote"};
   private static final String[] ATTACK_HOME = {"lpuocy"};
   private static final String[] NAME_ADULT = {"spfsrr"};
   private static final String[] NAME_BABY = {"gzsztp"};
   private static final String[] LEAD = {"elexev"};
   private static final String[] BELL_BABY = {"nxalcz"};

   private VnActions() {
   }

   public static synchronized boolean recentAttack(Entity e, long now) {
      Long t = ATTACKED_AT.get(e);
      return t != null && now - t < 12L;
   }

   public static long lastSpawnEgg() {
      return lastSpawnEgg;
   }

   public static Entity tradingEntity() {
      return tradingWith;
   }

   /** Makes the villager nearest to the player react (used for things the player does that are not tied to a block). */
   public static void reactNearPlayer(Minecraft mc, String[] groups) {
      if (groups == null || mc.level == null || mc.player == null) {
         return;
      }

      LivingEntity best = null;
      double bestDist = 14.0 * 14.0;
      for (Entity e : mc.level.getEntities((Entity)null, mc.player.getBoundingBox().inflate(14.0), x -> x instanceof Villager)) {
         double d = e.distanceToSqr(mc.player);
         if (d < bestDist && e instanceof LivingEntity le && !le.isBaby()) {
            best = le;
            bestDist = d;
         }
      }

      if (best != null) {
         VnTriggers.react(best, groups);
      }
   }

   public static String[] events(String key) {
      return EVENTS.get(key);
   }

   public static String[] workGroups(String profession) {
      return WORK.get(profession);
   }

   public static String[] castMeet(String cast) {
      return CAST_MEET.get(cast);
   }

   public static String[] speakerGroups(String speaker) {
      return SPEAKERS.get(speaker);
   }

   public static synchronized void install() {
      if (installed) {
         return;
      }

      installed = true;
      load();
      UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
         Minecraft mc = Minecraft.getInstance();
         if (level != mc.level || player != mc.player || !VillagerNews.enabled()) {
            return InteractionResult.PASS;
         }

         BlockPos pos = hit.getBlockPos();
         BlockState state = level.getBlockState(pos);
         String block = BuiltInRegistries.BLOCK.getKey(state.getBlock()).getPath();
         ItemStack held = player.getItemInHand(hand);
         String heldPath = BuiltInRegistries.ITEM.getKey(held.getItem()).getPath();
         String[] groups = null;
         if (!player.isShiftKeyDown()) {
            groups = match(USE, block);
         }

         if (heldPath.endsWith("_spawn_egg")) {
            lastSpawnEgg = level.getGameTime();
         }

         String[] special = specialUse(mc, pos, state, block, heldPath);
         if (special != null) {
            groups = special;
         }

         if (block.equals("bell") && !player.isShiftKeyDown()) {
            babyHearsBell(mc);
         }

         if (held.getItem() instanceof BlockItem && heldPath.equals("iron_block")) {
            BlockPos placed = pos.relative(hit.getDirection());
            VnTriggers.later(4L, () -> checkGolemFrame(mc, placed));
         }

         if (groups == null && held.getItem() instanceof BlockItem) {
            groups = match(PLACE, BuiltInRegistries.ITEM.getKey(held.getItem()).getPath());
            if (groups == null) {
               groups = EVENTS.get("placeAny");
            }
         }

         if (block.contains("campfire") && held.has(net.minecraft.core.component.DataComponents.FOOD)) {
            groups = VnItemRules.list("cook");
         }

         react(mc, pos, groups);
         return InteractionResult.PASS;
      });
      AttackBlockCallback.EVENT.register((player, level, hand, pos, direction) -> {
         Minecraft mc = Minecraft.getInstance();
         if (level != mc.level || player != mc.player || !VillagerNews.enabled()) {
            return InteractionResult.PASS;
         }

         String block = BuiltInRegistries.BLOCK.getKey(level.getBlockState(pos).getBlock()).getPath();
         String[] groups = match(BREAK, block);
         if (groups == null) {
            groups = EVENTS.get("breakAny");
         }

         if (isCrop(block)) {
            groups = farmerNear(mc, pos) ? HARVEST_FARMER : HARVEST;
         }

         long nowTick = level.getGameTime();
         RECENT_BREAKS[breakIndex++ % RECENT_BREAKS.length] = nowTick;
         int quick = 0;
         for (long t : RECENT_BREAKS) {
            if (nowTick - t < 80L) {
               quick++;
            }
         }

         if (quick >= 6) {
            java.util.Arrays.fill(RECENT_BREAKS, -100000L);
            groups = MANY_BREAKS;
         }

         react(mc, pos, groups);
         return InteractionResult.PASS;
      });
      AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
         Minecraft mc = Minecraft.getInstance();
         if (level != mc.level || player != mc.player || !VillagerNews.enabled() || !(entity instanceof Villager v)) {
            return InteractionResult.PASS;
         }

         synchronized (VnActions.class) {
            ATTACKED_AT.put(entity, mc.level.getGameTime());
         }

         String[] groups;
         if (v.isBaby()) {
            groups = EVENTS.get("babyHurt");
         } else {
            groups = match(ATTACK, BuiltInRegistries.ITEM.getKey(player.getItemInHand(hand).getItem()).getPath());
            if (groups == null) {
               groups = attackDefault;
            }
         }

         if (!v.isBaby() && !level.canSeeSky(v.blockPosition()) && VnWatch.blockNear(mc, v.blockPosition(), 8, 3, "_bed")) {
            groups = ATTACK_HOME;
         }

         VnTriggers.react(v, groups);
         return InteractionResult.PASS;
      });
      UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
         Minecraft mc = Minecraft.getInstance();
         if (level != mc.level || player != mc.player || !VillagerNews.enabled()) {
            return InteractionResult.PASS;
         }

         if (entity.getType() == EntityTypes.SHEEP && entity instanceof LivingEntity sheep && VillagerNews.isWooly(entity)) {
            boolean shears = BuiltInRegistries.ITEM.getKey(player.getItemInHand(hand).getItem()).getPath().equals("shears");
            VnTriggers.react(sheep, EVENTS.get(shears ? "woolyShear" : "woolyInteract"));
            return InteractionResult.PASS;
         }

         if (entity.getType() == EntityTypes.SHEEP && !VillagerNews.isWooly(entity)
            && BuiltInRegistries.ITEM.getKey(player.getItemInHand(hand).getItem()).getPath().equals("shears")) {
            reactNearPlayer(mc, VnItemRules.list("shearSheep"));
            return InteractionResult.PASS;
         }

         ItemStack inHand = player.getItemInHand(hand);
         String inHandPath = BuiltInRegistries.ITEM.getKey(inHand.getItem()).getPath();
         if (inHandPath.equals("lead") && !(entity instanceof Villager) && entity instanceof LivingEntity) {
            reactNearPlayer(mc, LEAD);
         }

         if (!(entity instanceof Villager v)) {
            return InteractionResult.PASS;
         }

         if (inHandPath.equals("name_tag") && inHand.has(net.minecraft.core.component.DataComponents.CUSTOM_NAME)) {
            VnTriggers.react(v, v.isBaby() ? NAME_BABY : NAME_ADULT);
            return InteractionResult.PASS;
         }

         String heldPath = BuiltInRegistries.ITEM.getKey(player.getItemInHand(hand).getItem()).getPath();
         if (player.getItemInHand(hand).getItem() == com.ans.vn.item.VnItems.VILLAGER_NOSE
            && !v.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.OFFHAND).is(com.ans.vn.item.VnItems.VILLAGER_NOSE)) {
            VnTriggers.react(v, VnItemRules.list("noseSecond"));
            return InteractionResult.PASS;
         }

         if ((heldPath.equals("bread") || heldPath.equals("carrot") || heldPath.equals("potato") || heldPath.equals("beetroot"))
            && (v.isBaby() || player.isShiftKeyDown())) {
            String[] g = v.isBaby() ? VnItemRules.FOOD_BABY.get(heldPath) : VnItemRules.FOOD_ADULT.get(heldPath);
            if (g == null && !v.isBaby()) {
               g = VnItemRules.FOOD_ADULT.get("any");
            }

            VnTriggers.react(v, g);
            return InteractionResult.PASS;
         }

         String prof = profession(v);
         if (v.isBaby()) {
            VnTriggers.react(v, EVENTS.get("babyTrade"));
         } else if (prof.equals("nitwit")) {
            VnTriggers.react(v, EVENTS.get("nitwitTrade"));
         } else if (prof.equals("none")) {
            VnTriggers.react(v, EVENTS.get("unemployedTrade"));
         }

         return InteractionResult.PASS;
      });
      ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
         if (!(screen instanceof MerchantScreen) || !VillagerNews.enabled()) {
            return;
         }

         Entity target = client.crosshairPickEntity;
         tradingWith = target instanceof Villager ? target : null;
         emeraldsAtOpen = countEmeralds(client);
         if (tradingWith instanceof LivingEntity v) {
            String[] opening = VnWatch.tradeOpening(client, v);
            VnTriggers.react(v, opening != null ? opening : EVENTS.get("openTrade"));
         }

         ScreenEvents.remove(screen).register(closed -> {
            if (tradingWith instanceof LivingEntity v) {
               boolean bought = countEmeralds(client) != emeraldsAtOpen;
               VnTriggers.react(v, EVENTS.get(bought ? "closeBought" : "closeNot"));
            }

            tradingWith = null;
         });
      });
   }

   private static boolean isCrop(String block) {
      return block.equals("wheat") || block.equals("carrots") || block.equals("potatoes") || block.equals("beetroots")
         || block.equals("nether_wart") || block.equals("sweet_berry_bush");
   }

   private static boolean farmerNear(Minecraft mc, BlockPos pos) {
      for (Entity e : mc.level.getEntities((Entity)null, mc.player.getBoundingBox().inflate(12.0), x -> x instanceof Villager)) {
         if (e instanceof Villager v && !v.isBaby() && profession(v).equals("farmer")) {
            return true;
         }
      }

      return false;
   }

   /** Reactions that depend on the block's state (open, lit) or on what is held. */
   private static String[] specialUse(Minecraft mc, BlockPos pos, BlockState state, String block, String held) {
      boolean open = state.hasProperty(BlockStateProperties.OPEN) && state.getValue(BlockStateProperties.OPEN);
      boolean lit = state.hasProperty(BlockStateProperties.LIT) && state.getValue(BlockStateProperties.LIT);
      if (open && block.contains("fence_gate")) {
         return GATE_SHUT;
      }

      if (open && block.endsWith("_door") && villagerNear(mc, pos, 2.5)) {
         return DOOR_SHUT;
      }

      if (block.equals("pumpkin") && held.equals("shears")) {
         return CARVE;
      }

      if (block.contains("campfire") && lit && held.endsWith("_shovel")) {
         return CAMPFIRE_OUT;
      }

      if (block.endsWith("candle") && lit && held.equals("air")) {
         return CANDLE_OUT;
      }

      if ((block.equals("chest") || block.equals("barrel") || block.equals("trapped_chest"))
         && !mc.level.canSeeSky(pos) && villagerNear(mc, pos, 7.0) && RANDOM.nextInt(2) == 0) {
         return CHEST_AT_HOME;
      }

      return null;
   }

   private static boolean villagerNear(Minecraft mc, BlockPos pos, double range) {
      return !mc.level.getEntities(
         (Entity)null, new net.minecraft.world.phys.AABB(pos).inflate(range), x -> x instanceof Villager && !((Villager)x).isBaby()
      ).isEmpty();
   }

   private static void babyHearsBell(Minecraft mc) {
      for (Entity e : mc.level.getEntities((Entity)null, mc.player.getBoundingBox().inflate(24.0), x -> x instanceof Villager)) {
         if (e instanceof Villager v && v.isBaby()) {
            VnTriggers.react(v, BELL_BABY);
            return;
         }
      }
   }

   /** After an iron block was placed: is there now the T-shaped body of an iron golem? */
   private static void checkGolemFrame(Minecraft mc, BlockPos placed) {
      if (mc.level == null) {
         return;
      }

      for (int dx = -1; dx <= 1; dx++) {
         for (int dy = -1; dy <= 1; dy++) {
            for (int dz = -1; dz <= 1; dz++) {
               BlockPos c = placed.offset(dx, dy, dz);
               if (!iron(mc, c) || !iron(mc, c.below())) {
                  continue;
               }

               boolean armsX = iron(mc, c.east()) && iron(mc, c.west());
               boolean armsZ = iron(mc, c.north()) && iron(mc, c.south());
               if (armsX || armsZ) {
                  reactNearPlayer(mc, GOLEM_FRAME);
                  return;
               }
            }
         }
      }
   }

   private static boolean iron(Minecraft mc, BlockPos pos) {
      return BuiltInRegistries.BLOCK.getKey(mc.level.getBlockState(pos).getBlock()).getPath().equals("iron_block");
   }

   public static String profession(Villager v) {
      String name = v.getVillagerData().profession().getRegisteredName();
      return name.substring(name.indexOf(':') + 1);
   }

   private static int countEmeralds(Minecraft mc) {
      if (mc.player == null) {
         return 0;
      }

      int total = 0;
      for (int i = 0; i < mc.player.getInventory().getContainerSize(); i++) {
         ItemStack s = mc.player.getInventory().getItem(i);
         if (!s.isEmpty() && BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().equals("emerald")) {
            total += s.getCount();
         }
      }

      return total;
   }

   private static String[] match(List<Rule> rules, String path) {
      for (Rule r : rules) {
         if (r.test(path)) {
            return r.groups();
         }
      }

      return null;
   }

   private static void react(Minecraft mc, BlockPos pos, String[] groups) {
      if (groups == null || mc.level == null) {
         return;
      }

      LivingEntity best = null;
      double bestDist = 14.0 * 14.0;
      for (Entity e : mc.level.getEntities((Entity)null, mc.player.getBoundingBox().inflate(14.0), x -> x instanceof Villager)) {
         double d = e.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
         if (d < bestDist && e instanceof LivingEntity le && !le.isBaby() && le.hasLineOfSight(mc.player)) {
            best = le;
            bestDist = d;
         }
      }

      if (best != null) {
         VnTriggers.react(best, groups);
      }
   }

   private static String[] ids(JsonElement e) {
      JsonArray a = e.getAsJsonArray();
      String[] r = new String[a.size()];
      for (int i = 0; i < r.length; i++) {
         r[i] = a.get(i).getAsString();
      }

      return r;
   }

   private static void rules(JsonObject root, String key, List<Rule> into) {
      for (JsonElement e : root.getAsJsonArray(key)) {
         JsonObject o = e.getAsJsonObject();
         into.add(new Rule(o.get("m").getAsString(), ids(o.get("g"))));
      }
   }

   private static void load() {
      try (InputStream in = VnActions.class.getResourceAsStream("/assets/ans/vn/actions.json");
         Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
         JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
         rules(root, "use", USE);
         rules(root, "place", PLACE);
         rules(root, "break", BREAK);
         for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("work").entrySet()) {
            WORK.put(e.getKey(), ids(e.getValue()));
         }

         for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("events").entrySet()) {
            if (e.getValue().isJsonArray()) {
               EVENTS.put(e.getKey(), ids(e.getValue()));
            }
         }

         for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("cast").entrySet()) {
            CAST_MEET.put(e.getKey(), ids(e.getValue().getAsJsonObject().get("meet")));
         }

         for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("speakers").entrySet()) {
            SPEAKERS.put(e.getKey(), ids(e.getValue()));
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News action rules could not be loaded: {}", ex.toString());
      }

      try (InputStream in = VnActions.class.getResourceAsStream("/assets/ans/vn/more.json");
         Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
         JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
         for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("events").entrySet()) {
            EVENTS.put(e.getKey(), ids(e.getValue()));
         }

         rules(root, "attack", ATTACK);
         attackDefault = ids(root.get("attackDefault"));
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News extra rules could not be loaded: {}", ex.toString());
      }

      try (InputStream in = VnActions.class.getResourceAsStream("/assets/ans/vn/more2.json");
         Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
         JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
         // these go in front of the older rules, because the older ones match broad names like "snow" or "brick"
         for (String key : new String[]{"use", "place", "break"}) {
            if (root.has(key)) {
               List<Rule> extra = new ArrayList<>();
               rules(root, key, extra);
               (key.equals("use") ? USE : key.equals("place") ? PLACE : BREAK).addAll(0, extra);
            }
         }
      } catch (IOException | RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News more2 rules could not be loaded: {}", ex.toString());
      }
   }
}
