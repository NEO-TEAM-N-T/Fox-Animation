package com.ans.client.mob.groups;

import com.ans.client.molang.BedrockProperties;
import com.ans.client.molang.PackSettings;
import net.minecraft.client.Minecraft;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.npc.villager.Villager;
import org.jspecify.annotations.Nullable;

/**
 * Villager News entity properties (the Bedrock "p:" properties). Every property starts at the
 * default declared by the original behavior pack; the dialogue system overrides them per entity.
 */
public final class VnProperties {
   private static final Map<Entity, Map<String, Object>> OVERRIDES = new WeakHashMap<>();

   private VnProperties() {
   }

   public static synchronized void set(Entity entity, String name, @Nullable Object value) {
      Map<String, Object> m = OVERRIDES.computeIfAbsent(entity, k -> new java.util.HashMap<>());
      if (value == null) {
         m.remove(name);
      } else {
         m.put(name, value);
      }
   }

   private static synchronized @Nullable Object override(Entity entity, String name) {
      Map<String, Object> m = OVERRIDES.get(entity);
      return m == null ? null : m.get(name);
   }

   private static void defaults(EntityType<? extends Entity> type, String name, Object value) {
      BedrockProperties.register(type, name, e -> {
         Object o = override(e, name);
         return o != null ? o : value;
      });
   }


   private static int ridingMode(Entity e) {
      Entity v = e.getVehicle();
      if (v == null) {
         return 0;
      }

      String path = EntityType.getKey(v.getType()).getPath();
      if (path.contains("boat")) {
         return 1;
      }

      return path.contains("minecart") ? 2 : 0;
   }

   private static Object stateFlags(Entity e) {
      boolean sleeping = e instanceof LivingEntity l && l.isSleeping();
      return 1000 * (sleeping ? 1 : 0) + 100 * (e.onGround() ? 1 : 0) + 10 * (e.isInWater() ? 1 : 0) + ridingMode(e);
   }

   private static void live(EntityType<? extends Entity> type) {
      BedrockProperties.register(type, "p:fsjsbp", e -> {
         Object o = override(e, "p:fsjsbp");
         return o != null ? o : stateFlags(e);
      });
      BedrockProperties.register(type, "p:enczhb", e -> {
         Object o = override(e, "p:enczhb");
         return o != null ? o : ridingMode(e);
      });
   }

   public static void register() {
      defaults(EntityTypes.VILLAGER, "p:bvkgap", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:cdpyit", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:difficulty", 0);
      defaults(EntityTypes.VILLAGER, "p:enczhb", 0);
      defaults(EntityTypes.VILLAGER, "p:fsjsbp", 0);
      defaults(EntityTypes.VILLAGER, "p:gcfsvg", Boolean.TRUE);
      defaults(EntityTypes.VILLAGER, "p:ihxrtl", 0);
      defaults(EntityTypes.VILLAGER, "p:kwtyoa", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:mlxeez", "none");
      defaults(EntityTypes.VILLAGER, "p:mreyue", -1);
      defaults(EntityTypes.VILLAGER, "p:mrlyfj", "clear");
      defaults(EntityTypes.VILLAGER, "p:nhncnz", Boolean.TRUE);
      defaults(EntityTypes.VILLAGER, "p:olbxcw", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:pmpece", 0);
      defaults(EntityTypes.VILLAGER, "p:rynvcz", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:sbkmbc", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:sign", -1);
      defaults(EntityTypes.VILLAGER, "p:twjrsp", Boolean.FALSE);
      defaults(EntityTypes.VILLAGER, "p:wjnyei", 0);
      defaults(EntityTypes.VILLAGER, "p:zsuvyv", Boolean.FALSE);
      defaults(EntityTypes.WANDERING_TRADER, "p:bvkgap", Boolean.FALSE);
      defaults(EntityTypes.WANDERING_TRADER, "p:difficulty", 0);
      defaults(EntityTypes.WANDERING_TRADER, "p:floige", Boolean.TRUE);
      defaults(EntityTypes.WANDERING_TRADER, "p:gcfsvg", Boolean.TRUE);
      defaults(EntityTypes.WANDERING_TRADER, "p:kwtyoa", Boolean.FALSE);
      defaults(EntityTypes.WANDERING_TRADER, "p:mrlyfj", "clear");
      defaults(EntityTypes.WANDERING_TRADER, "p:pmpece", 0);
      defaults(EntityTypes.WANDERING_TRADER, "p:rynvcz", Boolean.FALSE);
      defaults(EntityTypes.WANDERING_TRADER, "p:twjrsp", Boolean.FALSE);
      defaults(EntityTypes.SHEEP, "p:gmtjzx", Boolean.FALSE);
      defaults(EntityTypes.SHEEP, "p:gwvveg", Boolean.TRUE);
      defaults(EntityTypes.SHEEP, "p:pmpece", 0);
      live(EntityTypes.VILLAGER);
      live(EntityTypes.WANDERING_TRADER);
      BedrockProperties.register(EntityTypes.VILLAGER, "p:gcfsvg", e -> {
         Object o = override(e, "p:gcfsvg");
         return o != null ? o : Boolean.valueOf(!e.getItemBySlot(EquipmentSlot.OFFHAND).is(com.ans.vn.item.VnItems.VILLAGER_NOSE));
      });
      BedrockProperties.register(EntityTypes.VILLAGER, "p:mlxeez", e -> {
         Object o = override(e, "p:mlxeez");
         if (o != null) {
            return o;
         }

         String code = com.ans.vn.item.VnItems.cosmeticCode(e.getItemBySlot(EquipmentSlot.HEAD));
         if (code == null) {
            code = com.ans.vn.item.VnItems.cosmeticCode(e.getItemBySlot(EquipmentSlot.MAINHAND));
         }

         return code == null ? "none" : code;
      });
      BedrockProperties.register(EntityTypes.VILLAGER, "p:sign", e -> {
         Object o = override(e, "p:sign");
         if (o != null) {
            return o;
         }

         String path = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(e.getItemBySlot(EquipmentSlot.MAINHAND).getItem()).getPath();
         return Integer.valueOf(com.ans.vn.item.VnVillagerItems.SIGNS.indexOf(path));
      });
      BedrockProperties.register(EntityTypes.VILLAGER, "p:mreyue", e -> {
         Object o = override(e, "p:mreyue");
         return o != null ? o : Integer.valueOf(Math.max(0, Math.min(4, e.getVillagerData().level() - 1)));
      });
      BedrockProperties.register(EntityTypes.VILLAGER, "p:nhncnz", e -> {
         Object o = override(e, "p:nhncnz");
         return o != null ? o : Boolean.valueOf(!e.isDeadOrDying());
      });
      // villager style (setting) and the direction the villager glances at the nearest player
      BedrockProperties.register(EntityTypes.VILLAGER, "p:pmpece", e -> {
         Object o = override(e, "p:pmpece");
         return o != null ? o : Integer.valueOf(styleIndex());
      });
      BedrockProperties.register(EntityTypes.WANDERING_TRADER, "p:pmpece", e -> {
         Object o = override(e, "p:pmpece");
         return o != null ? o : Integer.valueOf(styleIndex());
      });
      BedrockProperties.register(EntityTypes.SHEEP, "p:pmpece", e -> {
         Object o = override(e, "p:pmpece");
         return o != null ? o : Integer.valueOf(styleIndex());
      });
      BedrockProperties.register(EntityTypes.VILLAGER, "p:ihxrtl", e -> {
         Object o = override(e, "p:ihxrtl");
         return o != null ? o : Integer.valueOf(glanceBin(e));
      });
   }

   public static final String STYLE_SETTING = "oreville_ans:villagerstyle";
   public static final String GLANCE_SETTING = "oreville_ans:vnglance";

   /** 0 = Vanilla, 1 = Actions & Stuff, 2 = Actions & Stuff: Flat. */
   private static int styleIndex() {
      return switch (PackSettings.value(STYLE_SETTING)) {
         case "actions_stuff" -> 1;
         case "flat" -> 2;
         default -> 0;
      };
   }

   /**
    * Which way the villager looks at the nearest player, in the five directions its animations know:
    * 1 = ahead (or too far), 2 and 4 = over the left/right shoulder, 3 and 5 = to the side.
    */
   private static int glanceBin(Entity e) {
      Minecraft mc = Minecraft.getInstance();
      String setting = PackSettings.value(GLANCE_SETTING);
      if (mc.player == null || (!setting.isEmpty() && !PackSettings.enabled(GLANCE_SETTING))) {
         return 1;
      }

      double rx = mc.player.getX() - e.getX();
      double rz = mc.player.getZ() - e.getZ();
      if (rx * rx + rz * rz > 16.0 * 16.0) {
         return 1;
      }

      double yaw = Math.toRadians(e instanceof LivingEntity l ? l.yHeadRot : e.getYRot());
      double tx = -Math.sin(yaw);
      double tz = Math.cos(yaw);
      double cross = tx * rz - tz * rx;
      double dot = tx * rx + tz * rz;
      double deg = Math.toDegrees(Math.atan2(cross, dot));
      if (deg < 0.0) {
         deg += 360.0;
      }

      if (deg >= 75.0 && deg <= 105.0) {
         return 3;
      }

      if (deg >= 255.0 && deg <= 285.0) {
         return 5;
      }

      if (deg >= 105.0 && deg <= 165.0) {
         return 2;
      }

      return deg >= 195.0 && deg <= 255.0 ? 4 : 1;
   }
}
