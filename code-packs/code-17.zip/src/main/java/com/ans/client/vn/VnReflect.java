package com.ans.client.vn;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import net.minecraft.world.entity.LivingEntity;

/** Small reflection helpers for game methods whose names differ between versions. Every call fails soft. */
public final class VnReflect {
   private static final Map<String, Method> CACHE = new HashMap<>();

   private VnReflect() {
   }

   private static Class<?> box(Class<?> c) {
      if (!c.isPrimitive()) {
         return c;
      }

      if (c == int.class) {
         return Integer.class;
      }

      if (c == long.class) {
         return Long.class;
      }

      if (c == boolean.class) {
         return Boolean.class;
      }

      if (c == double.class) {
         return Double.class;
      }

      return c == float.class ? Float.class : c;
   }

   private static Method find(Class<?> type, String name, Object[] args) {
      String key = type.getName() + "#" + name + "#" + args.length;
      synchronized (CACHE) {
         if (CACHE.containsKey(key)) {
            return CACHE.get(key);
         }
      }

      Method found = null;
      for (Method m : type.getMethods()) {
         if (!m.getName().equals(name) || m.getParameterCount() != args.length) {
            continue;
         }

         Class<?>[] pt = m.getParameterTypes();
         boolean ok = true;
         for (int i = 0; i < pt.length; i++) {
            if (args[i] != null && !box(pt[i]).isInstance(args[i])) {
               ok = false;
               break;
            }
         }

         if (ok) {
            found = m;
            break;
         }
      }

      synchronized (CACHE) {
         CACHE.put(key, found);
      }

      return found;
   }

   /** Calls a public method by name; returns null when it does not exist or fails. */
   public static Object invoke(Object target, String name, Object... args) {
      if (target == null) {
         return null;
      }

      try {
         Method m = find(target.getClass(), name, args);
         return m == null ? null : m.invoke(target, args);
      } catch (ReflectiveOperationException | RuntimeException ex) {
         return null;
      }
   }

   public static boolean bool(Object target, String name) {
      return Boolean.TRUE.equals(invoke(target, name));
   }

   public static int integer(Object target, String name, int fallback, Object... args) {
      Object o = invoke(target, name, args);
      return o instanceof Number n ? n.intValue() : fallback;
   }

   /** Lower-case id of the last damage a living entity took ("fall", "cactus", "inwall", "indirectmagic" ...), or "". */
   public static String damageId(LivingEntity e) {
      Object src = invoke(e, "getLastDamageSource");
      if (src == null) {
         return "";
      }

      Object id = invoke(src, "getMsgId");
      if (id == null) {
         id = invoke(invoke(src, "type"), "msgId");
      }

      return id == null ? "" : id.toString().toLowerCase(Locale.ROOT).replace("_", "");
   }
}
