package com.ans.client.vn;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import java.util.Locale;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** In-game handbook (/vnhandbook) and quick spawn helper (/vnspawn). */
public final class VnHandbook {
   private static String pending;

   private VnHandbook() {
   }

   /** Opens the book on the next tick, after a closing chat screen can no longer replace it. */
   public static void tick(Minecraft mc) {
      if (pending != null && mc.level != null) {
         String search = pending;
         pending = null;
         VnBookScreen.open(search);
      }
   }

   public static void install() {
      com.ans.vn.item.VnItems.openHandbook = () -> pending = "";
      ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
         dispatcher.register(
            ClientCommands.literal("vnhandbook")
               .executes(ctx -> {
                  handbook(ctx, "");
                  return 1;
               })
               .then(
                  ClientCommands.argument("search", StringArgumentType.greedyString())
                     .executes(ctx -> {
                        handbook(ctx, StringArgumentType.getString(ctx, "search"));
                        return 1;
                     })
               )
         );
         dispatcher.register(
            ClientCommands.literal("vnspawn")
               .executes(ctx -> {
                  ctx.getSource().sendFeedback(Component.literal("Use /vnspawn <mayor|testificate|villager5|villager9|unreachable|villager|trader|wooly> (needs cheats)"));
                  return 1;
               })
               .then(
                  ClientCommands.argument("who", StringArgumentType.word())
                     .executes(ctx -> {
                        spawn(ctx, StringArgumentType.getString(ctx, "who"));
                        return 1;
                     })
               )
         );
      });
   }

   private static void handbook(CommandContext<FabricClientCommandSource> ctx, String query) {
      FabricClientCommandSource src = ctx.getSource();
      String q = query.trim();
      if (!q.isEmpty() && VnBookScreen.find(q) == null) {
         src.sendFeedback(Component.literal("§7No handbook entry matches \"" + query + "\"."));
         return;
      }

      pending = q;
   }

   private static void spawn(CommandContext<FabricClientCommandSource> ctx, String who) {
      String command;
      switch (who.toLowerCase(Locale.ROOT)) {
         case "mayor" -> command = "summon minecraft:villager ~ ~ ~ {CustomName:\"Mayor Villager\"}";
         case "testificate" -> command = "summon minecraft:villager ~ ~ ~ {CustomName:\"Testificate Man\"}";
         case "villager5" -> command = "summon minecraft:villager ~ ~ ~ {CustomName:\"Villager Number 5\"}";
         case "villager9" -> command = "summon minecraft:villager ~ ~ ~ {CustomName:\"Villager Number 9\"}";
         case "unreachable" -> command = "summon minecraft:villager ~ ~ ~ {CustomName:\"Villager Unreachable\"}";
         case "villager" -> command = "summon minecraft:villager ~ ~ ~";
         case "trader" -> command = "summon minecraft:wandering_trader ~ ~ ~";
         case "wooly" -> command = "summon minecraft:sheep ~ ~ ~ {CustomName:\"Wooly\"}";
         default -> {
            ctx.getSource().sendFeedback(Component.literal("§7Unknown. Use mayor, testificate, villager5, villager9, unreachable, villager, trader or wooly."));
            return;
         }
      }

      Minecraft mc = Minecraft.getInstance();
      if (mc.getConnection() != null) {
         mc.getConnection().sendCommand(command);
      }
   }
}
