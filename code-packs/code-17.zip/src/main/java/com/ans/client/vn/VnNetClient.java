package com.ans.client.vn;

import com.ans.Ans;
import com.ans.vn.net.VnNet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

/** What the server told us about villagers: reputation of this player and raids. */
public final class VnNetClient {
   public static final int UNKNOWN = Integer.MIN_VALUE;

   private record Info(int reputation, int flags, long tick) {
   }

   private static final Map<Integer, Info> INFO = new HashMap<>();
   private static boolean installed;

   private VnNetClient() {
   }

   public static synchronized void install() {
      if (installed) {
         return;
      }

      installed = true;
      try {
         ClientPlayNetworking.registerGlobalReceiver(VnNet.InfoPayload.TYPE, (payload, context) -> accept(payload.data()));
      } catch (RuntimeException ex) {
         Ans.LOGGER.warn("[ans] Villager News: no server information (the server does not have the mod): {}", ex.toString());
      }
   }

   private static synchronized void accept(List<Integer> data) {
      Minecraft mc = Minecraft.getInstance();
      long now = mc.level == null ? 0L : mc.level.getGameTime();
      if (INFO.size() > 400) {
         INFO.clear();
      }

      for (int i = 0; i + 2 < data.size(); i += 3) {
         INFO.put(data.get(i), new Info(data.get(i + 1), data.get(i + 2), now));
      }
   }

   private static synchronized Info info(Entity e) {
      Minecraft mc = Minecraft.getInstance();
      Info i = INFO.get(e.getId());
      if (i == null || mc.level == null || mc.level.getGameTime() - i.tick() > 400L) {
         return null;
      }

      return i;
   }

   /** Reputation of the player with this villager, or UNKNOWN. */
   public static int reputation(Entity e) {
      Info i = info(e);
      return i == null ? UNKNOWN : i.reputation();
   }

   public static boolean raid(Entity e) {
      Info i = info(e);
      return i != null && (i.flags() & 1) != 0;
   }

   /** -2 extremely low, -1 low, 0 normal or unknown, 1 high, 2 extremely high. */
   public static int tier(Entity e) {
      int r = reputation(e);
      if (r == UNKNOWN) {
         return 0;
      }

      if (r >= 60) {
         return 2;
      }

      if (r >= 15) {
         return 1;
      }

      if (r <= -60) {
         return -2;
      }

      return r <= -15 ? -1 : 0;
   }
}
