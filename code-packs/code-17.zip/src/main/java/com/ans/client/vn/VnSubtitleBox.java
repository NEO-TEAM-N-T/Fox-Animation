package com.ans.client.vn;

import com.ans.Ans;
import com.ans.client.molang.PackSettings;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/** The subtitle box: the spoken line in a dark box above the hotbar, with the speaker's name. */
public final class VnSubtitleBox {
   public static final String SETTING = "oreville_ans:vnsubtitles";
   private static boolean ready;
   private static String speaker = "";
   private static String text;
   private static long until;
   private static long shownAt;

   private VnSubtitleBox() {
   }

   /** "box" (default), "actionbar" or "off". */
   public static String mode() {
      String v = PackSettings.value(SETTING);
      return v.isEmpty() ? "box" : v;
   }

   public static boolean ready() {
      return ready;
   }

   /** The hud element hook is looked up by name so a renamed Fabric method only switches the box off. */
   public static void install() {
      try {
         Class<?> registry = Class.forName("net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry");
         Class<?> element = Class.forName("net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement");
         Object proxy = Proxy.newProxyInstance(element.getClassLoader(), new Class<?>[]{element}, (self, method, args) -> {
            if (method.getDeclaringClass() == Object.class) {
               return switch (method.getName()) {
                  case "hashCode" -> (Object)Integer.valueOf(System.identityHashCode(self));
                  case "equals" -> (Object)Boolean.valueOf(args != null && args.length > 0 && self == args[0]);
                  default -> "VnSubtitleBox";
               };
            }

            if (args != null) {
               for (Object o : args) {
                  if (o instanceof GuiGraphicsExtractor g) {
                     try {
                        draw(g);
                     } catch (RuntimeException ex) {
                        // never let a subtitle break the hud
                     }

                     break;
                  }
               }
            }

            return null;
         });
         Method add = registry.getMethod("addLast", Identifier.class, element);
         add.invoke(null, Ans.id("vn_subtitles"), proxy);
         ready = true;
         Ans.LOGGER.info("[ans] Villager News subtitle box registered");
      } catch (ReflectiveOperationException | RuntimeException | LinkageError ex) {
         Ans.LOGGER.warn("[ans] Villager News subtitle box is not available, the action bar is used: {}", ex.toString());
      }
   }

   public static void set(String who, Component line) {
      String s = line.getString();
      if (s.isEmpty()) {
         return;
      }

      speaker = who == null ? "" : who;
      text = s;
      shownAt = System.currentTimeMillis();
      until = shownAt + Math.max(2200L, 1200L + 55L * s.length());
   }

   private static List<String> wrap(Font font, String s, int maxWidth) {
      List<String> lines = new ArrayList<>();
      StringBuilder cur = new StringBuilder();
      for (String word : s.split(" ")) {
         String trial = cur.length() == 0 ? word : cur + " " + word;
         if (font.width(trial) > maxWidth && cur.length() > 0) {
            lines.add(cur.toString());
            cur = new StringBuilder(word);
         } else {
            cur = new StringBuilder(trial);
         }
      }

      if (cur.length() > 0) {
         lines.add(cur.toString());
      }

      return lines;
   }

   private static void draw(GuiGraphicsExtractor g) {
      if (text == null || !mode().equals("box")) {
         return;
      }

      long now = System.currentTimeMillis();
      if (now > until) {
         text = null;
         return;
      }

      Minecraft mc = Minecraft.getInstance();
      Font font = mc.font;
      int sw = mc.getWindow().getGuiScaledWidth();
      int sh = mc.getWindow().getGuiScaledHeight();
      float fadeOut = Math.min(1.0F, (until - now) / 350.0F);
      float fadeIn = Math.min(1.0F, (now - shownAt) / 120.0F);
      float fade = Math.max(0.0F, Math.min(fadeOut, fadeIn));
      List<String> lines = wrap(font, text, Math.min(300, sw - 48));
      int widest = speaker.isEmpty() ? 0 : font.width(speaker);
      for (String l : lines) {
         widest = Math.max(widest, font.width(l));
      }

      int lineHeight = 11;
      int boxW = widest + 20;
      int boxH = 8 + (speaker.isEmpty() ? 0 : lineHeight + 2) + lines.size() * lineHeight;
      int x0 = (sw - boxW) / 2;
      int y0 = sh - 78 - boxH;
      int back = ((int)(190.0F * fade) << 24) | 0x101018;
      int edge = ((int)(220.0F * fade) << 24) | 0xC9A227;
      int white = ((int)(255.0F * fade) << 24) | 0xFFFFFF;
      int gold = ((int)(255.0F * fade) << 24) | 0xFFD25A;
      g.fill(x0, y0, x0 + boxW, y0 + boxH, back);
      g.outline(x0, y0, boxW, boxH, edge);
      int y = y0 + 5;
      if (!speaker.isEmpty()) {
         g.centeredText(font, Component.literal(speaker), sw / 2, y, gold);
         y += lineHeight + 2;
      }

      for (String l : lines) {
         g.centeredText(font, Component.literal(l), sw / 2, y, white);
         y += lineHeight;
      }
   }
}
