package com.ans.client.vn;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

/** The Villager News handbook as a book: a cover, then one page per situation, in alphabetical order. */
public final class VnBookScreen extends Screen {
   private record Entry(String title, List<String[]> parts) {
   }

   private static List<Entry> entries;
   private int spread;
   private Button prev;
   private Button next;
   private final List<Button> letters = new ArrayList<>();
   private int bookLeft;
   private int bookTop;
   private int bookWidth;
   private int bookHeight;

   public VnBookScreen(String search) {
      super(Component.translatable("text.ans_vn.book.title"));
      load();
      this.spread = Math.max(0, pageFor(search) / 2);
   }

   public static void open(String search) {
      Minecraft.getInstance().gui.setScreen(new VnBookScreen(search));
   }

   /** Number of situations in the book. */
   public static int count() {
      load();
      return entries.size();
   }

   /** The first entry whose title contains the text, or null. */
   public static String find(String search) {
      load();
      String q = search.trim().toLowerCase(Locale.ROOT);
      for (Entry e : entries) {
         if (e.title().toLowerCase(Locale.ROOT).equals(q)) {
            return e.title();
         }
      }

      for (Entry e : entries) {
         if (e.title().toLowerCase(Locale.ROOT).contains(q)) {
            return e.title();
         }
      }

      return null;
   }

   private static synchronized void load() {
      if (entries != null) {
         return;
      }

      List<Entry> list = new ArrayList<>();
      for (VnSpeech.Group g : VnSpeech.groups()) {
         if (g.title().isEmpty()) {
            continue;
         }

         List<String[]> parts = new ArrayList<>();
         for (String seg : g.body().split("\n\n")) {
            if (seg.startsWith("§e")) {
               parts.add(new String[]{"h", seg.substring(2)});
            } else if (seg.startsWith("§7")) {
               parts.add(new String[]{"t", seg.substring(2)});
            } else if (!seg.isBlank()) {
               parts.add(new String[]{"t", seg});
            }
         }

         list.add(new Entry(g.title(), parts));
      }

      list.sort((a, b) -> a.title().compareToIgnoreCase(b.title()));
      entries = list;
   }

   /** Page number (0 = cover, 1 = first entry) for a search text; 0 when nothing is searched for or found. */
   private static int pageFor(String search) {
      if (search == null || search.isBlank()) {
         return 0;
      }

      String found = find(search);
      for (int i = 0; found != null && i < entries.size(); i++) {
         if (entries.get(i).title().equals(found)) {
            return i + 1;
         }
      }

      return 0;
   }

   private int spreads() {
      return (entries.size() + 2) / 2;
   }

   @Override
   protected void init() {
      this.bookWidth = Math.min(this.width - 24, 400);
      this.bookHeight = Math.min(this.height - 80, 220);
      this.bookLeft = (this.width - this.bookWidth) / 2;
      this.bookTop = 10;
      int rowY = this.bookTop + this.bookHeight + 10;
      this.prev = this.addRenderableWidget(Button.builder(Component.translatable("text.ans_vn.book.prev"), b -> turn(-1)).bounds(this.width / 2 - 112, rowY, 70, 18).build());
      this.addRenderableWidget(Button.builder(Component.translatable("text.ans_vn.book.close"), b -> this.onClose()).bounds(this.width / 2 - 35, rowY, 70, 18).build());
      this.next = this.addRenderableWidget(Button.builder(Component.translatable("text.ans_vn.book.next"), b -> turn(1)).bounds(this.width / 2 + 42, rowY, 70, 18).build());
      this.letters.clear();
      String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
      int perRow = 13;
      int size = 15;
      int startX = (this.width - perRow * size) / 2;
      for (int i = 0; i < alphabet.length(); i++) {
         char c = alphabet.charAt(i);
         int x = startX + (i % perRow) * size;
         int y = rowY + 24 + (i / perRow) * size;
         Button b = Button.builder(Component.literal(String.valueOf(c)), btn -> jump(c)).bounds(x, y, size - 1, size - 1).build();
         b.active = hasLetter(c);
         this.letters.add(this.addRenderableWidget(b));
      }
   }

   private boolean hasLetter(char c) {
      for (Entry e : entries) {
         if (Character.toUpperCase(e.title().charAt(0)) == c) {
            return true;
         }
      }

      return false;
   }

   private void jump(char c) {
      for (int i = 0; i < entries.size(); i++) {
         if (Character.toUpperCase(entries.get(i).title().charAt(0)) == c) {
            this.spread = (i + 1) / 2;
            return;
         }
      }
   }

   private void turn(int by) {
      this.spread = Math.max(0, Math.min(spreads() - 1, this.spread + by));
   }

   @Override
   public boolean keyPressed(KeyEvent event) {
      if (event.isLeft()) {
         turn(-1);
         return true;
      }

      if (event.isRight()) {
         turn(1);
         return true;
      }

      return super.keyPressed(event);
   }

   @Override
   public void onClose() {
      Minecraft.getInstance().gui.setScreen(null);
   }

   @Override
   public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
      super.extractBackground(g, mouseX, mouseY, delta);
      this.prev.active = this.spread > 0;
      this.next.active = this.spread < spreads() - 1;
      int l = this.bookLeft;
      int t = this.bookTop;
      int w = this.bookWidth;
      int h = this.bookHeight;
      int mid = l + w / 2;
      g.fill(l - 5, t - 5, l + w + 5, t + h + 5, 0xFF4A2E14);
      g.fill(l, t, mid, t + h, 0xFFE8D7A3);
      g.fill(mid, t, l + w, t + h, 0xFFE8D7A3);
      g.fill(mid - 1, t, mid + 1, t + h, 0xFF9A7A45);
      g.outline(l - 5, t - 5, w + 10, h + 10, 0xFF2A1A0A);
      int pageWidth = w / 2 - 26;
      drawPage(g, this.spread * 2, l + 14, t + 12, pageWidth, h - 28);
      drawPage(g, this.spread * 2 + 1, mid + 12, t + 12, pageWidth, h - 28);
   }

   private void drawPage(GuiGraphicsExtractor g, int page, int x, int y, int w, int h) {
      if (page > entries.size()) {
         return;
      }

      int bottom = y + h;
      int cy = y;
      if (page == 0) {
         cy = line(g, Component.translatable("text.ans_vn.book.title").getString(), x, cy, w, 0xFF7A4A00, bottom);
         cy += 6;
         cy = line(g, entries.size() + " " + Component.translatable("text.ans_vn.book.situations").getString(), x, cy, w, 0xFF3B2F1E, bottom);
         cy += 6;
         line(g, Component.translatable("text.ans_vn.book.hint").getString(), x, cy, w, 0xFF5A4A33, bottom);
      } else {
         Entry e = entries.get(page - 1);
         cy = line(g, e.title(), x, cy, w, 0xFF7A4A00, bottom);
         cy += 5;
         for (String[] p : e.parts()) {
            cy = line(g, p[1], x, cy, w, p[0].equals("h") ? 0xFF8A5A00 : 0xFF3B2F1E, bottom);
            cy += p[0].equals("h") ? 1 : 5;
         }
      }

      String number = String.valueOf(page + 1);
      g.centeredText(this.font, Component.literal(number), x + w / 2, bottom + 4, 0xFF7A6A4A);
   }

   /** Draws wrapped, left-aligned text and returns the next free y. Only centred text is drawn, so the centre is computed. */
   private int line(GuiGraphicsExtractor g, String text, int x, int y, int width, int color, int bottom) {
      StringBuilder cur = new StringBuilder();
      List<String> lines = new ArrayList<>();
      for (String word : text.split(" ")) {
         String trial = cur.length() == 0 ? word : cur + " " + word;
         if (this.font.width(trial) > width && cur.length() > 0) {
            lines.add(cur.toString());
            cur = new StringBuilder(word);
         } else {
            cur = new StringBuilder(trial);
         }
      }

      if (cur.length() > 0) {
         lines.add(cur.toString());
      }

      for (String l : lines) {
         if (y + 9 > bottom) {
            return y;
         }

         g.centeredText(this.font, Component.literal(l), x + this.font.width(l) / 2, y, color);
         y += 11;
      }

      return y;
   }
}
