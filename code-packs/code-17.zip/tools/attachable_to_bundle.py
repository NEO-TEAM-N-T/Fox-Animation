#!/usr/bin/env python3
"""Convert Bedrock attachables (resource pack) into the engine's attachable bundles.

Usage: attachable_to_bundle.py <RP folder> <out root> 
Writes, under <out root>/assets/ans/:
  attachable/<name>.json                       the bundle (+ identifier, bone_bindings)
  geckolib/models/entity/<name>_<geo>.geo.json models (the bone "binding" key is moved into bone_bindings)
  geckolib/animations/entity/<name>.animation.json
  textures/...                                 textures used by the item
"""
import json, os, re, sys, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from bedrock_to_bundle import Pack, jload, tok, render_type  # noqa: E402

NS = 'ans'
# Bedrock attachable file -> (bundle name, Java item id, slots it is allowed in)
ITEMS = [
    ('ece.json', 'vn_item_handbook', 'ans:villager_news_handbook', ['main_hand', 'off_hand']),
    ('ecf.json', 'vn_item_mayor_hat', 'ans:mayor_hat', ['head']),
    ('ecg.json', 'vn_item_microphone', 'ans:microphone', ['main_hand', 'off_hand']),
    ('ech.json', 'vn_item_moustache', 'ans:moustache', ['head']),
    ('eci.json', 'vn_item_testificate_helmet', 'ans:testificate_man_helmet', ['head']),
    ('ecj.json', 'vn_item_villager_nose', 'ans:villager_nose', ['head']),
]
OWNERS = "q.is_owner_identifier_any('minecraft:player','minecraft:armor_stand')"


def convert_attachable(pack, att_file, name, out_root):
    d = jload(att_file)['minecraft:attachable']['description']
    report = {'missing_anim': [], 'missing_ctrl': [], 'missing_rc': [], 'missing_geo': [], 'textures': []}
    att_dir = f'{out_root}/assets/{NS}/attachable'
    geo_dir = f'{out_root}/assets/{NS}/geckolib/models/entity'
    anim_dir = f'{out_root}/assets/{NS}/geckolib/animations/entity'
    for p in (att_dir, geo_dir, anim_dir):
        os.makedirs(p, exist_ok=True)

    geometry, bone_bindings = {}, {}
    for key, gid in d.get('geometry', {}).items():
        gid = gid.split(':')[0]
        if gid not in pack.geo:
            report['missing_geo'].append(gid)
            continue
        fname = f'{name}_{tok(gid)}'
        g = json.loads(json.dumps(pack.geo[gid]))
        g['description']['identifier'] = f'geometry.{NS}.{fname}'
        binds = {}
        for b in g.get('bones', []):
            if 'binding' in b:
                binds[b['name'].lower()] = b.pop('binding')
        json.dump({'format_version': '1.12.0', 'minecraft:geometry': [g]},
                  open(f'{geo_dir}/{fname}.geo.json', 'w'), separators=(',', ':'))
        geometry[key] = f'{NS}:entity/{fname}'
        if binds:
            bone_bindings[f'{NS}:entity/{fname}'] = binds

    textures = {}
    for key, t in d.get('textures', {}).items():
        src = os.path.join(pack.root, t + '.png')
        if os.path.exists(src):
            dst = f'{out_root}/assets/{NS}/{t}.png'
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(src, dst)
            textures[key] = f'{NS}:{t}.png'
            report['textures'].append(t)
        else:
            textures[key] = f'minecraft:{t}.png'

    materials = {}
    for key, m in d.get('materials', {}).items():
        parent = pack.mat.get(m, m)
        rt, cm, multi = render_type(parent)
        e = {'bedrock': parent, 'render_type': rt}
        if cm:
            e['color_mask'] = True
        if multi:
            e['multi_texture'] = True
        materials[key] = e

    anim_file, animations = {}, {}
    for key, v in d.get('animations', {}).items():
        if v.startswith('controller.animation.'):
            c = pack.ctrl.get(v)
            if c is None:
                report['missing_ctrl'].append(v)
                animations[key] = {'bedrock': v, 'missing': True}
                continue
            animations[key] = {'bedrock': v, 'controller': json.loads(json.dumps(c))}
        else:
            a = pack.anim.get(v)
            if a is None:
                report['missing_anim'].append(v)
                animations[key] = {'bedrock': v, 'missing': True}
                continue
            gk = f'animation.{name}.{tok(key)}'
            e = {'bedrock': v, 'animation': gk}
            for k in ('loop', 'animation_length', 'anim_time_update', 'blend_weight', 'start_delay',
                      'loop_delay', 'override_previous_animation', 'timeline'):
                if k in a:
                    e[k] = a[k]
            animations[key] = e
            anim_file[gk] = {k: x for k, x in a.items() if k not in ('timeline', 'sound_effects', 'particle_effects')}
    json.dump({'format_version': '1.8.0', 'animations': anim_file},
              open(f'{anim_dir}/{name}.animation.json', 'w'), separators=(',', ':'))

    rcs = []
    for ent in d.get('render_controllers', []):
        rid, cond = (ent, None) if isinstance(ent, str) else next(iter(ent.items()))
        r = pack.rc.get(rid)
        if r is None:
            report['missing_rc'].append(rid)
            continue
        r = json.loads(json.dumps(r))
        if 'arrays' in r:
            flat = {}
            for grp in r['arrays'].values():
                for an, vals in grp.items():
                    flat[an] = vals
            r['arrays'] = flat
        r['id'] = rid
        r['condition'] = cond
        rcs.append(r)

    scripts = {k: v for k, v in (d.get('scripts') or {}).items() if k != 'variables'}
    bundle = {
        'format': f'{NS}:bedrock_attachable', 'format_version': 1,
        'identifier': d['identifier'],
        'source': {'layer': 'RP', 'file': os.path.basename(att_file), 'min_engine_version': '1.12.0'},
        'animation_file': f'{NS}:entity/{name}',
        'geometry': geometry, 'textures': textures, 'materials': materials,
        'animations': animations, 'scripts': scripts, 'render_controllers': rcs,
        'bone_bindings': bone_bindings,
        'sound_effects': {}, 'particle_effects': {},
    }
    json.dump(bundle, open(f'{att_dir}/{name}.json', 'w'), separators=(',', ':'))
    return report


def main():
    rp, out = sys.argv[1], sys.argv[2]
    pack = Pack(rp)
    index = {}
    for fn, name, item, slots in ITEMS:
        r = convert_attachable(pack, os.path.join(rp, 'attachables', fn), name, out)
        print(name, json.dumps(r))
        cond = "(" + " || ".join(f"c.item_slot=='{s}'" for s in slots) + ") && " + OWNERS
        index[item] = [[f'{NS}:attachable/{name}', cond]]
    os.makedirs(f'{out}/assets/{NS}/attachable', exist_ok=True)
    json.dump({'items': index}, open(f'{out}/assets/{NS}/attachable/_vn_index.json', 'w'), indent=1)


if __name__ == '__main__':
    main()
